"use client";
import { memo, useMemo } from "react";
import {
  ReactFlow, Background, BackgroundVariant, Controls, MiniMap, Handle, Position, MarkerType,
  type Node, type Edge, type NodeProps,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import { Award, Briefcase, Check, Code2, Flag, Hammer, Lock, MessageSquare, Zap } from "lucide-react";
import type { StoredRoadmap } from "@/lib/schema";
import { COL_W, layoutNodes, type Status } from "@/lib/graph";

type PFData = { title: string; kind: string; hours: number; status: Status; optional: boolean; selected: boolean };
const ICONS: Record<string, any> = { skill: Code2, project: Hammer, role: Briefcase, cert: Award, interview: MessageSquare, target: Flag };

const PFNode = memo(function PFNode({ data }: NodeProps) {
  const d = data as unknown as PFData;
  const Icon = ICONS[d.kind] || Code2;
  return (
    <div className={`pfnode ${d.status} ${d.kind === "target" ? "target" : ""} ${d.optional ? "optional" : ""} ${d.selected ? "sel" : ""}`}>
      <Handle type="target" position={Position.Left} className="pfh" />
      <div className="pfn-top">
        <span className="pfn-ico"><Icon size={14} /></span>
        <span className="pfn-kind">{d.kind}</span>
        <span className="pfn-state">
          {d.status === "completed" ? <Check size={14} /> : d.status === "locked" ? <Lock size={12} /> : d.status === "progress" ? <Zap size={13} /> : null}
        </span>
      </div>
      <div className="pfn-title">{d.title}</div>
      <div className="pfn-meta">{d.hours}h{d.optional ? " · alternative route" : ""}</div>
      <Handle type="source" position={Position.Right} className="pfh" />
    </div>
  );
});

const PhaseLabel = memo(function PhaseLabel({ data }: NodeProps) {
  const d = data as unknown as { title: string; index: number };
  return (
    <div className="phase-label">
      <span>PHASE {d.index + 1}</span>
      {d.title}
    </div>
  );
});

const nodeTypes = { pf: PFNode, phase: PhaseLabel };

export default function RoadmapView({
  roadmap, status, selectedId, onSelect,
}: { roadmap: StoredRoadmap; status: Record<string, Status>; selectedId: string | null; onSelect: (id: string) => void }) {
  const pos = useMemo(() => layoutNodes(roadmap), [roadmap]);

  const nodes: Node[] = useMemo(() => {
    const phaseNodes: Node[] = roadmap.phases.map((p, index) => ({
      id: `phase-${p.id}`, type: "phase", position: { x: index * COL_W, y: -90 },
      data: { title: p.title, index }, draggable: false, selectable: false, focusable: false,
    }));
    const pfNodes: Node[] = roadmap.nodes.map((n) => ({
      id: n.id, type: "pf", position: pos[n.id] || { x: 0, y: 0 }, draggable: false,
      data: { title: n.title, kind: n.type, hours: n.hours, status: status[n.id] || "locked", optional: n.optional, selected: n.id === selectedId },
    }));
    return [...phaseNodes, ...pfNodes];
  }, [roadmap, status, selectedId, pos]);

  const edges: Edge[] = useMemo(
    () =>
      roadmap.nodes.flatMap((n) =>
        n.prerequisites.map((p) => {
          const srcDone = status[p] === "completed";
          const tgtDone = status[n.id] === "completed";
          const color = srcDone ? "#06B6D4" : status[n.id] === "locked" ? "rgba(255,255,255,0.14)" : "#A855F7";
          return {
            id: `${p}-${n.id}`, source: p, target: n.id, animated: srcDone && !tgtDone,
            style: { stroke: color, strokeWidth: srcDone ? 2.4 : 1.6, strokeDasharray: n.optional ? "6 5" : undefined },
            markerEnd: { type: MarkerType.ArrowClosed, color },
          } as Edge;
        })
      ),
    [roadmap, status]
  );

  return (
    <ReactFlow
      key={roadmap.id}
      nodes={nodes}
      edges={edges}
      nodeTypes={nodeTypes}
      colorMode="dark"
      fitView
      fitViewOptions={{ padding: 0.15 }}
      minZoom={0.2}
      maxZoom={1.8}
      nodesDraggable={false}
      nodesConnectable={false}
      elementsSelectable
      onNodeClick={(_, n) => { if (n.type === "pf") onSelect(n.id); }}
    >
      <Background variant={BackgroundVariant.Dots} gap={26} size={1} color="rgba(255,255,255,0.09)" />
      <Controls showInteractive={false} />
      <MiniMap pannable zoomable className="minimap" maskColor="rgba(5,5,10,0.7)" nodeColor={(n) => (n.type === "phase" ? "transparent" : "#06B6D4")} />
    </ReactFlow>
  );
}
