import { NextResponse } from "next/server";
import { AIError } from "./ai";

const hits = new Map<string, number[]>();
export function limited(req: Request, max = 12, windowMs = 60000): boolean {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "local";
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < windowMs);
  if (arr.length >= max) {
    hits.set(ip, arr);
    return true;
  }
  arr.push(now);
  hits.set(ip, arr);
  return false;
}

export async function readBody(req: Request, max = 20000): Promise<unknown> {
  const text = await req.text();
  if (text.length > max) throw new AIError("Request too large.", 413);
  try {
    return JSON.parse(text);
  } catch {
    throw new AIError("Invalid request.", 400);
  }
}

export function fail(e: unknown) {
  if (e instanceof AIError) return NextResponse.json({ error: e.message }, { status: e.status });
  console.error(e);
  return NextResponse.json({ error: "Something went wrong. Please try again." }, { status: 500 });
}

export const tooMany = () => NextResponse.json({ error: "Too many requests. Please wait a minute." }, { status: 429 });
