-- PathSurfers CRISTIANO additive enhancements
-- Idempotent: adds tables/indexes only and existing rows are never deleted or rewritten

CREATE TABLE IF NOT EXISTS user_regions (
    username TEXT PRIMARY KEY,
    region TEXT NOT NULL CHECK(region IN ('North','South','East','West','Central','North-East')),
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(username) REFERENCES users(username) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS course_metadata (
    course_id INTEGER PRIMARY KEY,
    created_by TEXT,
    status TEXT NOT NULL DEFAULT 'Published',
    duration_minutes INTEGER,
    FOREIGN KEY(course_id) REFERENCES courses(id) ON DELETE CASCADE,
    FOREIGN KEY(created_by) REFERENCES users(username) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS course_learning_outcomes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    course_id INTEGER NOT NULL,
    outcome TEXT NOT NULL,
    sequence_no INTEGER DEFAULT 1,
    FOREIGN KEY(course_id) REFERENCES courses(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS course_prerequisites (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    course_id INTEGER NOT NULL,
    prerequisite TEXT NOT NULL,
    FOREIGN KEY(course_id) REFERENCES courses(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS trainer_resources (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trainer_username TEXT NOT NULL,
    repository_id INTEGER NOT NULL,
    course_id INTEGER,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(trainer_username) REFERENCES users(username) ON DELETE CASCADE,
    FOREIGN KEY(repository_id) REFERENCES repository(id) ON DELETE CASCADE,
    FOREIGN KEY(course_id) REFERENCES courses(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_trainer_resources_trainer ON trainer_resources(trainer_username, created_at);

CREATE TABLE IF NOT EXISTS recovery_rate_limits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    identifier_hash TEXT NOT NULL,
    action TEXT NOT NULL,
    window_started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    attempts INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS chat_context (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    context_key TEXT NOT NULL,
    context_value TEXT NOT NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(username, context_key)
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username_ci_unique ON users(username COLLATE NOCASE);
CREATE UNIQUE INDEX IF NOT EXISTS idx_enrollments_user_course_unique ON enrollments(username, course_id);
CREATE INDEX IF NOT EXISTS idx_enrollments_course ON enrollments(course_id);
CREATE INDEX IF NOT EXISTS idx_module_progress_user ON user_module_progress(username, module_id);
CREATE INDEX IF NOT EXISTS idx_assessment_attempts_user ON assessment_attempts(username, completed_at);
CREATE INDEX IF NOT EXISTS idx_course_assessments_user_course ON course_assessments(username, course_id);
CREATE INDEX IF NOT EXISTS idx_assignments_trainee ON trainer_assignments(trainee_username, status);
CREATE INDEX IF NOT EXISTS idx_assignments_trainer ON trainer_assignments(trainer_username, status);
CREATE INDEX IF NOT EXISTS idx_notifications_user_read ON notifications(username, is_read, created_at);
CREATE INDEX IF NOT EXISTS idx_competency_scores_subject ON competency_scores(subject, created_at);
CREATE INDEX IF NOT EXISTS idx_course_outcomes_course ON course_learning_outcomes(course_id, sequence_no);
