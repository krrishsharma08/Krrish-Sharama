#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT/android_wrapper"
if [ -x ./gradlew ]; then
  ./gradlew clean assembleDebug
elif command -v gradle >/dev/null 2>&1; then
  gradle clean assembleDebug
else
  echo "Android build toolchain missing. Install Android Studio + SDK 35 + Gradle 8.9+, then run this script again."
  exit 1
fi
printf '\nAPK: %s\n' "$PWD/app/build/outputs/apk/debug/app-debug.apk"
