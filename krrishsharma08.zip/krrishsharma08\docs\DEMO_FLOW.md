# PathSurfers Judge Demo Flow

1. Sign in as a Trainee.
2. Open **PathForge** and enter a hyper-specific dream job.
3. Show the generated dependency graph and explain the branch/merge structure.
4. Open a milestone and show the AI-generated project/interview/resource brief.
5. Mark a prerequisite as known; show the conservative AI replan.
6. Open Courses and enroll in a real CSE/AI course.
7. Complete modules and show live progress.
8. Open Competencies and show that the score is derived from actual progress/assessments.
9. Open Recommendations and show Groq selecting from the real catalog using the PathForge target.
10. Open Analytics Hub and show the live metrics plus AI coach insight.
11. Ask Mr.White a question about the learner's actual progress/path.
12. Finish on the PathForge graph + synced Learning Path as the memorable final frame.

## Demo safety

- Keep a local fallback roadmap available.
- Never invent user counts, performance numbers or testimonials.
- If Groq is temporarily unavailable, explain the deterministic fallback honestly.
