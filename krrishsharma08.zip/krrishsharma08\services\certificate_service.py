
import secrets
def eligibility(conn, username, course_id):
    enrolled=conn.execute("SELECT 1 FROM enrollments WHERE username=? AND course_id=?",(username,course_id)).fetchone()
    if not enrolled: return False,"Course not enrolled"
    total=conn.execute("SELECT COUNT(*) c FROM course_modules WHERE course_id=?",(course_id,)).fetchone()["c"]
    done=conn.execute("""SELECT COUNT(*) c FROM user_module_progress ump JOIN course_modules cm ON cm.id=ump.module_id
                         WHERE ump.username=? AND cm.course_id=? AND ump.completed=1""",(username,course_id)).fetchone()["c"]
    assessment=conn.execute("""SELECT MAX(score) s FROM course_assessments
        WHERE username=? AND course_id=? AND passed=1""",(username,course_id)).fetchone()["s"]
    if total and done < total: return False,f"Complete all modules ({done}/{total})"
    if not assessment: return False,"Pass the required course assessment"
    return True,"Eligible"
def issue(conn, username, course_id, score):
    existing=conn.execute("SELECT * FROM certificates WHERE username=? AND course_id=? AND status='Issued'",
                          (username,course_id)).fetchone()
    if existing: return dict(existing)
    code="CC-"+secrets.token_hex(5).upper()
    conn.execute("""INSERT INTO certificates(certificate_id,username,course_id,verification_code,issued_at,score,status)
                    VALUES (?,?,?,?,CURRENT_TIMESTAMP,?,'Issued')""",
                 (code,username,course_id,code,float(score)))
    return dict(conn.execute("SELECT * FROM certificates WHERE certificate_id=?",(code,)).fetchone())
