@echo off
setlocal
cd /d "%~dp0"
title PATHSURFERS
REM All Python dependencies are vendored in vendor\python, so no pip install is needed.
set "PYTHONPATH=%~dp0vendor\python;%PYTHONPATH%"
if "%PORT%"=="" set "PORT=5000"
REM 0.0.0.0 lets a phone on the same Wi-Fi open the app. Use 127.0.0.1 for this PC only.
if "%FLASK_HOST%"=="" set "FLASK_HOST=0.0.0.0"
if not exist ".env" (
  echo [!] .env not found - AI features will use the local fallback. Copy .env.example to .env and add GROQ_API_KEY.
)
set "PY=python"
where py >nul 2>nul && set "PY=py -3"
echo.
echo  PATHSURFERS is starting...
echo  On this PC:      http://127.0.0.1:%PORT%
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4"') do echo  On your phone:   http:/%%a:%PORT%  (same Wi-Fi)
echo.
%PY% app.py
pause