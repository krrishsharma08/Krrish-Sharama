# Database

Original tables preserved:
users, courses, enrollments, messages, repository, course_modules, user_module_progress, audit_logs, emergency_drills, webinars.

Added tables:
competency_assessments, competency_scores, questions, question_options, assessment_attempts, assessment_answers,
trainer_profiles, trainer_expertise, trainer_availability, trainer_questionnaires, trainer_assignments,
course_resources, course_feedback, trainer_feedback, certificates, course_assessments, approvals, notifications,
training_deadlines, learning_paths, learning_path_items, user_badges, learning_streaks.

Migration: `migrations/001_enhancements.sql`.
Seed: `scripts/seed_enhancements.py`.
