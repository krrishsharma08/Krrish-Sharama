# PathSurfers — final 5-minute run

## Windows

```powershell
cd C:\pathsurfers08
.\.venv\Scripts\Activate.ps1
python app.py
```

Open `http://127.0.0.1:5000`.

## PathForge

Open **PathForge ✦**, enter a target role and press **Forge my path**.

PathForge is intentionally fail-safe:
- Groq is the primary roadmap generator.
- If Groq times out or is temporarily unavailable, the validated local dependency graph renders instead.
- The UI never waits indefinitely for AI.
- Milestone AI details and Mr.White can still use Groq independently.

## If the browser still shows the old loader

Do a hard refresh:

`Ctrl + Shift + R`

If necessary, clear the site's local storage once from DevTools → Application → Local Storage, then refresh.

## Groq

Keep the API key in the local `.env` only. Never commit or publish `.env`.
