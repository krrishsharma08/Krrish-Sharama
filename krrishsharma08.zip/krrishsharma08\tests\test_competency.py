import unittest
from services.competency_service import competency_level, classify_gap
class CompetencyTests(unittest.TestCase):
    def test_levels(self):
        self.assertEqual(competency_level(35),"Beginner"); self.assertEqual(competency_level(50),"Developing")
        self.assertEqual(competency_level(75),"Intermediate"); self.assertEqual(competency_level(90),"Advanced"); self.assertEqual(competency_level(98),"Expert")
    def test_gap(self):
        self.assertEqual(classify_gap(45),"Critical Gap"); self.assertEqual(classify_gap(65),"Needs Improvement"); self.assertEqual(classify_gap(85),"Strong")
if __name__=="__main__": unittest.main()
