
def calculate_trainer_performance(conn, username):
    feedback = conn.execute("SELECT AVG(rating) v FROM trainer_feedback WHERE trainer_username=?", (username,)).fetchone()["v"]
    trainee_score = conn.execute("""SELECT AVG(ca.score) v FROM course_assessments ca
        JOIN trainer_assignments ta ON ta.trainee_username=ca.username
        WHERE ta.trainer_username=?""", (username,)).fetchone()["v"]
    assigned = conn.execute("SELECT COUNT(*) c FROM trainer_assignments WHERE trainer_username=?", (username,)).fetchone()["c"] or 0
    completed = conn.execute("SELECT COUNT(*) c FROM trainer_assignments WHERE trainer_username=? AND status='Completed'", (username,)).fetchone()["c"] or 0
    completion_rate = (completed/assigned*100) if assigned else 0
    feedback_score = float(feedback or 0) * 20
    trainee_score = float(trainee_score or 0)
    performance = round(0.45*feedback_score + 0.35*trainee_score + 0.20*completion_rate,1)
    conn.execute("UPDATE trainer_profiles SET performance_score=? WHERE username=?", (performance,username))
    return performance

def _availability_score(conn, username):
    row = conn.execute("""SELECT COUNT(*) AS available FROM trainer_availability
        WHERE trainer_username=? AND available=1""", (username,)).fetchone()
    return min(100, 50 + (row["available"] or 0) * 10)

def _workload(conn, username):
    row = conn.execute("""SELECT COUNT(*) AS c FROM trainer_assignments
        WHERE trainer_username=? AND status IN ('Pending','Accepted','Active')""", (username,)).fetchone()
    return row["c"] or 0

def calculate_trainer_match_score(conn, trainee_username, trainer_username, subject, trainee_level=None):
    expertise = conn.execute("""SELECT te.skill_level FROM trainer_expertise te
        WHERE te.trainer_username=? AND lower(te.subject)=lower(?) LIMIT 1""",
        (trainer_username, subject)).fetchone()
    expertise_score = {"Beginner":65, "Developing":75, "Intermediate":85, "Advanced":95, "Expert":100}.get(
        (expertise["skill_level"] if expertise else ""), 0)
    performance = calculate_trainer_performance(conn, trainer_username)
    availability = _availability_score(conn, trainer_username)
    workload = _workload(conn, trainer_username)
    workload_penalty = min(25, workload * 5)
    trainee_gap = conn.execute("""SELECT score FROM competency_scores cs
        JOIN competency_assessments ca ON ca.id=cs.assessment_id
        WHERE ca.username=? AND lower(cs.subject)=lower(?) ORDER BY cs.id DESC LIMIT 1""",
        (trainee_username, subject)).fetchone()
    gap = 100 - float(trainee_gap["score"]) if trainee_gap else 50
    competency_match = min(100, 50 + gap * 0.5)
    score = max(0, min(100, 0.30*expertise_score + 0.20*competency_match +
                       0.20*performance + 0.20*availability + 0.10*(100-workload_penalty)))
    reasons = []
    if expertise: reasons.append(f"{subject} expertise ({expertise['skill_level']})")
    if performance >= 80: reasons.append("strong trainer performance")
    if availability >= 70: reasons.append("good availability")
    if workload <= 2: reasons.append("low current workload")
    if trainee_level and expertise and expertise["skill_level"] in ("Intermediate","Advanced","Expert"):
        reasons.append(f"experienced for {trainee_level.lower()} learners")
    return round(score, 1), {
        "expertise_match": round(expertise_score, 1),
        "competency_match": round(competency_match, 1),
        "performance": round(performance, 1),
        "availability": round(availability, 1),
        "workload": round(max(0, 100-workload_penalty), 1),
        "reason": "; ".join(reasons) or "subject match available"
    }

def match_trainers_for_trainee(conn, trainee_username, subject):
    trainers = conn.execute("""SELECT u.username, COALESCE(u.fullname,u.username) fullname,
        tp.designation, tp.organization, tp.experience_years
        FROM users u JOIN trainer_profiles tp ON tp.username=u.username
        JOIN trainer_expertise te ON te.trainer_username=u.username
        WHERE u.role!='Trainee' AND lower(te.subject)=lower(?)""", (subject,)).fetchall()
    results=[]
    for t in trainers:
        score, breakdown=calculate_trainer_match_score(conn, trainee_username,t["username"],subject)
        results.append({**dict(t), "match_score":score, **breakdown})
    return sorted(results,key=lambda x:x["match_score"],reverse=True)


# --- Cristiano enhancement: questionnaire-aware, de-duplicated matching ---
def match_trainers_for_trainee_enhanced(conn, trainee_username, subject):
    """Return one explainable match per trainer using only stored data.

    This extends the existing deterministic matching model. No ML/API is used.
    """
    trainee = conn.execute(
        "SELECT username, role FROM users WHERE username=?", (trainee_username,)
    ).fetchone()
    if not trainee:
        return []

    scores = latest_trainee_scores = {}
    try:
        rows = conn.execute(
            """SELECT subject, score FROM competency_scores
               WHERE username=? ORDER BY recorded_at DESC""", (trainee_username,)
        ).fetchall()
        for r in rows:
            scores.setdefault(r["subject"].lower(), float(r["score"]))
    except Exception:
        pass
    trainee_score = scores.get((subject or "").lower())
    if trainee_score is None:
        trainee_level = "Developing"
    elif trainee_score < 40:
        trainee_level = "Beginner"
    elif trainee_score < 60:
        trainee_level = "Developing"
    elif trainee_score < 80:
        trainee_level = "Intermediate"
    elif trainee_score < 95:
        trainee_level = "Advanced"
    else:
        trainee_level = "Expert"

    rows = conn.execute(
        """SELECT tp.username, COALESCE(u.fullname,u.username) fullname,
                  tp.specialization, tp.experience_years, tp.performance_score,
                  tp.availability_status,
                  te.subject, te.topic, te.skill_level,
                  tq.teaching_experience, tq.technical_expertise,
                  tq.subjects_handled, tq.preferred_trainee_level,
                  tq.training_methodology, tq.certifications,
                  tq.research_interests, tq.practical_expertise
           FROM trainer_profiles tp
           JOIN users u ON u.username=tp.username
           LEFT JOIN trainer_expertise te ON te.trainer_username=tp.username
           LEFT JOIN trainer_questionnaires tq ON tq.trainer_username=tp.username
           WHERE u.role NOT IN ('Trainee','Administrator')
           ORDER BY tp.username"""
    ).fetchall()

    grouped = {}
    subject_l = (subject or "").strip().lower()
    for r in rows:
        grouped.setdefault(r["username"], []).append(r)

    result = []
    for username, records in grouped.items():
        # Do not recommend a trainer already assigned to this trainee for this subject.
        active = conn.execute(
            """SELECT 1 FROM trainer_assignments
               WHERE trainer_username=? AND trainee_username=? AND lower(subject)=?
                 AND status IN ('Pending','Accepted','Active')
               LIMIT 1""",
            (username, trainee_username, subject_l),
        ).fetchone()
        if active:
            continue

        best = max(records, key=lambda x: (
            1 if (x["subject"] or "").lower() == subject_l else 0,
            1 if subject_l and subject_l in (x["subjects_handled"] or "").lower() else 0,
        ))
        expertise_text = " ".join(
            str((r["subject"] or "")) + " " + str((r["topic"] or "")) +
            " " + str((r["technical_expertise"] or "")) +
            " " + str((r["practical_expertise"] or ""))
            for r in records
        ).lower()
        exact_subject = any((r["subject"] or "").lower() == subject_l for r in records)
        questionnaire_subject = subject_l in (best["subjects_handled"] or "").lower()
        expertise = 100 if exact_subject else (85 if questionnaire_subject else (55 if subject_l in expertise_text else 25))

        pref_level = (best["preferred_trainee_level"] or "").strip().lower()
        level_match = 100 if pref_level == trainee_level.lower() else (70 if not pref_level else 40)

        methodology = 100 if (best["training_methodology"] or "").strip() else 50
        experience = min(100, float(best["experience_years"] or 0) * 10)
        performance = float(best["performance_score"] or 0)
        availability = 100 if (best["availability_status"] or "").lower() == "available" else 45 if (best["availability_status"] or "").lower() == "busy" else 10
        workload = conn.execute(
            """SELECT COUNT(*) FROM trainer_assignments
               WHERE trainer_username=? AND status IN ('Pending','Accepted','Active')""",
            (username,),
        ).fetchone()[0]
        workload_score = max(0, 100 - min(100, int(workload) * 20))

        # Questionnaire is deliberately meaningful but does not overpower expertise.
        score = round(
            expertise * 0.35 +
            level_match * 0.15 +
            performance * 0.20 +
            availability * 0.10 +
            workload_score * 0.10 +
            experience * 0.05 +
            methodology * 0.05, 1
        )
        reasons = []
        if exact_subject:
            reasons.append(f"Strong {subject} expertise")
        elif questionnaire_subject:
            reasons.append(f"Questionnaire lists {subject}")
        if level_match >= 100:
            reasons.append(f"Preferred for {trainee_level}-level trainees")
        if experience >= 50:
            reasons.append(f"{round(float(best['experience_years'] or 0),1)} years of experience")
        if performance > 0:
            reasons.append(f"Trainer performance {round(performance,1)}%")
        if availability >= 100:
            reasons.append("Currently available")
        if workload_score >= 80:
            reasons.append("Low current workload")
        if not reasons:
            reasons.append("Relevant trainer profile data")

        result.append({
            "username": username,
            "fullname": best["fullname"],
            "match_score": score,
            "reason": "; ".join(reasons),
            "reasons": reasons,
            "trainee_level": trainee_level,
            "workload": workload,
            "availability_status": best["availability_status"],
        })
    return sorted(result, key=lambda x: (-x["match_score"], x["fullname"].lower()))
