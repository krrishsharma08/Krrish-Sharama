
def log_action(conn, username, action, details=""):
    conn.execute("INSERT INTO audit_logs(username,action,details) VALUES (?,?,?)",
                 (username,action,details[:1000] if details else ""))
