import sqlite3
import random
import math
import difflib
import re
import os
import ast
import secrets
from functools import wraps
from datetime import date, datetime
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_file
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def _load_local_env():
    env_path = os.path.join(BASE_DIR, '.env')
    if os.path.exists(env_path):
        for line in open(env_path, encoding='utf-8', errors='ignore'):
            line=line.strip()
            if line and not line.startswith('#') and '=' in line:
                k,v=line.split('=',1)
                os.environ.setdefault(k.strip(), v.strip())
_load_local_env()
app.secret_key = os.environ.get('SECRET_KEY') or secrets.token_hex(32)
app.config.update(SEND_FILE_MAX_AGE_DEFAULT=3600, TEMPLATES_AUTO_RELOAD=False, SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax',
                  SESSION_COOKIE_SECURE=os.environ.get('FLASK_SECURE_COOKIE','0') == '1')

# PORTAL additive, FAM fix: login rate limiting now persists in the
# login_rate_limits SQLite table (migrations/006_ai_features.sql) instead of an
# in-memory dict, so lockouts survive a process restart. Same key/window/lockout
# semantics as before.
_LOGIN_MAX_ATTEMPTS = 5
_LOGIN_WINDOW_SECONDS = 600     # 10 minutes
_LOGIN_LOCKOUT_SECONDS = 900    # 15 minutes

def _login_rate_key():
    ip = request.headers.get('X-Forwarded-For', request.remote_addr or 'unknown').split(',')[0].strip()
    uname = (request.form.get('username') or '').strip().lower()
    return f"{ip}:{uname}"

def _login_is_locked_out(key):
    conn = get_db_connection()
    row = conn.execute(
        "SELECT locked_until FROM login_rate_limits WHERE rate_key=? ORDER BY id DESC LIMIT 1", (key,)
    ).fetchone()
    conn.close()
    if not row or not row['locked_until']:
        return False, 0
    locked_until = datetime.fromisoformat(row['locked_until'])
    now = datetime.now()
    if locked_until > now:
        return True, int((locked_until - now).total_seconds())
    return False, 0

def _login_record_failure(key):
    conn = get_db_connection()
    now = datetime.now()
    window_start = now.timestamp() - _LOGIN_WINDOW_SECONDS
    recent = conn.execute(
        """SELECT COUNT(*) c FROM login_rate_limits
           WHERE rate_key=? AND window_started_at >= ?""",
        (key, datetime.fromtimestamp(window_start).isoformat())
    ).fetchone()['c']
    attempts = recent + 1
    locked_until = None
    if attempts >= _LOGIN_MAX_ATTEMPTS:
        locked_until = (now.timestamp() + _LOGIN_LOCKOUT_SECONDS)
        locked_until = datetime.fromtimestamp(locked_until).isoformat()
    conn.execute(
        "INSERT INTO login_rate_limits(rate_key, window_started_at, attempts, locked_until) VALUES(?,?,?,?)",
        (key, now.isoformat(), attempts, locked_until)
    )
    conn.commit()
    conn.close()

def _login_clear(key):
    conn = get_db_connection()
    conn.execute("DELETE FROM login_rate_limits WHERE rate_key=?", (key,))
    conn.commit()
    conn.close()

def _get_cert_signing_key():
    """PORTAL fix: certificate signatures must stay valid across server restarts.
    app.secret_key is regenerated randomly on every restart when SECRET_KEY isn't
    set in .env (confirmed true for this project's default setup), so signing
    against it would silently invalidate every previously issued certificate on
    the next restart. Instead, persist a small dedicated signing key on disk the
    first time it's needed — independent of the session secret, never touching
    any existing data or table."""
    key_dir = os.path.join(BASE_DIR, 'instance')
    key_path = os.path.join(key_dir, 'cert_signing_key.txt')
    try:
        if os.path.exists(key_path):
            with open(key_path, 'r') as f:
                return f.read().strip()
        os.makedirs(key_dir, exist_ok=True)
        key = secrets.token_hex(32)
        with open(key_path, 'w') as f:
            f.write(key)
        return key
    except OSError:
        # Filesystem not writable (e.g. read-only deploy) — fall back to the
        # runtime secret so the feature still works, just without cross-restart
        # stability, rather than raising an error on every certificate view.
        return app.secret_key

def certificate_signature(cert_id, verification_code, username, course_id):
    """PORTAL additive: deterministic HMAC signature so a certificate's authenticity
    can be cryptographically re-derived at verify time, with nothing new stored in
    the database — it is recomputed from fields that already exist on the row."""
    import hmac, hashlib
    key = _get_cert_signing_key()
    key_bytes = key if isinstance(key, bytes) else str(key).encode('utf-8')
    payload = f"{cert_id}|{verification_code}|{username}|{course_id}".encode('utf-8')
    return hmac.new(key_bytes, payload, hashlib.sha256).hexdigest()[:16].upper()

def get_db_connection():
    conn = sqlite3.connect(os.path.join(BASE_DIR, 'database.db'))
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    return conn

from services.competency_service import record_assessment, gap_analysis, latest_scores, competency_level
from services.trainer_matching import match_trainers_for_trainee, match_trainers_for_trainee_enhanced
from services.assessment_service import get_question_set, question_options
from services.notification_service import notify, unread_count
from services.feedback_service import average_trainer_rating, average_course_rating
from services.analytics_service import dashboard_metrics, score_distribution, pass_rate, leaderboard, question_accuracy
from services.audit_service import log_action
from services.certificate_service import eligibility, issue
from services.account_recovery import find_user_by_identifier, create_recovery_code, verify_recovery_code, set_password, valid_password, verify_current_password
from services.ai_content_service import generate_ai_quiz_questions, generate_course_assessment_questions, ai_recommend_course
from services.mrwhite_ai import ask_mr_white, build_context_block
from services.groq_service import ai_enabled as ai_is_enabled

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if 'user' not in session:
            return redirect(url_for('login'))
        return fn(*args, **kwargs)
    return wrapper

def role_required(*roles):
    def deco(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            if 'user' not in session:
                return redirect(url_for('login'))
            if session.get('role') not in roles:
                flash('You are not authorized to perform that action.')
                return redirect(url_for('home'))
            return fn(*args, **kwargs)
        return wrapper
    return deco

# Database Initialization Helper
def init_db():
    conn = get_db_connection()
    # Users table
    conn.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL,
            fullname TEXT,
            email TEXT,
            phone TEXT,
            dob TEXT,
            ref_code TEXT UNIQUE,
            leader_ref_code TEXT
        )
    ''')
    # Courses table
    conn.execute('''
        CREATE TABLE IF NOT EXISTS courses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            category TEXT NOT NULL,
            level TEXT NOT NULL
        )
    ''')
    # Enrollments table
    conn.execute('''
        CREATE TABLE IF NOT EXISTS enrollments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            course_id INTEGER NOT NULL,
            FOREIGN KEY (username) REFERENCES users (username),
            FOREIGN KEY (course_id) REFERENCES courses (id)
        )
    ''')
    # Messages table
    conn.execute('''
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender_username TEXT NOT NULL,
            receiver_username TEXT NOT NULL,
            message TEXT NOT NULL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    # Repository table
    conn.execute('''
        CREATE TABLE IF NOT EXISTS repository (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            category TEXT NOT NULL,
            type TEXT NOT NULL,
            summary TEXT NOT NULL,
            content TEXT NOT NULL,
            published_date TEXT NOT NULL
        )
    ''')
    # Course Modules Table
    conn.execute('''
        CREATE TABLE IF NOT EXISTS course_modules (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            course_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            order_index INTEGER DEFAULT 1,
            FOREIGN KEY (course_id) REFERENCES courses (id)
        )
    ''')
    # User Module Progress Table
    conn.execute('''
        CREATE TABLE IF NOT EXISTS user_module_progress (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            module_id INTEGER NOT NULL,
            completed INTEGER DEFAULT 0,
            completed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (module_id) REFERENCES course_modules (id),
            UNIQUE(username, module_id)
        )
    ''')
    
    # Seed sample courses if empty
    course_count = conn.execute('SELECT COUNT(*) FROM courses').fetchone()[0]
    if course_count == 0:
        sample_courses = [
            ("Python Programming Fundamentals", "Learn core python concepts, data structures, and automation scripts for real-world datasets.", "Programming", "Beginner"),
            ("Oceanographic Data Processing", "Analyze CTD profiler streams, salinity calculations, and current telemetry arrays.", "Oceanography", "Advanced"),
            ("Seismic Wave Analysis", "P-wave/S-wave detection, focal depth calculations, and emergency telemetry failovers.", "Seismology", "Intermediate"),
            ("Coastal Cyclone Forecasting", "Atmospheric pressure drops, wind vectors, and emergency evacuation protocols.", "Meteorology", "Intermediate")
        ]
        conn.executemany('INSERT INTO courses (title, description, category, level) VALUES (?, ?, ?, ?)', sample_courses)
        
        # Seed default modules for course 1
        sample_modules = [
            (1, "Introduction to Python Syntax", "Variables, loops, functions, and working with basic data structures.", 1),
            (1, "Working with NumPy Arrays", "Handling multi-dimensional arrays for sensor grids and mathematical modeling.", 2),
            (1, "Pandas for Data Cleaning", "Dropping nulls, filtering telemetry readings, and generating data frames.", 3)
        ]
        conn.executemany('INSERT INTO course_modules (course_id, title, content, order_index) VALUES (?, ?, ?, ?)', sample_modules)

    count = conn.execute('SELECT COUNT(*) FROM repository').fetchone()[0]
    if count == 0:
        sample_docs = [
            (
                "SOP 101: Coastal Cyclone Evacuation Protocol",
                "Meteorology",
                "SOP",
                "Standard operating procedure for emergency evacuation procedures during category 3+ cyclones along coastal zones.",
                "1. Trigger alert upon 24-hr landfall warning.\n2. Coordinate with regional coastal authorities.\n3. Mobilize emergency shelters and verify telemetry links.",
                "2026-01-15"
            ),
            (
                "SOP 204: Tsunami Buoy Maintenance & Telemetry Check",
                "Oceanography",
                "SOP",
                "Field maintenance steps for ocean floor pressure sensors and surface telemetry buoys.",
                "1. Inspect battery levels and acoustic transducer seals.\n2. Perform live satellite telemetry loopback test.\n3. Calibrate depth-pressure sensor array.",
                "2026-02-10"
            ),
            (
                "Case Study: 2023 Tsunami Early Warning Protocol Analysis",
                "Oceanography",
                "Case Study",
                "In-depth analysis of telemetry response times during the Indian Ocean seismic event.",
                "Analysis confirmed early warning alert delivered within 8 minutes of seismic wave detection. Highlighted need for redundant satellite backhauls.",
                "2025-11-20"
            ),
            (
                "Emergency Manual: Seismic Data Ingestion Failover",
                "Seismology",
                "Manual",
                "Quick-reference troubleshooting manual for telemetry failure at primary earthquake monitoring stations.",
                "Step 1: Check hardware status LED.\nStep 2: Switch data stream to backup cellular radio frequency.\nStep 3: Alert regional monitoring center.",
                "2026-03-01"
            )
        ]
        conn.executemany(
            'INSERT INTO repository (title, category, type, summary, content, published_date) VALUES (?, ?, ?, ?, ?, ?)',
            sample_docs
        )
    conn.commit()
    conn.close()

init_db()

def apply_enhancement_migrations():
    conn = get_db_connection()
    migration_dir = os.path.join(BASE_DIR, 'migrations')
    for filename in sorted(os.listdir(migration_dir)):
        if not filename.endswith('.sql'):
            continue
        with open(os.path.join(migration_dir, filename), encoding='utf-8') as f:
            conn.executescript(f.read())
    conn.commit()
    conn.close()
apply_enhancement_migrations()

def apply_web_migrations():
    """WEB additive: adds a nullable avatar_path column to users if missing.
    Guarded (checks PRAGMA table_info first) instead of a raw ALTER TABLE in the
    migrations/*.sql auto-loader, since that loader re-runs every startup and a
    plain ALTER TABLE ADD COLUMN would crash on the second run with
    'duplicate column name'. No existing column or row is touched."""
    conn = get_db_connection()
    cols = [r['name'] for r in conn.execute("PRAGMA table_info(users)").fetchall()]
    if 'avatar_path' not in cols:
        conn.execute("ALTER TABLE users ADD COLUMN avatar_path TEXT")
        conn.commit()
    conn.close()
apply_web_migrations()

def apply_fam_migrations():
    """FAM additive: adds nullable theme_preference / cert_display_name columns to
    users if missing, same guarded-ALTER pattern as apply_web_migrations() above
    (the migrations/*.sql loader can't safely ALTER an existing table on rerun)."""
    conn = get_db_connection()
    cols = [r['name'] for r in conn.execute("PRAGMA table_info(users)").fetchall()]
    if 'theme_preference' not in cols:
        conn.execute("ALTER TABLE users ADD COLUMN theme_preference TEXT DEFAULT 'dark'")
    if 'cert_display_name' not in cols:
        conn.execute("ALTER TABLE users ADD COLUMN cert_display_name TEXT")
    conn.commit()
    conn.close()
apply_fam_migrations()

import services.groq_service as groq_service

# Helper function to generate unique 5-digit reference codes
def generate_unique_ref_code():
    conn = get_db_connection()
    try:
        while True:
            code = str(random.randint(10000, 99999))
            existing = conn.execute('SELECT id FROM users WHERE ref_code = ?', (code,)).fetchone()
            if not existing:
                return code
    finally:
        conn.close()

# Dynamic AI Questions Generator
def generate_dynamic_ai_questions(count=3):
    templates = [
        {
            "domain": "Programming",
            "type": "array_calc",
            "generate": lambda: (
                lambda dim1, dim2: {
                    "question": f"In Python NumPy, if an ocean sensor array has shape ({dim1}, {dim2}), what is the total number of data points returned by `.size`?",
                    "options": list({str(dim1 * dim2), str(dim1 * dim2 + 5), str(dim1 * dim2 * 2), str(dim1 * dim2 + 12)}),
                    "answer": str(dim1 * dim2)
                }
            )(random.randint(2, 8), random.randint(10, 50))
        },
        {
            "domain": "Programming",
            "type": "pandas_filter",
            "generate": lambda: {
                "question": f"Which Pandas function is used to drop missing oceanographic salinity values recorded above threshold {random.randint(30, 40)} PSU?",
                "options": ["dropna()", "fillna()", "remove_null()", "clean()"],
                "answer": "dropna()"
            }
        },
        {
            "domain": "Oceanography",
            "type": "ctd_depth",
            "generate": lambda: {
                "question": f"An ocean CTD profiler deployed at station #{random.randint(101, 999)} measures sea surface temperature. Which sensor measures electrical conductivity to derive salinity?",
                "options": ["Conductivity Cell", "Acoustic Doppler", "Barometer", "Seismometer"],
                "answer": "Conductivity Cell"
            }
        },
        {
            "domain": "Seismology",
            "type": "wave_velocity",
            "generate": lambda: {
                "question": f"During a seismic monitoring event with focal depth {random.randint(10, 50)} km, which wave arrives FIRST at a seismic telemetry station?",
                "options": ["P-Wave (Primary)", "S-Wave (Secondary)", "Love Wave", "Rayleigh Wave"],
                "answer": "P-Wave (Primary)"
            }
        },
        {
            "domain": "Meteorology",
            "type": "pressure_trend",
            "generate": lambda: {
                "question": f"An atmospheric pressure drop of {random.randint(5, 15)} hPa within 3 hours measured by a coastal weather station indicates which phenomenon?",
                "options": ["Approaching Cyclonic Depression", "Solar Maximum", "Tectonic Uplift", "Thermal Inversion"],
                "answer": "Approaching Cyclonic Depression"
            }
        },
        # PORTAL additive templates: same generator contract, more meteorological domain variety.
        {
            "domain": "Meteorology",
            "type": "nwp_resolution",
            "generate": lambda: (
                lambda km: {
                    "question": f"An NWP model run at {km} km horizontal resolution over the Bay of Bengal is best suited for detecting weather features larger than roughly what scale?",
                    "options": [f"~{km*2} km", f"~{max(1,km//2)} km", f"~{km*10} km", f"~{km} m"],
                    "answer": f"~{km*2} km"
                }
            )(random.choice([3, 6, 12, 25]))
        },
        {
            "domain": "Meteorology",
            "type": "cyclone_category",
            "generate": lambda: (
                lambda speed: {
                    "question": f"A cyclonic storm off the east coast with sustained wind speed of {speed} km/h would be classified under IMD nomenclature closest to which category?",
                    "options": ["Severe Cyclonic Storm", "Depression", "Super Cyclonic Storm", "Well Marked Low Pressure Area"],
                    "answer": "Severe Cyclonic Storm" if 89 <= speed <= 117 else "Super Cyclonic Storm"
                }
            )(random.choice([95, 105, 112]))
        },
        {
            "domain": "Oceanography",
            "type": "sst_anomaly",
            "generate": lambda: (
                lambda anomaly: {
                    "question": f"A sea-surface temperature anomaly of +{anomaly}°C sustained over the central Pacific for several months is most consistent with which climate phenomenon?",
                    "options": ["El Niño", "La Niña", "Indian Ocean Dipole (negative)", "Polar Vortex Collapse"],
                    "answer": "El Niño"
                }
            )(random.choice([0.8, 1.2, 1.6]))
        },
        {
            "domain": "Seismology",
            "type": "magnitude_scale",
            "generate": lambda: (
                lambda mag: {
                    "question": f"On the Moment Magnitude scale, an earthquake of magnitude {mag} releases roughly how much more energy than one of magnitude {mag-1}?",
                    "options": ["~32 times more", "~2 times more", "~10 times more", "~100 times more"],
                    "answer": "~32 times more"
                }
            )(random.choice([5, 6, 7]))
        },
    ]
    
    selected_templates = random.sample(templates, min(count, len(templates)))
    generated_questions = []
    
    for i, t in enumerate(selected_templates, 1):
        q_data = t["generate"]()
        options = q_data["options"][:]
        random.shuffle(options)
        
        generated_questions.append({
            "id": i,
            "question": q_data["question"],
            "options": options,
            "answer": q_data["answer"],
            "domain": t["domain"]
        })
        
    return generated_questions

@app.route('/')
def home():
    if 'user' not in session:
        return redirect(url_for('login'))

    conn = get_db_connection()
    rows = conn.execute(
        '''SELECT c.id, c.title, c.category, c.level,
                  COUNT(cm.id) AS total_modules,
                  SUM(CASE WHEN COALESCE(ump.completed,0)=1 THEN 1 ELSE 0 END) AS completed_modules
           FROM courses c
           JOIN enrollments e ON c.id=e.course_id
           LEFT JOIN course_modules cm ON cm.course_id=c.id
           LEFT JOIN user_module_progress ump
             ON ump.module_id=cm.id AND ump.username=e.username
           WHERE e.username=?
           GROUP BY c.id, c.title, c.category, c.level
           ORDER BY c.title''',
        (session['user'],)
    ).fetchall()

    enrolled = []
    for row in rows:
        item = dict(row)
        total = int(item.get('total_modules') or 0)
        done = int(item.get('completed_modules') or 0)
        item['progress'] = 100 if total == 0 else min(100, round(done * 100 / total))
        enrolled.append(item)

    user = conn.execute(
        "SELECT username,fullname,email,phone,role FROM users WHERE username=?",
        (session['user'],)
    ).fetchone()
    conn.close()
    return render_template('dashboard.html', username=session['user'], enrolled_courses=enrolled, current_user=user)

@app.route('/admin')
@role_required('Administrator', 'Leader')
def admin():
    if 'user' not in session:
        return redirect(url_for('login'))
    
    role = session.get('role')
    user_ref_code = session.get('ref_code')
    current_username = session.get('user')

    conn = get_db_connection()
    total_courses = conn.execute('SELECT COUNT(*) FROM courses').fetchone()[0]

    assigned_leader_name = None
    assigned_leader_username = None
    leader_ref_code = user_ref_code if role not in ('Trainee', 'Non-Reliable User') else None

    if role == 'Trainee':
        user_info = conn.execute('SELECT leader_ref_code FROM users WHERE username = ?', (current_username,)).fetchone()
        trainee_leader_code = user_info['leader_ref_code'] if user_info else None
        
        if trainee_leader_code:
            leader_ref_code = trainee_leader_code
            leader_user = conn.execute('SELECT username, fullname FROM users WHERE ref_code = ?', (trainee_leader_code,)).fetchone()
            if leader_user:
                assigned_leader_username = leader_user['username']
                assigned_leader_name = leader_user['fullname'] or leader_user['username']

        total_users = 1
        total_enrollments = conn.execute('SELECT COUNT(*) FROM enrollments WHERE username = ?', (current_username,)).fetchone()[0]
        user_stats = conn.execute('''
            SELECT u.username, u.fullname, u.email, u.phone, u.role, u.ref_code, u.leader_ref_code, COUNT(e.id) as course_count 
            FROM users u 
            LEFT JOIN enrollments e ON u.username = e.username 
            WHERE u.username = ?
            GROUP BY u.id
        ''', (current_username,)).fetchall()

    elif role in ('Administrator', 'Leader'):
        total_users = conn.execute('SELECT COUNT(*) FROM users').fetchone()[0]
        total_enrollments = conn.execute('SELECT COUNT(*) FROM enrollments').fetchone()[0]
        
        user_stats = conn.execute('''
            SELECT u.username, u.fullname, u.email, u.phone, u.role, u.ref_code, u.leader_ref_code, COUNT(e.id) as course_count 
            FROM users u 
            LEFT JOIN enrollments e ON u.username = e.username 
            GROUP BY u.id
        ''').fetchall()
    else:
        total_users = conn.execute('SELECT COUNT(*) FROM users WHERE leader_ref_code = ?', (user_ref_code,)).fetchone()[0]
        
        total_enrollments = conn.execute('''
            SELECT COUNT(e.id) 
            FROM enrollments e 
            JOIN users u ON e.username = u.username 
            WHERE u.leader_ref_code = ?
        ''', (user_ref_code,)).fetchone()[0]
        
        user_stats = conn.execute('''
            SELECT u.username, u.fullname, u.email, u.phone, u.role, u.ref_code, u.leader_ref_code, COUNT(e.id) as course_count 
            FROM users u 
            LEFT JOIN enrollments e ON u.username = e.username 
            WHERE u.leader_ref_code = ?
            GROUP BY u.id
        ''', (user_ref_code,)).fetchall()

    conn.close()

    return render_template('admin.html', 
                           total_users=total_users, 
                           total_courses=total_courses, 
                           total_enrollments=total_enrollments, 
                           user_stats=user_stats,
                           leader_ref_code=leader_ref_code,
                           assigned_leader_name=assigned_leader_name,
                           assigned_leader_username=assigned_leader_username)

@app.route('/send_message', methods=['POST'])
def send_message():
    if 'user' not in session:
        return jsonify({'status': 'error', 'message': 'Unauthorized'}), 401
    
    if session.get('role') == 'Non-Reliable User':
        return jsonify({'status': 'error', 'message': 'Non-Reliable User accounts cannot send direct messages.'}), 403

    data = request.get_json(silent=True) or {}
    receiver_username = data.get('receiver_username')
    message_text = data.get('message')

    if not receiver_username or not message_text:
        return jsonify({'status': 'error', 'message': 'Missing data'}), 400

    conn = get_db_connection()
    receiver_exists=conn.execute('SELECT 1 FROM users WHERE username=?',(receiver_username,)).fetchone()
    if not receiver_exists:
        conn.close(); return jsonify({'status':'error','message':'Receiver not found'}),404
    conn.execute('INSERT INTO messages (sender_username, receiver_username, message) VALUES (?, ?, ?)',
                 (session['user'], receiver_username, message_text[:2000]))
    notify(conn,receiver_username,'Trainer message',f'New message from {session["user"]}.','message')
    conn.commit(); conn.close()
    return jsonify({'status': 'success'})

@app.route('/get_messages/<receiver_username>')
def get_messages(receiver_username):
    if 'user' not in session:
        return jsonify([]), 401

    current_user = session['user']
    conn = get_db_connection()
    
    messages = conn.execute('''
        SELECT sender_username, receiver_username, message, timestamp 
        FROM messages 
        WHERE (sender_username = ? AND receiver_username = ?)
           OR (sender_username = ? AND receiver_username = ?)
        ORDER BY timestamp ASC
    ''', (current_user, receiver_username, receiver_username, current_user)).fetchall()
    
    conn.close()

    result = []
    for msg in messages:
        result.append({
            'sender': msg['sender_username'],
            'message': msg['message'],
            'timestamp': msg['timestamp'],
            'is_me': msg['sender_username'] == current_user
        })

    return jsonify(result)

@app.route('/courses')
def courses():
    if 'user' not in session:
        return redirect(url_for('login'))
    
    conn = get_db_connection()
    all_courses = conn.execute('SELECT * FROM courses').fetchall()
    
    user_enrollments = conn.execute('SELECT course_id FROM enrollments WHERE username = ?', (session['user'],)).fetchall()
    enrolled_ids = [row['course_id'] for row in user_enrollments]
    conn.close()
    
    return render_template('courses.html', courses=all_courses, enrolled_ids=enrolled_ids)

@app.route('/course/<int:course_id>')
def course_detail(course_id):
    if 'user' not in session:
        return redirect(url_for('login'))
    
    conn = get_db_connection()
    course = conn.execute('SELECT * FROM courses WHERE id = ?', (course_id,)).fetchone()
    
    if not course:
        conn.close()
        flash('Course not found!')
        return redirect(url_for('courses'))
        
    enrollment = conn.execute('SELECT * FROM enrollments WHERE username = ? AND course_id = ?', 
                            (session['user'], course_id)).fetchone()
    
    modules = conn.execute('SELECT * FROM course_modules WHERE course_id = ? ORDER BY order_index ASC', (course_id,)).fetchall()
    
    completed_modules = conn.execute(
        'SELECT module_id FROM user_module_progress WHERE username = ? AND completed = 1',
        (session['user'],)
    ).fetchall()
    completed_ids = [m['module_id'] for m in completed_modules]
    outcomes = conn.execute("SELECT outcome FROM course_learning_outcomes WHERE course_id=? ORDER BY sequence_no,id", (course_id,)).fetchall()
    prerequisites = conn.execute("SELECT prerequisite FROM course_prerequisites WHERE course_id=? ORDER BY id", (course_id,)).fetchall()
    metadata = conn.execute("SELECT * FROM course_metadata WHERE course_id=?", (course_id,)).fetchone()
    # FAM additive: attached course files (pdf/photo/video), downloadable for offline viewing.
    course_files = conn.execute(
        "SELECT id, file_type, original_name, stored_path FROM course_files WHERE course_id=? ORDER BY id",
        (course_id,)).fetchall()

    conn.close()

    return render_template('course_detail.html', course=course, is_enrolled=bool(enrollment), modules=modules,
                           completed_ids=completed_ids, outcomes=outcomes, prerequisites=prerequisites,
                           metadata=metadata, course_files=course_files)

@app.route('/complete_module/<int:module_id>', methods=['POST'])
@login_required
def complete_module(module_id):
    conn = get_db_connection()
    module = conn.execute('SELECT * FROM course_modules WHERE id=?', (module_id,)).fetchone()
    enrolled = conn.execute('SELECT 1 FROM enrollments e JOIN course_modules cm ON cm.course_id=e.course_id WHERE e.username=? AND cm.id=?',
                            (session['user'], module_id)).fetchone()
    if not module or not enrolled:
        conn.close(); return jsonify({'status':'error','message':'Module not found or not enrolled'}),403
    conn.execute('''INSERT INTO user_module_progress (username, module_id, completed)
                    VALUES (?, ?, 1)
                    ON CONFLICT(username, module_id) DO UPDATE SET completed=1, completed_at=CURRENT_TIMESTAMP''',
                 (session['user'], module_id))
    log_action(conn, session['user'], 'module_completion', f'Module {module_id}')
    conn.commit(); conn.close()
    return jsonify({'status':'success'})

@app.route('/course/<int:course_id>/download-pdf')
@login_required
def download_course_pdf(course_id):
    """Generate a read-only PDF snapshot of an existing course without changing DB data."""
    conn = get_db_connection()
    try:
        course = conn.execute('SELECT * FROM courses WHERE id=?', (course_id,)).fetchone()
        if not course:
            flash('Course not found!')
            return redirect(url_for('courses'))
        modules = conn.execute('SELECT * FROM course_modules WHERE course_id=? ORDER BY order_index ASC', (course_id,)).fetchall()
        outcomes = conn.execute('SELECT outcome FROM course_learning_outcomes WHERE course_id=? ORDER BY sequence_no,id', (course_id,)).fetchall()
        prerequisites = conn.execute('SELECT prerequisite FROM course_prerequisites WHERE course_id=? ORDER BY id', (course_id,)).fetchall()
    finally:
        conn.close()

    # Tiny dependency-free PDF writer. It intentionally uses the standard PDF
    # Helvetica font and replaces unsupported Unicode with a readable fallback,
    # keeping the download available even in an offline/local deployment.
    import io
    import textwrap

    def safe_text(value):
        text = str(value or '').replace('\r', '').replace('\t', '    ')
        return text.encode('latin-1', 'replace').decode('latin-1')

    lines = [
        'PathSurfers - Course Study Guide',
        '',
        safe_text(course['title']),
        f"Category: {safe_text(course['category'])}",
        f"Level: {safe_text(course['level'])}",
        '',
        'COURSE DESCRIPTION',
    ]
    for para in safe_text(course['description']).split('\n'):
        lines.extend(textwrap.wrap(para, width=92) or [''])
    if outcomes:
        lines += ['', 'WHAT YOU WILL LEARN']
        for row in outcomes:
            lines.extend(textwrap.wrap('- ' + safe_text(row['outcome']), width=92) or [''])
    if prerequisites:
        lines += ['', 'PREREQUISITES']
        for row in prerequisites:
            lines.extend(textwrap.wrap('- ' + safe_text(row['prerequisite']), width=92) or [''])
    if modules:
        lines += ['', 'COURSE MODULES']
        for idx, module in enumerate(modules, 1):
            lines.append(f'{idx}. {safe_text(module["title"])}')
            content = safe_text(module['content'])
            for para in content.split('\n'):
                lines.extend(textwrap.wrap(para, width=88) or [''])
            lines.append('')
    lines += ['', 'Generated by PathSurfers. This PDF is a read-only course snapshot.']

    # Build a minimal valid PDF with automatic page breaks.
    page_lines = 48
    pages = [lines[i:i + page_lines] for i in range(0, len(lines), page_lines)] or [['PathSurfers']]
    objects = []
    page_ids = []
    font_id = 3 + 2 * len(pages)
    for page_no, page_lines_data in enumerate(pages, 1):
        content = ['BT', '/F1 11 Tf', '54 748 Td', '14 TL']
        for line in page_lines_data:
            escaped = line.replace('\\', '\\\\').replace('(', '\\(').replace(')', '\\)')
            content.append(f'({escaped}) Tj T*')
        content.append('ET')
        stream = '\n'.join(content).encode('latin-1', 'replace')
        content_id = 3 + 2 * (page_no - 1)
        page_id = 4 + 2 * (page_no - 1)
        objects.append((content_id, f'<< /Length {len(stream)} >>\nstream\n'.encode() + stream + b'\nendstream'))
        objects.append((page_id, f'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 {font_id} 0 R >> >> /Contents {content_id} 0 R >>'.encode()))
        page_ids.append(page_id)

    kids = ' '.join(f'{pid} 0 R' for pid in page_ids)
    objects.insert(0, (1, b'<< /Type /Catalog /Pages 2 0 R >>'))
    objects.insert(1, (2, f'<< /Type /Pages /Kids [{kids}] /Count {len(page_ids)} >>'.encode()))
    objects.append((font_id, b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>'))
    objects.sort(key=lambda x: x[0])

    pdf = bytearray(b'%PDF-1.4\n%\xe2\xe3\xcf\xd3\n')
    offsets = {0: 0}
    for obj_id, body in objects:
        offsets[obj_id] = len(pdf)
        pdf.extend(f'{obj_id} 0 obj\n'.encode())
        pdf.extend(body)
        pdf.extend(b'\nendobj\n')
    xref = len(pdf)
    max_id = max(offsets)
    pdf.extend(f'xref\n0 {max_id + 1}\n'.encode())
    pdf.extend(b'0000000000 65535 f \n')
    for i in range(1, max_id + 1):
        pdf.extend(f'{offsets.get(i, 0):010d} 00000 n \n'.encode())
    pdf.extend(f'trailer\n<< /Size {max_id + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n'.encode())

    filename = re.sub(r'[^A-Za-z0-9._-]+', '_', safe_text(course['title'])).strip('_') or f'course_{course_id}'
    return send_file(io.BytesIO(bytes(pdf)), mimetype='application/pdf', as_attachment=True,
                     download_name=f'{filename}.pdf')

@app.route('/certificate/<int:course_id>')
@login_required
def certificate(course_id):
    conn=get_db_connection()
    course=conn.execute('SELECT * FROM courses WHERE id=?',(course_id,)).fetchone()
    if not course:
        conn.close(); flash('Course not found!'); return redirect(url_for('courses'))
    ok,reason=eligibility(conn,session['user'],course_id)
    cert=conn.execute("SELECT * FROM certificates WHERE username=? AND course_id=? AND status='Issued'",
                      (session['user'],course_id)).fetchone()
    if not ok and not cert:
        conn.close(); flash('Certificate not available yet: '+reason); return redirect(url_for('course_detail',course_id=course_id))
    # FAM additive: before the very first certificate is issued for this user, ask
    # what name they want printed on it (once — the choice is then remembered on
    # their profile and reused silently for every future certificate).
    if not cert:
        me = conn.execute("SELECT cert_display_name FROM users WHERE username=?", (session['user'],)).fetchone()
        if not (me and me['cert_display_name']):
            conn.close()
            return redirect(url_for('certificate_name_prompt', course_id=course_id))
        score=conn.execute("SELECT score FROM course_assessments WHERE username=? AND course_id=? AND passed=1 ORDER BY id DESC LIMIT 1",
                           (session['user'],course_id)).fetchone()['score']
        cert=issue(conn,session['user'],course_id,score)
        log_action(conn,session['user'],'certificate_generation',f'Course {course_id}')
        notify(conn,session['user'],'Certificate available',f'Your certificate for {course["title"]} is ready.','certificate')
        conn.commit()
    display_name_row = conn.execute("SELECT cert_display_name, fullname FROM users WHERE username=?", (session['user'],)).fetchone()
    display_name = (display_name_row['cert_display_name'] if display_name_row else None) or \
                    (display_name_row['fullname'] if display_name_row else None) or session['user']
    conn.close()
    sig = certificate_signature(cert['certificate_id'], cert['verification_code'], cert['username'], cert['course_id']) if cert else None
    verify_url = url_for('verify_certificate', verification_code=cert['verification_code'], _external=True) if cert else None
    return render_template('certificate.html',course=course,username=display_name,certificate=cert,
                            cert_signature=sig, verify_url=verify_url)

@app.route('/certificate/<int:course_id>/name', methods=['GET', 'POST'])
@login_required
def certificate_name_prompt(course_id):
    conn = get_db_connection()
    course = conn.execute('SELECT * FROM courses WHERE id=?', (course_id,)).fetchone()
    if not course:
        conn.close(); flash('Course not found!'); return redirect(url_for('courses'))
    if request.method == 'POST':
        name = (request.form.get('cert_display_name') or '').strip()[:120]
        if not name:
            conn.close(); flash('Please enter the name you want printed on your certificate.')
            return redirect(url_for('certificate_name_prompt', course_id=course_id))
        conn.execute("UPDATE users SET cert_display_name=? WHERE username=?", (name, session['user']))
        conn.commit(); conn.close()
        return redirect(url_for('certificate', course_id=course_id))
    current = conn.execute("SELECT fullname FROM users WHERE username=?", (session['user'],)).fetchone()
    conn.close()
    return render_template('certificate_name.html', course=course,
                            suggested_name=(current['fullname'] if current else session['user']))

@app.route('/enroll/<int:course_id>', methods=['POST'])
def enroll(course_id):
    if 'user' not in session:
        return redirect(url_for('login'))
    
    conn = get_db_connection()
    try:
        course = conn.execute('SELECT id,title FROM courses WHERE id=?', (course_id,)).fetchone()
        if not course:
            flash('Course not found.')
            return redirect(url_for('courses'))
        existing = conn.execute('SELECT 1 FROM enrollments WHERE username=? AND course_id=?', (session['user'], course_id)).fetchone()
        if existing:
            flash('You are already enrolled in this course.')
            return redirect(url_for('course_detail', course_id=course_id))
        conn.execute('INSERT INTO enrollments (username, course_id) VALUES (?, ?)', (session['user'], course_id))
        log_action(conn,session['user'],'course_enrollment',f'Course {course_id}')
        notify(conn,session['user'],'Course enrolled',f'You are now enrolled in {course["title"]}.','enrollment')
        conn.commit()
        flash(f'Successfully enrolled in {course["title"]}!')
        return redirect(url_for('course_detail', course_id=course_id))
    except sqlite3.IntegrityError:
        conn.rollback()
        flash('Enrollment could not be completed because the course relationship is invalid. Please retry.')
        return redirect(url_for('courses'))
    finally:
        conn.close()

@app.route('/unenroll/<int:course_id>', methods=['POST'])
def unenroll(course_id):
    if 'user' not in session:
        return redirect(url_for('login'))
    
    conn = get_db_connection()
    conn.execute('DELETE FROM enrollments WHERE username = ? AND course_id = ?', (session['user'], course_id))
    log_action(conn,session['user'],'course_unenrollment',f'Course {course_id}')
    conn.commit()
    conn.close()
    
    flash('Course unenrolled successfully.')
    return redirect(url_for('home'))

@app.route('/competencies', methods=['GET', 'POST'])
def competencies():
    if 'user' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        q1 = request.form.get('q1')
        q2 = request.form.get('q2')
        
        python_score = 100 if q1 == 'correct' else 40
        ocean_score = 100 if q2 == 'correct' else 30
        
        session['python_score'] = python_score
        session['ocean_score'] = ocean_score
        session.modified = True
        
        flash('Quiz evaluation complete! View your results report below.')
        return redirect(url_for('result'))

    # FAM fix: build competency cards from real stored competency_scores + course
    # module-completion progress instead of one hard-coded "Data Analysis: 65%"
    # placeholder row. Falls back to the session quiz values only when no
    # assessment has been recorded yet for that subject.
    conn = get_db_connection()
    stored = {r['subject']: float(r['score']) for r in latest_scores(conn, session['user'])}
    # Never manufacture proficiency scores. Assessment evidence wins; when no
    # assessment exists, course/module completion is the only progress signal.
    user_competencies = []
    for subject, score in sorted(stored.items()):
        user_competencies.append({
            'name': subject,
            'level': f'{round(score)}%',
            'status': 'Strong' if score >= 80 else ('Moderate' if score >= 50 else 'Needs Improvement'),
            'color': '#22c55e' if score >= 80 else ('#eab308' if score >= 50 else '#ef4444'),
        })
    # Add per-enrolled-course completion percentage, grounded in real progress rows.
    enrolled_progress = conn.execute(
        """SELECT c.title,
                  COUNT(cm.id) total_modules,
                  SUM(CASE WHEN COALESCE(ump.completed,0)=1 THEN 1 ELSE 0 END) done
           FROM courses c JOIN enrollments e ON e.course_id=c.id
           LEFT JOIN course_modules cm ON cm.course_id=c.id
           LEFT JOIN user_module_progress ump ON ump.module_id=cm.id AND ump.username=?
           WHERE e.username=? GROUP BY c.id ORDER BY c.title""",
        (session['user'], session['user'])).fetchall()
    conn.close()
    for row in enrolled_progress:
        total = row['total_modules'] or 0
        done = row['done'] or 0
        pct = round((done / total) * 100) if total else 0
        user_competencies.append({
            'name': f"{row['title']} (course progress)", 'level': f'{pct}%',
            'status': 'Strong' if pct >= 70 else ('Moderate' if pct >= 40 else 'Needs Improvement'),
            'color': '#22c55e' if pct >= 70 else ('#eab308' if pct >= 40 else '#ef4444'),
        })

    return render_template('competency.html', competencies=user_competencies)

@app.route('/result')
def result():
    if 'user' not in session:
        return redirect(url_for('login'))
    
    conn=get_db_connection()
    stored=latest_scores(conn,session['user']); conn.close()
    score_map={r['subject']:r['score'] for r in stored}
    python_score=score_map.get('Programming',session.get('python_score',40))
    ocean_score=score_map.get('Oceanography',session.get('ocean_score',30))
    overall_score=round((python_score+ocean_score)/2)

    return render_template('result.html', 
                           username=session['user'], 
                           python_score=python_score, 
                           ocean_score=ocean_score, 
                           overall_score=overall_score)

@app.route('/ai-quiz', methods=['GET', 'POST'])
def ai_quiz():
    if 'user' not in session:
        return redirect(url_for('login'))
        
    if request.method == 'POST':
        score = 0
        weak_domains = []
        active_questions = session.get('active_ai_questions', [])
        
        for q in active_questions:
            selected_option = request.form.get(f"q_{q['id']}")
            if selected_option == q['answer']:
                score += 1
            else:
                weak_domains.append(q['domain'])
                
        if 'Programming' in weak_domains:
            session['python_score'] = 45
        else:
            session['python_score'] = 95
            
        if 'Oceanography' in weak_domains or 'Seismology' in weak_domains or 'Meteorology' in weak_domains:
            session['ocean_score'] = 35
        else:
            session['ocean_score'] = 90
            
        session.modified = True
        
        conn = get_db_connection()
        recommended_courses = []

        if weak_domains:
            placeholders = ','.join(['?'] * len(weak_domains))
            query = f"SELECT * FROM courses WHERE category IN ({placeholders})"
            db_matches = conn.execute(query, weak_domains).fetchall()
            recommended_courses = [dict(row) for row in db_matches]

            # FAM additive: if Groq is configured, ask it to pick the single best
            # match from the REAL catalogue (never a hallucinated course) and lead
            # with that pick + its reasoning; the existing category-match list still
            # backs it up so the page never comes back empty.
            all_courses = [dict(row) for row in conn.execute("SELECT * FROM courses").fetchall()]
            ai_pick = ai_recommend_course(weak_domains, all_courses) if all_courses else None
            if ai_pick:
                picked = next((c for c in all_courses if c['id'] == ai_pick['course_id']), None)
                if picked:
                    picked = dict(picked)
                    picked['reason'] = ai_pick['reason'] or f"Matches your gap in {', '.join(set(weak_domains))}."
                    picked['ai_powered'] = True
                    recommended_courses = [picked] + [c for c in recommended_courses if c.get('id') != picked['id']]

            if not recommended_courses:
                for d in set(weak_domains):
                    recommended_courses.append({
                        'title': f'{d} Competency Mastery Module',
                        'reason': f'AI identified continuous skill gap in {d} based on latest generated quiz attempt.',
                        'category': d,
                        'level': 'Intermediate'
                    })
        else:
            recommended_courses = [dict(row) for row in conn.execute("SELECT * FROM courses ORDER BY RANDOM() LIMIT 2").fetchall()]

        conn.close()
        
        session['ai_recommendations'] = recommended_courses
        
        return render_template(
            'recommendations.html', 
            score=score, 
            total=len(active_questions), 
            recommendations=recommended_courses,
            completed=True
        )

    # FAM additive: ask Groq for real, non-repeating questions narrowed to the
    # user's actual enrolled courses when possible; the exact same template
    # generator as before is the fallback, so the quiz never breaks offline.
    conn = get_db_connection()
    enrolled_titles = [r['title'] for r in conn.execute(
        """SELECT c.title FROM courses c JOIN enrollments e ON e.course_id=c.id
           WHERE e.username=?""", (session['user'],)).fetchall()]
    conn.close()
    new_questions = generate_ai_quiz_questions(
        count=5, topics=enrolled_titles or None, difficulty="Intermediate",
        fallback_fn=generate_dynamic_ai_questions
    )
    session['active_ai_questions'] = new_questions
    session['ai_quiz_is_ai'] = any(q.get('source') == 'ai' for q in new_questions)
    session.modified = True

    return render_template('ai_quiz.html', questions=new_questions, ai_powered=session['ai_quiz_is_ai'])

@app.route('/recommendations')
def recommendations():
    if 'user' not in session:
        return redirect(url_for('login'))

    # Recommendations are always constrained to the real course catalogue and
    # the learner's current evidence. PathForge target context is included when
    # available, so the recommendation closes the gap toward the chosen career.
    conn = get_db_connection()
    gaps = gap_analysis(conn, session['user'])
    available = conn.execute(
        "SELECT id,title,category,level,description FROM courses ORDER BY title"
    ).fetchall()
    enrolled_ids = {r['course_id'] for r in conn.execute(
        "SELECT course_id FROM enrollments WHERE username=?", (session['user'],)
    ).fetchall()}
    path = conn.execute(
        "SELECT * FROM learning_paths WHERE username=? AND status='Active' ORDER BY id DESC LIMIT 1",
        (session['user'],)
    ).fetchone()
    path_items = conn.execute(
        "SELECT title,item_type,status FROM learning_path_items WHERE path_id=? ORDER BY sequence_no",
        (path['id'],)
    ).fetchall() if path else []
    conn.close()

    weak = [str(x.get('subject')) for x in gaps.get('weak', []) if x.get('subject')]
    candidates = [dict(c) for c in available if c['id'] not in enrolled_ids]

    ai_pick = ai_recommend_course(weak, candidates) if candidates else None
    recommendations_out = []
    if ai_pick:
        chosen = next((c for c in candidates if c['id'] == ai_pick['course_id']), None)
        if chosen:
            recommendations_out.append({
                'title': chosen['title'],
                'reason': ai_pick.get('reason') or 'Best available course for your current evidence-based skill gaps.',
                'category': chosen['category'],
                'level': chosen['level'],
                'course_id': chosen['id'],
                'ai': True
            })

    if not recommendations_out:
        # Deterministic fallback: rank real courses by category match to weak
        # domains, then prefer courses the learner has not enrolled in.
        def score(c):
            hay = f"{c['title']} {c['category']} {c['description']}".lower()
            return sum(1 for w in weak if w.lower() in hay)
        ranked = sorted(candidates, key=lambda c: (-score(c), c['title']))
        for c in ranked[:3]:
            reason = ("Targets your current gap(s): " + ", ".join(weak[:3])
                      if weak else "A real catalogue course not yet in your enrolment; start building evidence toward your PathForge goal.")
            recommendations_out.append({
                'title': c['title'], 'reason': reason, 'category': c['category'],
                'level': c['level'], 'course_id': c['id'], 'ai': False
            })

    return render_template('recommendations.html',
                           recommendations=recommendations_out,
                           path=path,
                           path_items=path_items,
                           gaps=gaps,
                           ai_powered=ai_is_enabled())

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        rl_key = _login_rate_key()
        locked, retry_in = _login_is_locked_out(rl_key)
        if locked:
            flash(f'Too many failed login attempts. Please try again in {max(1, retry_in // 60)} minute(s).')
            return render_template('login.html')

        username = request.form['username']
        password = request.form['password']

        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        conn.close()

        if user and check_password_hash(user['password'], password):
            _login_clear(rl_key)
            session['user']=user['username']; session['role']=user['role']; session['ref_code']=user['ref_code']
            session['avatar_path']=user['avatar_path'] if 'avatar_path' in user.keys() else None
            user_dict = dict(user) if user else {}
            session['theme_preference']=user_dict.get('theme_preference', 'dark')
            conn=get_db_connection(); log_action(conn,user['username'],'login','Successful login'); conn.commit(); conn.close()
            return redirect(url_for('home'))
        else:
            _login_record_failure(rl_key)
            flash('Invalid username or password!')

    return render_template('login.html')

@app.route('/recover', methods=['GET', 'POST'])
def recover_account():
    if request.method == 'POST':
        action = request.form.get('action', 'username')
        identifier = request.form.get('identifier', '').strip()
        if action not in ('username', 'password') or not identifier:
            flash('Choose a recovery option and enter your registered email or phone number.')
            return render_template('recover.html')
        conn = get_db_connection()
        user, channel = find_user_by_identifier(conn, identifier)
        if not user:
            conn.close()
            flash('We could not verify those contact details. Check them and try again.')
            return render_template('recover.html')
        code, sent, masked, expires = create_recovery_code(conn, user['username'], channel, identifier)
        conn.commit(); conn.close()
        session['recovery_username'] = user['username']
        session['recovery_action'] = action
        session['recovery_demo_code'] = code if not sent else None
        session.modified = True
        if sent:
            flash(f'Verification code sent to {masked}. It expires in 10 minutes.')
        else:
            flash(f'Demo mode: verification code for {masked} is {code}. It expires in 10 minutes.')
        return redirect(url_for('recover_verify'))
    return render_template('recover.html')

@app.route('/recover/verify', methods=['GET', 'POST'])
def recover_verify():
    username = session.get('recovery_username')
    action = session.get('recovery_action')
    if not username or action not in ('username', 'password'):
        return redirect(url_for('recover_account'))
    if request.method == 'POST':
        code = request.form.get('code', '').strip()
        conn = get_db_connection()
        ok, message = verify_recovery_code(conn, username, code)
        if not ok:
            conn.commit(); conn.close()
            flash(message)
            return render_template('recover_verify.html', action=action, demo_code=session.get('recovery_demo_code'))
        conn.commit(); conn.close()
        session['recovery_verified'] = True
        session.pop('recovery_demo_code', None)
        return redirect(url_for('recover_reset'))
    return render_template('recover_verify.html', action=action, demo_code=session.get('recovery_demo_code'))

@app.route('/recover/reset', methods=['GET', 'POST'])
def recover_reset():
    username = session.get('recovery_username')
    action = session.get('recovery_action')
    if not username or not session.get('recovery_verified'):
        return redirect(url_for('recover_account'))
    conn = get_db_connection()
    user = conn.execute("SELECT username,fullname FROM users WHERE username=?", (username,)).fetchone()
    if not user:
        conn.close(); session.clear(); flash('Account not found.'); return redirect(url_for('login'))
    if action == 'username':
        conn.close()
        session.pop('recovery_username', None); session.pop('recovery_action', None); session.pop('recovery_verified', None)
        return render_template('recover_result.html', username=user['username'])
    if request.method == 'POST':
        new_password = request.form.get('new_password', '')
        confirm = request.form.get('confirm_password', '')
        if new_password != confirm:
            conn.close(); flash('Passwords do not match.')
            return render_template('recover_reset.html')
        if not valid_password(new_password):
            conn.close(); flash('Password must be 8–128 characters and include at least one letter and one number.')
            return render_template('recover_reset.html')
        set_password(conn, username, new_password)
        log_action(conn, username, 'password_recovery', 'Password reset completed')
        conn.commit(); conn.close()
        session.clear()
        flash('Password reset successfully. You can now sign in.')
        return redirect(url_for('login'))
    conn.close()
    return render_template('recover_reset.html')

AVATAR_DIR = os.path.join(BASE_DIR, 'static', 'uploads', 'avatars')
AVATAR_ALLOWED_EXT = {'png', 'jpg', 'jpeg', 'webp', 'gif'}
AVATAR_MAX_BYTES = 2 * 1024 * 1024  # 2MB

def _remove_avatar_file(username):
    """WEB additive: best-effort cleanup of a user's stored avatar file(s)."""
    if not os.path.isdir(AVATAR_DIR):
        return
    safe_prefix = re.sub(r'[^A-Za-z0-9_.-]', '_', username)
    for fname in os.listdir(AVATAR_DIR):
        if fname.startswith(safe_prefix + '.'):
            try:
                os.remove(os.path.join(AVATAR_DIR, fname))
            except OSError:
                pass

def _handle_avatar_upload():
    """WEB additive: validated profile-picture upload. Stores the file under
    static/uploads/avatars/<safe-username>.<ext> and records the relative path
    in the new (nullable, additive) users.avatar_path column only."""
    file = request.files.get('avatar')
    if not file or file.filename == '':
        flash('Choose an image to upload.')
        return redirect(url_for('account'))
    ext = file.filename.rsplit('.', 1)[-1].lower() if '.' in file.filename else ''
    if ext not in AVATAR_ALLOWED_EXT:
        flash('Please upload a PNG, JPG, JPEG, GIF or WEBP image.')
        return redirect(url_for('account'))
    file.seek(0, os.SEEK_END)
    size = file.tell()
    file.seek(0)
    if size > AVATAR_MAX_BYTES:
        flash('Image is too large. Please choose a file under 2MB.')
        return redirect(url_for('account'))
    try:
        os.makedirs(AVATAR_DIR, exist_ok=True)
        username = session['user']
        _remove_avatar_file(username)  # clear any previous extension for this user
        safe_prefix = re.sub(r'[^A-Za-z0-9_.-]', '_', username)
        fname = f"{safe_prefix}.{ext}"
        file.save(os.path.join(AVATAR_DIR, fname))
        rel_path = f"uploads/avatars/{fname}"
        conn = get_db_connection()
        conn.execute("UPDATE users SET avatar_path=? WHERE username=?", (rel_path, username))
        log_action(conn, username, 'avatar_upload', 'Profile picture updated')
        conn.commit(); conn.close()
        flash('Profile picture updated.')
        session['avatar_path'] = rel_path
        session.modified = True
    except OSError:
        flash('Could not save the image. Please try again.')
    return redirect(url_for('account'))

@app.route('/account', methods=['GET', 'POST'])
@login_required
def account():
    conn = get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE username=?", (session['user'],)).fetchone()
    if not user:
        conn.close(); session.clear(); return redirect(url_for('login'))
    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'username':
            new_username = request.form.get('new_username','').strip()
            current_password = request.form.get('current_password','')
            if not verify_current_password(conn, session['user'], current_password):
                conn.close(); flash('Current password is incorrect.'); return redirect(url_for('account'))
            if not re.fullmatch(r'[A-Za-z0-9_.-]{3,32}', new_username):
                conn.close(); flash('Username must be 3–32 characters and use only letters, numbers, dot, underscore or hyphen.'); return redirect(url_for('account'))
            if conn.execute("SELECT 1 FROM users WHERE lower(username)=lower(?) AND username<>?", (new_username, session['user'])).fetchone():
                conn.close(); flash('Username already exists. Please choose another username.'); return redirect(url_for('account'))
            old_username = session['user']
            try:
                conn.execute("UPDATE users SET username=? WHERE username=?", (new_username, old_username))
                for table, column in [
                    ('enrollments','username'),('messages','sender_username'),('messages','receiver_username'),
                    ('user_module_progress','username'),('competency_assessments','username'),
                    ('assessment_attempts','username'),('trainer_profiles','username'),('trainer_questionnaires','trainer_username'),
                    ('trainer_assignments','trainer_username'),('trainer_assignments','trainee_username'),
                    ('trainer_feedback','trainee_username'),('trainer_feedback','trainer_username'),
                    ('course_feedback','trainee_username'),('course_assessments','username'),('certificates','username'),
                    ('approvals','requested_by'),('notifications','username'),('learning_paths','username'),
                    ('learning_streaks','username'),('user_badges','username'),('training_deadlines','assigned_to'),
                    ('account_recovery_codes','username'),('audit_logs','username'),('user_regions','username'),('chat_context','username'),('course_metadata','created_by')
                ]:
                    try:
                        conn.execute(f"UPDATE {table} SET {column}=? WHERE {column}=?", (new_username, old_username))
                    except sqlite3.OperationalError:
                        pass
                session['user'] = new_username
                log_action(conn,new_username,'username_change',f'Username changed from {old_username}')
                conn.commit(); conn.close()
                flash('Username changed successfully.')
                return redirect(url_for('account'))
            except sqlite3.IntegrityError:
                conn.rollback(); conn.close(); flash('That username is already in use.'); return redirect(url_for('account'))
        if action == 'password':
            current_password = request.form.get('current_password','')
            new_password = request.form.get('new_password','')
            confirm = request.form.get('confirm_password','')
            if not verify_current_password(conn, session['user'], current_password):
                conn.close(); flash('Current password is incorrect.'); return redirect(url_for('account'))
            if new_password != confirm or not valid_password(new_password):
                conn.close(); flash('New passwords must match and contain 8–128 characters with at least one letter and one number.'); return redirect(url_for('account'))
            set_password(conn, session['user'], new_password)
            log_action(conn,session['user'],'password_change','Password changed from account settings')
            conn.commit(); conn.close(); flash('Password changed successfully.'); return redirect(url_for('account'))
        if action == 'cert_name':
            name = (request.form.get('cert_display_name') or '').strip()[:120]
            if not name:
                conn.close(); flash('Certificate name cannot be empty.'); return redirect(url_for('account'))
            conn.execute("UPDATE users SET cert_display_name=? WHERE username=?", (name, session['user']))
            log_action(conn, session['user'], 'cert_name_change', f'Certificate name set to {name}')
            conn.commit(); conn.close()
            flash('Certificate name updated. Future certificates will use this name.')
            return redirect(url_for('account'))
        if action == 'theme':
            theme = request.form.get('theme_preference', 'dark')
            if theme not in ('dark', 'light'):
                theme = 'dark'
            conn.execute("UPDATE users SET theme_preference=? WHERE username=?", (theme, session['user']))
            conn.commit(); conn.close()
            session['theme_preference'] = theme
            session.modified = True
            flash(f'Theme set to {theme} mode.')
            return redirect(url_for('account'))
        if action == 'avatar':
            conn.close()
            return _handle_avatar_upload()
        if action == 'remove_avatar':
            _remove_avatar_file(session['user'])
            conn.execute("UPDATE users SET avatar_path=NULL WHERE username=?", (session['user'],))
            log_action(conn,session['user'],'avatar_removed','Profile picture removed')
            conn.commit(); conn.close()
            session['avatar_path'] = None
            session.modified = True
            flash('Profile picture removed.'); return redirect(url_for('account'))
    stats = {
        'courses': conn.execute("SELECT COUNT(*) FROM enrollments WHERE username=?", (session['user'],)).fetchone()[0],
        'completed_modules': conn.execute("SELECT COUNT(*) FROM user_module_progress WHERE username=? AND completed=1", (session['user'],)).fetchone()[0],
        'certificates': conn.execute("SELECT COUNT(*) FROM certificates WHERE username=? AND status='Issued'", (session['user'],)).fetchone()[0],
        'assessments': conn.execute("SELECT COUNT(*) FROM course_assessments WHERE username=?", (session['user'],)).fetchone()[0],
        'average_score': round(conn.execute("SELECT COALESCE(AVG(score),0) FROM course_assessments WHERE username=?", (session['user'],)).fetchone()[0], 1),
        'completed_courses': conn.execute('''SELECT COUNT(*) FROM (
            SELECT e.course_id
            FROM enrollments e
            LEFT JOIN course_modules cm ON cm.course_id=e.course_id
            LEFT JOIN user_module_progress ump ON ump.username=e.username AND ump.module_id=cm.id AND ump.completed=1
            WHERE e.username=?
            GROUP BY e.course_id
            HAVING COUNT(cm.id)=0 OR COUNT(DISTINCT ump.module_id)=COUNT(DISTINCT cm.id)
        )''', (session['user'],)).fetchone()[0]
    }
    assignments = conn.execute("""SELECT ta.*, COALESCE(tp.specialization,'Trainer') specialization
                                   FROM trainer_assignments ta LEFT JOIN trainer_profiles tp ON tp.username=ta.trainer_username
                                   WHERE ta.trainee_username=? ORDER BY ta.id DESC LIMIT 3""", (session['user'],)).fetchall()
    region_row = conn.execute("SELECT region FROM user_regions WHERE username=?", (session['user'],)).fetchone()
    conn.close()
    return render_template('account.html', user=user, stats=stats, assignments=assignments,
                           region=(region_row['region'] if region_row else None),
                           regions=('North','South','East','West','Central','North-East'),
                           cert_display_name=(user['cert_display_name'] if user else None),
                           theme_preference=(user['theme_preference'] if user else 'dark'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        fullname = request.form.get('fullname')
        email = request.form.get('email')
        phone = request.form.get('phone')
        dob = request.form.get('dob')
        role = request.form.get('role', 'Trainee').strip()
        if role not in ('Trainee', 'Leader', 'Non-Reliable User'):
            role = 'Trainee'
        region = request.form.get('region', '').strip()
        if region and region not in ('North','South','East','West','Central','North-East'):
            flash('Invalid region selected.')
            return render_template('register.html')
        leader_ref_code = request.form.get('leader_ref_code', '').strip()

        hashed_password = generate_password_hash(password)
        ref_code = None

        if role == 'Leader':
            ref_code = generate_unique_ref_code()
            leader_ref_code = None
        elif role == 'Non-Reliable User':
            ref_code = None
            leader_ref_code = None
        else:
            if not re.fullmatch(r'\d{5}', leader_ref_code or ''):
                flash('A valid 5-digit Leader code is required for trainee registration.')
                return render_template('register.html')
            conn = get_db_connection()
            leader = conn.execute('SELECT id FROM users WHERE ref_code = ? AND role = "Leader"', (leader_ref_code,)).fetchone()
            conn.close()
            if not leader:
                flash('Invalid Leader code. Ask your chosen Leader for their 5-digit code.')
                return render_template('register.html')

        username = username.strip()
        if not re.fullmatch(r'[A-Za-z0-9_.-]{3,32}', username):
            flash('Username must be 3–32 characters and use only letters, numbers, dot, underscore or hyphen.')
            return render_template('register.html')
        conn = get_db_connection()
        try:
            if conn.execute('SELECT 1 FROM users WHERE lower(username)=lower(?)', (username,)).fetchone():
                conn.close()
                flash('Username already exists. Please choose another username.')
                return render_template('register.html')
            conn.execute(
                '''INSERT INTO users (username, password, role, fullname, email, phone, dob, ref_code, leader_ref_code) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                (username, hashed_password, role, fullname, email, phone, dob, ref_code, leader_ref_code)
            )
            if region:
                conn.execute('INSERT OR REPLACE INTO user_regions(username,region) VALUES(?,?)', (username, region))
            conn.commit()
            conn.close()

            if role == 'Leader':
                flash(f'Leader account created successfully! Your unique 5-digit code is: {ref_code}')
            else:
                flash('Registration successful! Please log in.')

            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            conn.close()
            flash('Username already exists!')

    return render_template('register.html')

@app.route('/logout')
def logout():
    username=session.get('user')
    if username:
        conn=get_db_connection(); log_action(conn,username,'logout','User logout'); conn.commit(); conn.close()
    session.clear()
    return redirect(url_for('login'))

@app.route('/repository')
def repository():
    if 'user' not in session:
        return redirect(url_for('login'))

    search_query = request.args.get('q', '').strip()
    category_filter = request.args.get('category', '').strip()
    type_filter = request.args.get('type', '').strip()

    conn = get_db_connection()
    
    sql = 'SELECT * FROM repository WHERE 1=1'
    params = []

    if search_query:
        sql += ' AND (title LIKE ? OR summary LIKE ? OR content LIKE ?)'
        params.extend([f'%{search_query}%', f'%{search_query}%', f'%{search_query}%'])

    if category_filter:
        sql += ' AND category = ?'
        params.append(category_filter)

    if type_filter:
        sql += ' AND type = ?'
        params.append(type_filter)

    sql += ' ORDER BY id DESC'
    
    docs = conn.execute(sql, params).fetchall()
    
    categories = conn.execute('SELECT DISTINCT category FROM repository').fetchall()
    types = conn.execute('SELECT DISTINCT type FROM repository').fetchall()
    conn.close()

    return render_template(
        'repository.html',
        documents=docs,
        categories=[c['category'] for c in categories],
        types=[t['type'] for t in types],
        selected_q=search_query,
        selected_category=category_filter,
        selected_type=type_filter
    )

@app.route('/repository/add', methods=['POST'])
@login_required
def add_repository_resource():
    if session.get('role') == 'Trainee':
        flash('Only trainers/leaders and administrators can publish repository resources.')
        return redirect(url_for('repository'))

    title = request.form.get('title', '').strip()
    category = request.form.get('category', '').strip() or request.form.get('domain', '').strip()
    doc_type = request.form.get('resource_type', '').strip() or request.form.get('type', '').strip()
    summary = request.form.get('description', '').strip() or request.form.get('summary', '').strip()
    content = request.form.get('content', '').strip() or summary
    published_date = date.today().isoformat()

    if title and category and doc_type:
        conn = get_db_connection()
        conn.execute(
            '''INSERT INTO repository (title, category, type, summary, content, published_date) 
                VALUES (?, ?, ?, ?, ?, ?)''',
            (title, category, doc_type, summary, content, published_date)
        )
        conn.commit()
        conn.close()
        flash('Knowledge resource published successfully!')

    return redirect(url_for('repository'))

@app.route('/repository/<int:doc_id>')
def repository_detail(doc_id):
    if 'user' not in session:
        return redirect(url_for('login'))

    conn = get_db_connection()
    doc = conn.execute('SELECT * FROM repository WHERE id = ?', (doc_id,)).fetchone()
    conn.close()

    if not doc:
        flash('Document not found!')
        return redirect(url_for('repository'))

    return render_template('repository_detail.html', doc=doc)

# --- Mr.White AI Assistant Integration Routes with Typo Tolerance & Correct Scientific Calculator ---
@app.route('/chat')
def chat_page():
    if 'user' not in session:
        return redirect(url_for('login'))
    conn = get_db_connection()
    conversations = conn.execute(
        "SELECT id, title, updated_at FROM mrwhite_conversations WHERE username=? ORDER BY updated_at DESC LIMIT 50",
        (session['user'],)).fetchall()
    conn.close()
    return render_template('chat.html', conversations=conversations, ai_powered=ai_is_enabled())

@app.route('/api/chat', methods=['POST'])
def api_chat():
    if 'user' not in session:
        return jsonify({'status': 'error', 'message': 'Unauthorized'}), 401
    
    data = request.get_json()
    raw_message = data.get('message', '').strip()
    user_message = raw_message.lower()
    
    if not user_message:
        return jsonify({'status': 'error', 'message': 'Empty message'}), 400

    response_text = None

    def has_typo_match(keywords, cutoff=0.75):
        user_words = user_message.split()
        for word in user_words:
            matches = difflib.get_close_matches(word, keywords, n=1, cutoff=cutoff)
            if matches:
                return True
        return False

    # 1. Safe scientific calculator (AST allow-list; never executes arbitrary code)
    is_math_query = any(char.isdigit() for char in user_message) and any(op in user_message for op in ['+', '-', '*', '/', '^', 'x', 'sqrt', 'sin', 'cos', 'tan', 'log'])
    math_triggers = ['calculate', 'compute', 'solve', 'eval', 'value of', 'calc']
    if is_math_query or has_typo_match(math_triggers, cutoff=0.75):
        try:
            expr=user_message.replace('^','**').replace('×','*').replace('x','*')
            allowed={'sqrt':math.sqrt,'sin':math.sin,'cos':math.cos,'tan':math.tan,'log':math.log10,'pi':math.pi,'e':math.e}
            def safe_eval(node):
                if isinstance(node,ast.Expression): return safe_eval(node.body)
                if isinstance(node,ast.Constant) and isinstance(node.value,(int,float)): return node.value
                if isinstance(node,ast.UnaryOp) and isinstance(node.op,(ast.UAdd,ast.USub)):
                    v=safe_eval(node.operand); return v if isinstance(node.op,ast.UAdd) else -v
                if isinstance(node,ast.BinOp) and isinstance(node.op,(ast.Add,ast.Sub,ast.Mult,ast.Div,ast.Pow,ast.Mod)):
                    a,b=safe_eval(node.left),safe_eval(node.right)
                    if isinstance(node.op,ast.Pow) and abs(b)>12: raise ValueError()
                    return {ast.Add:a.__add__,ast.Sub:a.__sub__,ast.Mult:a.__mul__,ast.Div:a.__truediv__,ast.Pow:a.__pow__,ast.Mod:a.__mod__}[type(node.op)](b)
                if isinstance(node,ast.Name) and node.id in allowed: return allowed[node.id]
                if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id in allowed and len(node.args)==1:
                    return allowed[node.func.id](safe_eval(node.args[0]))
                raise ValueError()
            filtered=re.sub(r'(?<![\w.])0+(\d+)',r'\1',expr)
            calc_result=safe_eval(ast.parse(filtered,mode='eval'))
            if not isinstance(calc_result,(int,float)) or not math.isfinite(calc_result): raise ValueError()
            response_text=f"🧮 Scientific calculation result for `{raw_message}` is **{calc_result}**."
        except Exception:
            pass

    # 2. Context-aware local Mr.White intelligence (no external API)
    if not response_text:
        conn = get_db_connection()
        me = conn.execute("SELECT username,fullname,role FROM users WHERE username=?", (session['user'],)).fetchone()
        if me:
            enrolled = conn.execute("""SELECT c.title,
                COUNT(cm.id) total_modules,
                SUM(CASE WHEN COALESCE(ump.completed,0)=1 THEN 1 ELSE 0 END) done
                FROM courses c JOIN enrollments e ON e.course_id=c.id
                LEFT JOIN course_modules cm ON cm.course_id=c.id
                LEFT JOIN user_module_progress ump ON ump.module_id=cm.id AND ump.username=?
                WHERE e.username=? GROUP BY c.id ORDER BY c.title""",(session['user'],session['user'])).fetchall()
            assignment = conn.execute("""SELECT ta.subject,COALESCE(u.fullname,u.username) trainer,ta.status
                FROM trainer_assignments ta JOIN users u ON u.username=ta.trainer_username
                WHERE ta.trainee_username=? ORDER BY ta.id DESC LIMIT 1""",(session['user'],)).fetchone()
            deadlines = conn.execute("""SELECT title,due_date FROM training_deadlines
                WHERE assigned_to=? AND status!='Completed' ORDER BY date(due_date) LIMIT 3""",(session['user'],)).fetchall()
            assessments = conn.execute("""SELECT c.title,MAX(ca.score) score
                FROM course_assessments ca JOIN courses c ON c.id=ca.course_id
                WHERE ca.username=? GROUP BY ca.course_id ORDER BY c.title""",(session['user'],)).fetchall()

            if any(k in user_message for k in ['what should i learn','learn next','next course','recommend','recommendation','learning path']):
                gaps=gap_analysis(conn,session['user'])
                weak=gaps.get('weak') or []
                if weak:
                    response_text=f"Your biggest current learning gap is **{weak[0]['subject']}** ({round(weak[0]['score'],1)}%). I recommend opening your personalized learning path next."
                elif enrolled:
                    incomplete=next((x for x in enrolled if int(x['done'] or 0)<int(x['total_modules'] or 0)),None)
                    response_text=f"You are progressing well. I recommend continuing with **{incomplete['title']}**." if incomplete else "You have completed your enrolled modules. Your next step is to review assessments and advanced recommendations."
                else:
                    response_text="You are not enrolled in a course yet. Open the Course Catalog to start a capacity-building program."

            elif any(k in user_message for k in ['how am i doing','my progress','progress','performance']):
                if enrolled:
                    parts=[f"{x['title']}: {int(x['done'] or 0)}/{int(x['total_modules'] or 0)} modules" for x in enrolled]
                    response_text="Here is your current progress: " + "; ".join(parts) + "."
                else:
                    response_text="You do not have any course enrollments yet, so there is no course progress to report."

            elif any(k in user_message for k in ['who is my trainer','my trainer','trainer assigned']):
                response_text=(f"Your latest trainer assignment is **{assignment['trainer']}** for **{assignment['subject']}** ({assignment['status']})."
                               if assignment else "You do not have a trainer assignment yet. I can help you open Trainer Matching.")

            elif any(k in user_message for k in ['course','courses']) and any(k in user_message for k in ['available','offer','have','list']):
                courses=conn.execute("SELECT title,level,category FROM courses ORDER BY title LIMIT 8").fetchall()
                response_text="Available courses: " + "; ".join(f"{c['title']} ({c['level']})" for c in courses) + "."

            elif any(k in user_message for k in ['deadline','due','due date','complete soon']):
                response_text=("Upcoming deadlines: " + "; ".join(f"{d['title']} — {d['due_date']}" for d in deadlines) + "."
                               if deadlines else "You have no upcoming training deadlines recorded.")

            elif any(k in user_message for k in ['certificate','certification']) and any(k in user_message for k in ['can i','eligible','get','my']):
                certs=conn.execute("""SELECT c.title,MAX(ca.score) score
                    FROM course_assessments ca JOIN courses c ON c.id=ca.course_id
                    WHERE ca.username=? AND ca.passed=1 GROUP BY ca.course_id""",(session['user'],)).fetchall()
                completed=[x for x in enrolled if int(x['total_modules'] or 0)==int(x['done'] or 0)]
                if completed and certs:
                    response_text="You appear to have passed at least one course assessment. Open that course and use the Certificate action; eligibility is checked again by the server."
                else:
                    response_text="Certificate eligibility requires enrollment, completion of all course modules and a passing course assessment."

            elif any(k in user_message for k in ['what is competency','competency assessment','skill gap','competency']):
                gaps=gap_analysis(conn,session['user'])
                weak=gaps.get('weak') or []
                response_text=(f"Your current weakest competency area is **{weak[0]['subject']}** at {round(weak[0]['score'],1)}%. A competency assessment helps measure these areas and drives personalized learning."
                               if weak else "Competency assessments measure your skills by subject and help the platform identify learning gaps.")

            elif any(k in user_message for k in ['my notifications','notification']):
                unread=conn.execute("SELECT COUNT(*) FROM notifications WHERE username=? AND is_read=0",(session['user'],)).fetchone()[0]
                response_text=f"You currently have **{unread} unread notification(s)**. Open Notifications for the full list."

            # FAM additive: if none of the precise deterministic intents above matched,
            # hand the question to Groq — grounded in the exact same live data just
            # queried above, so it can chat naturally without inventing platform facts.
            if not response_text and ai_is_enabled():
                try:
                    gaps_ctx = gap_analysis(conn, session['user'])
                except Exception:
                    gaps_ctx = None
                ctx_block = build_context_block(dict(me), [dict(r) for r in enrolled],
                                                 dict(assignment) if assignment else None,
                                                 [dict(r) for r in deadlines],
                                                 [dict(r) for r in assessments], gaps_ctx)
                history = _mrwhite_recent_history(session['user'])
                ai_reply = ask_mr_white(raw_message, ctx_block, history)
                if ai_reply:
                    response_text = ai_reply.strip()

        conn.close()

    # 3. Human-like Conversational & Gen-Z Slang Patterns with Typo Tolerance
    if not response_text:
        greeting_triggers = ['hello', 'hi', 'hey', 'greetings', 'sup', 'yo', 'wassup', 'whatsup']
        laugh_triggers = ['lol', 'lmao', 'rofl', 'haha', 'lmfao']
        time_triggers = ['time', 'clock', 'hour']
        date_triggers = ['date', 'day', 'today', 'calendar']
        identity_triggers = ['who', 'name', 'what', 'mr.white', 'bot', 'assistant']

        if has_typo_match(greeting_triggers, cutoff=0.7):
            response_text = "Yo! What's good? I'm Mr.White, your personal AI collaborator. Ready to flex on your project tasks or crunch some numbers!"
        
        elif 'how' in user_message and ('u' in user_message or 'you' in user_message or 'doin' in user_message or 'hru' in user_message or 'whats' in user_message):
            response_text = "I'm literally doing amazing, just chillin' in the backend waiting to help you out. How are things on your end?"
        
        elif has_typo_match(laugh_triggers, cutoff=0.75):
            response_text = "Dead 💀😂 No for real though, let me know if you need anything else for your project!"

        elif has_typo_match(time_triggers, cutoff=0.8):
            current_time = datetime.now().strftime("%I:%M %p")
            response_text = f"Rn it's right around {current_time}. Time flies when you're building cool stuff!"
            
        elif has_typo_match(date_triggers, cutoff=0.8):
            current_date = datetime.now().strftime("%A, %B %d, %Y")
            response_text = f"Today is {current_date}. Make it count!"
            
        elif has_typo_match(identity_triggers, cutoff=0.8):
            response_text = "I'm Mr.White—your AI assistant built right into PathSurfers to keep things running smoothly!"

        else:
            response_text = f"My bad, I didn't quite catch that typo-heavy phrasing ('{raw_message}'). Try asking me to calculate something, check the time, or ask about your project modules!"

    # FAM additive: persist this turn to the active (or newly created) conversation
    # so chat history survives across page loads and can be browsed/resumed later.
    conv_id = _mrwhite_get_or_create_conversation(session['user'], data.get('conversation_id'), raw_message)
    conn = get_db_connection()
    conn.execute("INSERT INTO mrwhite_messages(conversation_id, role, content) VALUES(?,?,?)",
                 (conv_id, 'user', raw_message))
    conn.execute("INSERT INTO mrwhite_messages(conversation_id, role, content) VALUES(?,?,?)",
                 (conv_id, 'assistant', response_text))
    conn.execute("UPDATE mrwhite_conversations SET updated_at=CURRENT_TIMESTAMP WHERE id=?", (conv_id,))
    conn.commit()
    conn.close()

    return jsonify({'status': 'success', 'response': response_text, 'conversation_id': conv_id, 'ai_powered': ai_is_enabled()})

def _mrwhite_get_or_create_conversation(username, requested_id, first_message):
    """Returns a conversation id owned by `username`: the requested one if valid,
    else the most recently updated one, else a freshly created conversation."""
    conn = get_db_connection()
    try:
        if requested_id:
            row = conn.execute("SELECT id FROM mrwhite_conversations WHERE id=? AND username=?",
                                (requested_id, username)).fetchone()
            if row:
                return row['id']
        row = conn.execute(
            "SELECT id FROM mrwhite_conversations WHERE username=? ORDER BY updated_at DESC LIMIT 1",
            (username,)).fetchone()
        if row:
            return row['id']
        title = (first_message or 'New chat').strip()[:60] or 'New chat'
        cur = conn.execute("INSERT INTO mrwhite_conversations(username, title) VALUES(?,?)", (username, title))
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()

def _mrwhite_recent_history(username, limit=10):
    conn = get_db_connection()
    conv = conn.execute(
        "SELECT id FROM mrwhite_conversations WHERE username=? ORDER BY updated_at DESC LIMIT 1",
        (username,)).fetchone()
    if not conv:
        conn.close()
        return []
    rows = conn.execute(
        "SELECT role, content FROM mrwhite_messages WHERE conversation_id=? ORDER BY id DESC LIMIT ?",
        (conv['id'], limit)).fetchall()
    conn.close()
    return [dict(r) for r in reversed(rows)]

@app.route('/api/chat/conversations', methods=['GET'])
def api_chat_conversations():
    if 'user' not in session:
        return jsonify({'status': 'error', 'message': 'Unauthorized'}), 401
    conn = get_db_connection()
    rows = conn.execute(
        "SELECT id, title, updated_at FROM mrwhite_conversations WHERE username=? ORDER BY updated_at DESC LIMIT 50",
        (session['user'],)).fetchall()
    conn.close()
    return jsonify({'status': 'success', 'conversations': [dict(r) for r in rows]})

@app.route('/api/chat/conversations/new', methods=['POST'])
def api_chat_new_conversation():
    if 'user' not in session:
        return jsonify({'status': 'error', 'message': 'Unauthorized'}), 401
    conn = get_db_connection()
    cur = conn.execute("INSERT INTO mrwhite_conversations(username, title) VALUES(?, 'New chat')", (session['user'],))
    conn.commit()
    new_id = cur.lastrowid
    conn.close()
    return jsonify({'status': 'success', 'conversation_id': new_id})

@app.route('/api/chat/conversations/<int:conv_id>', methods=['GET'])
def api_chat_conversation_messages(conv_id):
    if 'user' not in session:
        return jsonify({'status': 'error', 'message': 'Unauthorized'}), 401
    conn = get_db_connection()
    owns = conn.execute("SELECT id FROM mrwhite_conversations WHERE id=? AND username=?",
                         (conv_id, session['user'])).fetchone()
    if not owns:
        conn.close()
        return jsonify({'status': 'error', 'message': 'Not found'}), 404
    rows = conn.execute(
        "SELECT role, content, created_at FROM mrwhite_messages WHERE conversation_id=? ORDER BY id ASC",
        (conv_id,)).fetchall()
    conn.close()
    return jsonify({'status': 'success', 'messages': [dict(r) for r in rows]})



# ==================== PathSurfers ADDITIVE ENHANCEMENTS ====================

@app.route('/competency-center')
@login_required
def competency_center():
    conn=get_db_connection()
    data=gap_analysis(conn,session['user'])
    history=conn.execute("""SELECT ca.id,ca.assessment_type,ca.completed_at,cs.subject,cs.score
                            FROM competency_assessments ca JOIN competency_scores cs ON cs.assessment_id=ca.id
                            WHERE ca.username=? ORDER BY ca.id DESC,cs.subject""",(session['user'],)).fetchall()
    conn.close()
    return render_template('competency_center.html',data=data,history=history)

@app.route('/assessment-bank')
@login_required
def assessment_bank():
    subject=request.args.get('subject','').strip()
    conn=get_db_connection()
    subjects=[r['subject'] for r in conn.execute("SELECT DISTINCT subject FROM questions WHERE active=1 ORDER BY subject")]
    questions=get_question_set(conn,subject or None,10)
    for q in questions: q['options']=question_options(conn,q['id'])
    conn.close()
    return render_template('assessment_bank.html',questions=questions,subjects=subjects,selected=subject)

@app.route('/assessment/<int:course_id>',methods=['GET','POST'])
@login_required
def course_assessment(course_id):
    conn=get_db_connection()
    course=conn.execute("SELECT * FROM courses WHERE id=?",(course_id,)).fetchone()
    enrolled=conn.execute("SELECT 1 FROM enrollments WHERE username=? AND course_id=?",(session['user'],course_id)).fetchone()
    if not course or not enrolled:
        conn.close(); flash('Enroll in this course before taking its assessment.'); return redirect(url_for('courses'))
    assessment_session_key = f"assessment_questions_{course_id}"
    submitted_key = f"assessment_submitted_{course_id}"
    if request.method=='POST':
        if session.get(submitted_key):
            conn.close(); flash('This assessment attempt has already been submitted. Reopen the assessment to start a new attempt.')
            return redirect(url_for('course_detail', course_id=course_id))
        try:
            ids=[int(x) for x in request.form.getlist('question_id')]
        except (TypeError, ValueError):
            conn.close(); flash('Invalid assessment submission.'); return redirect(url_for('course_assessment', course_id=course_id))
        official_ids=session.get(assessment_session_key, [])
        if not official_ids or sorted(set(ids)) != sorted(official_ids) or len(ids) != len(official_ids):
            conn.close(); flash('Assessment question set could not be verified. Please reopen the assessment.')
            return redirect(url_for('course_assessment', course_id=course_id))
        total=len(ids); correct=0
        for qid in ids:
            opt=request.form.get(f'q_{qid}')
            row=conn.execute("SELECT is_correct FROM question_options WHERE id=? AND question_id=?",(opt,qid)).fetchone() if opt else None
            if row and row['is_correct']: correct+=1
        score=round(correct*100/total,1) if total else 0
        passed=1 if score>=70 else 0
        cur_attempt=conn.execute("INSERT INTO assessment_attempts(username,assessment_type,subject,total_questions,correct_answers,score) VALUES(?,?,?,?,?,?)",
                                 (session['user'],f'Course assessment: {course["title"]}',course['category'],total,correct,score))
        attempt_id=cur_attempt.lastrowid
        for qid in ids:
            opt=request.form.get(f'q_{qid}')
            row=conn.execute("SELECT is_correct FROM question_options WHERE id=? AND question_id=?",(opt,qid)).fetchone() if opt else None
            conn.execute("INSERT INTO assessment_answers(attempt_id,question_id,selected_option_id,is_correct) VALUES(?,?,?,?)",
                         (attempt_id,qid,int(opt) if opt and opt.isdigit() else None,int(bool(row and row['is_correct']))))
        conn.execute("INSERT INTO course_assessments(username,course_id,score,passed,total_questions) VALUES(?,?,?,?,?)",
                     (session['user'],course_id,score,passed,total))
        record_assessment(conn,session['user'],f'Course assessment: {course["title"]}',{course['category']:score},total,correct)
        notify(conn,session['user'],'Assessment result',f'{course["title"]}: {score}%'+(' — passed.' if passed else ' — retake recommended.'),'assessment')
        log_action(conn,session['user'],'assessment_completion',f'Course {course_id}; score {score}')
        conn.commit(); conn.close()
        session[submitted_key] = True
        session.modified = True
        flash(f'Assessment submitted: {score}%.')
        return redirect(url_for('course_detail',course_id=course_id))
    questions=get_question_set(conn,course['category'],5)
    if len(questions)<3: questions=get_question_set(conn,None,5)
    for q in questions: q['options']=question_options(conn,q['id'])
    session[assessment_session_key] = [int(q['id']) for q in questions]
    session.pop(submitted_key, None)
    session.modified = True
    conn.close()
    # PORTAL additive: kiosk-mode time limit, derived (not stored) — 2 min/question, 5 min floor.
    time_limit_minutes = max(5, len(questions) * 2)
    return render_template('course_assessment.html',course=course,questions=questions,
                            time_limit_minutes=time_limit_minutes)

@app.route('/assessment/<int:course_id>/violation', methods=['POST'])
@login_required
def course_assessment_violation(course_id):
    """PORTAL additive: best-effort anti-cheat logging for kiosk-mode exams.
    Uses the existing audit_logs table only — no schema change, never blocks the exam."""
    try:
        conn = get_db_connection()
        kind = (request.get_json(silent=True) or {}).get('type', 'focus_loss')
        log_action(conn, session['user'], 'assessment_violation', f'Course {course_id}: {kind}')
        conn.commit(); conn.close()
    except Exception:
        pass
    return jsonify(status='logged')

@app.route('/trainer')
@login_required
def trainer_dashboard():
    if session.get('role') == 'Trainee':
        flash('Trainer Workshop is available only to authorized non-trainee roles.')
        return redirect(url_for('home'))
    conn=get_db_connection()
    profile=conn.execute("""SELECT tp.*,COALESCE(u.fullname,u.username) fullname,u.role FROM trainer_profiles tp
                            JOIN users u ON u.username=tp.username WHERE tp.username=?""",(session['user'],)).fetchone()
    assignments=conn.execute("""SELECT ta.*,COALESCE(u.fullname,u.username) trainee_name
                                FROM trainer_assignments ta JOIN users u ON u.username=ta.trainee_username
                                WHERE ta.trainer_username=? ORDER BY ta.id DESC""",(session['user'],)).fetchall()
    perf=conn.execute("""SELECT COUNT(*) assignments,
        ROUND(AVG(tf.rating),2) feedback,
        ROUND(AVG(ca.score),2) trainee_scores
        FROM trainer_assignments ta
        LEFT JOIN trainer_feedback tf ON tf.trainer_username=ta.trainer_username
        LEFT JOIN course_assessments ca ON ca.username=ta.trainee_username
        WHERE ta.trainer_username=?""",(session['user'],)).fetchone()
    conn.close()
    return render_template('trainer.html',profile=profile,assignments=assignments,perf=perf)

@app.route('/trainer/profile',methods=['GET','POST'])
@login_required
def trainer_profile():
    if session.get('role')=='Trainee':
        return redirect(url_for('home'))
    conn=get_db_connection()
    if request.method=='POST':
        f=request.form
        conn.execute("""INSERT INTO trainer_profiles(username,designation,organization,qualification,experience_years,bio,specialization,availability_status)
                        VALUES(?,?,?,?,?,?,?,?)
                        ON CONFLICT(username) DO UPDATE SET designation=excluded.designation,organization=excluded.organization,
                        qualification=excluded.qualification,experience_years=excluded.experience_years,bio=excluded.bio,
                        specialization=excluded.specialization,availability_status=excluded.availability_status""",
                     (session['user'],f.get('designation',''),f.get('organization',''),f.get('qualification',''),
                      float(f.get('experience_years') or 0),f.get('bio','')[:1000],f.get('specialization','')[:500],
                      f.get('availability_status','Available')))
        for subject in [x.strip() for x in f.get('expertise','').split(',') if x.strip()]:
            conn.execute("INSERT OR IGNORE INTO trainer_expertise(trainer_username,subject,topic,skill_level) VALUES(?,?,?,?)",
                         (session['user'],subject,'General',f.get('skill_level','Intermediate')))
        conn.execute("""INSERT INTO trainer_questionnaires(trainer_username,teaching_experience,technical_expertise,subjects_handled,
                        preferred_trainee_level,training_methodology,available_hours,certifications,research_interests,practical_expertise)
                        VALUES(?,?,?,?,?,?,?,?,?,?)
                        ON CONFLICT(trainer_username) DO UPDATE SET teaching_experience=excluded.teaching_experience,
                        technical_expertise=excluded.technical_expertise,subjects_handled=excluded.subjects_handled,
                        preferred_trainee_level=excluded.preferred_trainee_level,training_methodology=excluded.training_methodology,
                        available_hours=excluded.available_hours,certifications=excluded.certifications,
                        research_interests=excluded.research_interests,practical_expertise=excluded.practical_expertise,updated_at=CURRENT_TIMESTAMP""",
                     (session['user'],f.get('teaching_experience',''),f.get('technical_expertise',''),f.get('subjects_handled',''),
                      f.get('preferred_trainee_level',''),f.get('training_methodology',''),f.get('available_hours',''),
                      f.get('certifications',''),f.get('research_interests',''),f.get('practical_expertise','')))
        conn.execute("INSERT INTO approvals(entity_type,entity_id,requested_by,status,reason) VALUES(?,?,?,?,?)",
                     ('Trainer profile',session['user'],'Trainer profile update','Pending','Profile change requires administrator review.'))
        conn.commit(); conn.close(); flash('Trainer profile updated and submitted for approval.'); return redirect(url_for('trainer_profile'))
    profile=conn.execute("SELECT * FROM trainer_profiles WHERE username=?",(session['user'],)).fetchone()
    questionnaire=conn.execute("SELECT * FROM trainer_questionnaires WHERE trainer_username=?",(session['user'],)).fetchone()
    expertise=conn.execute("SELECT * FROM trainer_expertise WHERE trainer_username=?",(session['user'],)).fetchall()
    conn.close()
    return render_template('trainer_profile.html',profile=profile,questionnaire=questionnaire,expertise=expertise)

@app.route('/trainer-matching')
@login_required
def trainer_matching():
    subject=request.args.get('subject','').strip()
    conn=get_db_connection()
    gaps=gap_analysis(conn,session['user'])
    subjects=[r['subject'] for r in gaps['weak']] or [r['subject'] for r in gaps['scores']]
    subject=subject or (subjects[0] if subjects else '')
    matches=match_trainers_for_trainee_enhanced(conn,session['user'],subject) if subject else []
    conn.close()
    return render_template('trainer_matching.html',matches=matches,subject=subject,subjects=subjects)

@app.route('/trainer-matching/assign/<trainer_username>',methods=['POST'])
@login_required
def assign_trainer(trainer_username):
    subject=request.form.get('subject','').strip()
    conn=get_db_connection()
    matches=match_trainers_for_trainee_enhanced(conn,session['user'],subject)
    match=next((m for m in matches if m['username']==trainer_username),None)
    if not match:
        conn.close(); flash('Trainer is not eligible for this subject.'); return redirect(url_for('trainer_matching',subject=subject))
    reason=match['reason']
    conn.execute("""INSERT INTO trainer_assignments(trainer_username,trainee_username,subject,reason,match_score,status)
                    VALUES(?,?,?,?,?,'Recommended')""",(trainer_username,session['user'],subject,reason,match['match_score']))
    notify(conn,trainer_username,'New trainee recommendation',
           f"{session['user']} has been matched to you for {subject} ({match['match_score']}% match).",'assignment')
    notify(conn,session['user'],'Trainer recommendation',
           f"{trainer_username} matched at {match['match_score']}% for {subject}.",'assignment')
    log_action(conn,session['user'],'trainer_assignment',f'{trainer_username}; {subject}; {match["match_score"]}%')
    conn.commit(); conn.close(); flash('Trainer recommendation created.'); return redirect(url_for('trainer_matching',subject=subject))

@app.route('/trainer-assignment/<int:assignment_id>/<action>',methods=['POST'])
@login_required
def update_assignment(assignment_id,action):
    if action not in ('accept','reject','complete'): return ('Invalid action',400)
    conn=get_db_connection()
    a=conn.execute("SELECT * FROM trainer_assignments WHERE id=?",(assignment_id,)).fetchone()
    if not a or a['trainer_username']!=session['user']:
        conn.close(); return ('Forbidden',403)
    status={'accept':'Accepted','reject':'Rejected','complete':'Completed'}[action]
    conn.execute("UPDATE trainer_assignments SET status=? WHERE id=?",(status,assignment_id))
    notify(conn,a['trainee_username'],'Trainer assignment updated',f'Assignment status: {status}.','assignment')
    log_action(conn,session['user'],status.lower(),f'Assignment {assignment_id}')
    conn.commit(); conn.close(); return redirect(url_for('trainer_dashboard'))

@app.route('/learning-path')
@login_required
def learning_path():
    conn=get_db_connection()
    path=conn.execute("SELECT * FROM learning_paths WHERE username=? ORDER BY id DESC LIMIT 1",(session['user'],)).fetchone()
    items=conn.execute("SELECT * FROM learning_path_items WHERE path_id=? ORDER BY sequence_no",(path['id'],)).fetchall() if path else []
    gaps=gap_analysis(conn,session['user'])
    conn.close()
    return render_template('learning_path.html',path=path,items=items,gaps=gaps)

@app.route('/learning-path/generate',methods=['POST'])
@login_required
def generate_learning_path():
    conn=get_db_connection()
    gaps=gap_analysis(conn,session['user'])
    weak=gaps['weak'] or gaps['scores']
    conn.execute("UPDATE learning_paths SET status='Archived' WHERE username=? AND status='Active'",(session['user'],))
    cur=conn.execute("INSERT INTO learning_paths(username,title) VALUES(?,?)",(session['user'],"Personalized Competency Recovery Path"))
    pid=cur.lastrowid; seq=1
    for gap in weak[:3]:
        course=conn.execute("SELECT * FROM courses WHERE lower(category)=lower(?) LIMIT 1",(gap['subject'],)).fetchone()
        if course:
            conn.execute("INSERT INTO learning_path_items(path_id,item_type,item_id,title,sequence_no) VALUES(?,?,?,?,?)",
                         (pid,'Course',course['id'],course['title'],seq)); seq+=1
            module=conn.execute("SELECT * FROM course_modules WHERE course_id=? ORDER BY order_index LIMIT 1",(course['id'],)).fetchone()
            if module:
                conn.execute("INSERT INTO learning_path_items(path_id,item_type,item_id,title,sequence_no) VALUES(?,?,?,?,?)",
                             (pid,'Module',module['id'],module['title'],seq)); seq+=1
            resource=conn.execute("SELECT r.id,r.title FROM repository r WHERE lower(r.category)=lower(?) ORDER BY r.id DESC LIMIT 1",(gap['subject'],)).fetchone()
            if resource:
                conn.execute("INSERT INTO learning_path_items(path_id,item_type,item_id,title,sequence_no) VALUES(?,?,?,?,?)",
                             (pid,'Resource',resource['id'],resource['title'],seq)); seq+=1
            conn.execute("INSERT INTO learning_path_items(path_id,item_type,item_id,title,sequence_no,status) VALUES(?,?,?,?,?,?)",
                         (pid,'Assessment',course['id'],f'{course["title"]} assessment',seq,'Recommended')); seq+=1
            matches=match_trainers_for_trainee_enhanced(conn,session['user'],gap['subject'])
            if matches:
                conn.execute("INSERT INTO learning_path_items(path_id,item_type,item_id,title,sequence_no,status) VALUES(?,?,?,?,?,?)",
                             (pid,'Trainer',None,f'{matches[0]["fullname"]} ({matches[0]["match_score"]}% match)',seq,'Recommended')); seq+=1
    conn.commit(); conn.close(); flash('Personalized learning path generated from your stored competency gaps.')
    return redirect(url_for('learning_path'))

@app.route('/feedback',methods=['GET','POST'])
@login_required
def feedback():
    conn=get_db_connection()
    current=session['user']
    if request.method=='POST':
        rating=int(request.form.get('rating','0') or 0)
        comments=request.form.get('comments','')[:1000]
        kind=request.form.get('kind','course')
        if not 1<=rating<=5:
            conn.close(); flash('Rating must be between 1 and 5.'); return redirect(url_for('feedback'))
        if kind=='trainer':
            trainer=request.form.get('trainer_username','').strip()
            if not trainer or trainer == current:
                conn.close(); flash('You cannot give feedback to yourself.'); return redirect(url_for('feedback'))
            target=conn.execute("SELECT username,role FROM users WHERE username=?", (trainer,)).fetchone()
            if not target or target['role'] in ('Trainee','Administrator'):
                conn.close(); flash('That user is not an eligible feedback recipient.'); return redirect(url_for('feedback'))
            relationship = conn.execute("""SELECT 1 FROM messages
                                           WHERE (sender_username=? AND receiver_username=?)
                                              OR (sender_username=? AND receiver_username=?)
                                           LIMIT 1""",(current,trainer,trainer,current)).fetchone()
            assignment = conn.execute("""SELECT 1 FROM trainer_assignments
                                         WHERE trainer_username=? AND trainee_username=? LIMIT 1""",(trainer,current)).fetchone()
            leader_link = conn.execute("""SELECT 1 FROM users u
                                          JOIN users me ON me.username=?
                                          WHERE u.username=? AND me.leader_ref_code IS NOT NULL
                                            AND u.ref_code=me.leader_ref_code LIMIT 1""",(current,trainer)).fetchone()
            if not (relationship or assignment or leader_link):
                conn.close(); flash('You can only review someone you have interacted with or been assigned to.'); return redirect(url_for('feedback'))
            course_id=request.form.get('course_id') or None
            conn.execute("INSERT INTO trainer_feedback(trainee_username,trainer_username,course_id,rating,comments) VALUES(?,?,?,?,?)",
                         (current,trainer,course_id,rating,comments))
            notify(conn,trainer,'New feedback',f'You received a {rating}/5 rating.','feedback')
        else:
            try: course_id=int(request.form.get('course_id'))
            except (TypeError,ValueError):
                conn.close(); flash('Please select a valid enrolled course.'); return redirect(url_for('feedback'))
            enrolled=conn.execute("SELECT 1 FROM enrollments WHERE username=? AND course_id=?",(current,course_id)).fetchone()
            if not enrolled:
                conn.close(); flash('You can only review a course you are enrolled in.'); return redirect(url_for('feedback'))
            module_id=request.form.get('module_id') or None
            conn.execute("INSERT INTO course_feedback(trainee_username,course_id,module_id,rating,comments) VALUES(?,?,?,?,?)",
                         (current,course_id,module_id,rating,comments))
        log_action(conn,current,'feedback_submitted',f'{kind} feedback submitted')
        conn.commit(); conn.close(); flash('Feedback recorded. Thank you.'); return redirect(url_for('feedback'))

    courses=conn.execute("SELECT c.* FROM courses c JOIN enrollments e ON e.course_id=c.id WHERE e.username=? ORDER BY c.title",(current,)).fetchall()
    trainers=conn.execute("""SELECT DISTINCT u.username,COALESCE(u.fullname,u.username) name,
                             CASE
                               WHEN EXISTS(SELECT 1 FROM trainer_assignments ta WHERE ta.trainer_username=u.username AND ta.trainee_username=?) THEN 'Assigned trainer'
                               WHEN EXISTS(SELECT 1 FROM messages m WHERE (m.sender_username=? AND m.receiver_username=u.username) OR (m.sender_username=u.username AND m.receiver_username=?)) THEN 'Chat interaction'
                               WHEN EXISTS(SELECT 1 FROM users me WHERE me.username=? AND me.leader_ref_code=u.ref_code) THEN 'Assigned leader'
                             END relationship
                             FROM users u
                             WHERE u.role NOT IN ('Trainee','Administrator')
                               AND u.username<>?
                               AND (
                                 EXISTS(SELECT 1 FROM trainer_assignments ta WHERE ta.trainer_username=u.username AND ta.trainee_username=?)
                                 OR EXISTS(SELECT 1 FROM messages m WHERE (m.sender_username=? AND m.receiver_username=u.username) OR (m.sender_username=u.username AND m.receiver_username=?))
                                 OR EXISTS(SELECT 1 FROM users me WHERE me.username=? AND me.leader_ref_code=u.ref_code)
                               )
                             ORDER BY name""",
                          (current,current,current,current,current,current,current,current,current)).fetchall()
    conn.close(); return render_template('feedback.html',courses=courses,trainers=trainers)

@app.route('/notifications')
@login_required
def notifications_page():
    conn=get_db_connection()
    due=conn.execute("SELECT * FROM training_deadlines WHERE assigned_to=? AND status!='Completed' AND date(due_date) <= date('now','+7 day')",
                     (session['user'],)).fetchall()
    for d in due:
        exists=conn.execute("SELECT 1 FROM notifications WHERE username=? AND notification_type='deadline' AND message LIKE ? LIMIT 1",
                            (session['user'],f'%{d["title"]}%')).fetchone()
        if not exists: notify(conn,session['user'],'Upcoming deadline',f'{d["title"]} is due on {d["due_date"]}.','deadline')
    conn.commit()
    rows=conn.execute("SELECT * FROM notifications WHERE username=? ORDER BY id DESC",(session['user'],)).fetchall()
    conn.execute("UPDATE notifications SET is_read=1 WHERE username=?",(session['user'],)); conn.commit(); conn.close()
    return render_template('notifications.html',notifications=rows)

@app.route('/verify_certificate/<verification_code>')
def verify_certificate(verification_code):
    conn=get_db_connection()
    cert=conn.execute("""SELECT c.*,co.title course_title FROM certificates c JOIN courses co ON co.id=c.course_id
                         WHERE c.verification_code=? AND c.status='Issued'""",(verification_code,)).fetchone()
    conn.close()
    sig = certificate_signature(cert['certificate_id'], cert['verification_code'], cert['username'], cert['course_id']) if cert else None
    return render_template('verify_certificate.html',certificate=cert, cert_signature=sig)

@app.route('/approvals')
@role_required('Administrator', 'Leader')
def approvals():
    conn=get_db_connection(); rows=conn.execute("SELECT * FROM approvals ORDER BY id DESC").fetchall()
    conn.close(); return render_template('approvals.html',approvals=rows)

@app.route('/approvals/<int:approval_id>/<action>',methods=['POST'])
@role_required('Administrator', 'Leader')
def review_approval(approval_id,action):
    if action not in ('approve','reject'): return ('Invalid action',400)
    status='Approved' if action=='approve' else 'Rejected'
    conn=get_db_connection()
    row=conn.execute("SELECT * FROM approvals WHERE id=?",(approval_id,)).fetchone()
    if not row: conn.close(); return ('Not found',404)
    conn.execute("UPDATE approvals SET status=?,reviewed_by=?,reviewed_at=CURRENT_TIMESTAMP WHERE id=?",
                 (status,session['user'],approval_id))
    notify(conn,row['requested_by'],'Approval reviewed',f'Your {row["entity_type"]} request was {status.lower()}.','approval')
    log_action(conn,session['user'],action,f'Approval {approval_id}')
    conn.commit(); conn.close(); return redirect(url_for('approvals'))

@app.route('/control-center')
@app.route('/sih-control')
@role_required('Administrator', 'Leader')
def sih_control():
    conn=get_db_connection(); metrics=dashboard_metrics(conn)
    gap_rows=[]
    for rr in conn.execute("""SELECT c.category,COUNT(cm.id) total,COALESCE(SUM(CASE WHEN p.completed=1 THEN 1 ELSE 0 END),0) done
        FROM courses c JOIN enrollments e ON e.course_id=c.id LEFT JOIN course_modules cm ON cm.course_id=c.id
        LEFT JOIN user_module_progress p ON p.username=e.username AND p.module_id=cm.id GROUP BY c.category""").fetchall():
        total=int(rr['total'] or 0); done=int(rr['done'] or 0); pct=(done*100/total) if total else 0
        a=conn.execute("SELECT AVG(score) score,COUNT(*) attempts FROM course_assessments ca JOIN courses c ON c.id=ca.course_id WHERE c.category=?",(rr['category'],)).fetchone()
        score=round((pct+float(a['score']))/2,1) if a['score'] is not None else round(pct,1)
        gap_rows.append({'subject':rr['category'],'avg_score':score,'attempts':int(a['attempts'] or 0)})
    gaps=sorted(gap_rows,key=lambda x:x['avg_score'])[:12]
    trainers=conn.execute("""SELECT tp.username,tp.performance_score,tp.availability_status,
                             COUNT(ta.id) workload FROM trainer_profiles tp
                             LEFT JOIN trainer_assignments ta ON ta.trainer_username=tp.username AND ta.status IN ('Pending','Accepted','Active')
                             GROUP BY tp.username ORDER BY tp.performance_score DESC""").fetchall()
    # PORTAL additive: deeper analytics for the same control center, read-only queries only.
    dist = score_distribution(conn)
    prate = pass_rate(conn)
    board = leaderboard(conn, 10)
    weak_qs = question_accuracy(conn, 10)
    conn.close()
    return render_template('sih_control.html', metrics=metrics, gaps=gaps, trainers=trainers,
                            dist=dist, prate=prate, board=board, weak_qs=weak_qs)

@app.route('/control-center/export.csv')
@app.route('/sih-control/export.csv')
@role_required('Administrator', 'Leader')
def sih_control_export_csv():
    import csv, io
    conn = get_db_connection()
    rows = leaderboard(conn, 1000)
    conn.close()
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(['Rank', 'Name', 'Username', 'Average Score (%)', 'Attempts'])
    for i, r in enumerate(rows, 1):
        writer.writerow([i, r['name'], r['username'], r['avg_score'], r['attempts']])
    mem = io.BytesIO(buf.getvalue().encode('utf-8'))
    return send_file(mem, mimetype='text/csv', as_attachment=True, download_name='trainee_leaderboard.csv')

@app.route('/repository/delete/<int:doc_id>',methods=['POST'])
@role_required('Administrator','Leader','Non-Reliable User')
def delete_repository_resource(doc_id):
    conn=get_db_connection()
    if not conn.execute("SELECT 1 FROM repository WHERE id=?",(doc_id,)).fetchone():
        conn.close(); flash('Resource not found.'); return redirect(url_for('repository'))
    conn.execute("DELETE FROM repository WHERE id=?",(doc_id,))
    log_action(conn,session['user'],'repository_addition',f'Deleted repository resource {doc_id}')
    conn.commit(); conn.close(); flash('Resource deleted.'); return redirect(url_for('repository'))

@app.route('/health')
def health():
    conn=get_db_connection()
    tables=conn.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'").fetchone()[0]
    conn.close(); return jsonify({"status":"ok","database_tables":tables,"ai_provider":os.environ.get("AI_PROVIDER","none")})

@app.route('/webinars')
@login_required
def webinars():
    conn=get_db_connection(); rows=conn.execute("SELECT * FROM webinars ORDER BY scheduled_time").fetchall(); conn.close()
    return render_template('webinars.html',webinars=rows)

@app.route('/emergency-drills')
@login_required
def emergency_drills():
    conn=get_db_connection(); rows=conn.execute("SELECT * FROM emergency_drills WHERE username=? ORDER BY id DESC",(session['user'],)).fetchall(); conn.close()
    return render_template('emergency_drills.html',drills=rows)

# Additive Cristiano integration is registered after all original routes/services.
from enhancements import install_enhancements
install_enhancements(app)
from ghee_enhancements import install_ghee
install_ghee(app)

# PathSurfers OK additive layer: messaging, analytics UI, and local Mr.White intelligence.
from ok_chat_enhancements import install_ok_layer
install_ok_layer(app)
# Unified PathSurfers career-roadmapping layer (static PathForge + server-side Groq APIs).
from pathforge_api import install_pathforge
install_pathforge(app)
# FAM is the final compatibility layer and must be installed so its Mr.White, AI quiz,
# recommendations, competency sync, and course routes are active in the unified product.
from fam_enhancements import install_fam
install_fam(app)

if __name__ == '__main__':
    app.run(
        debug=os.environ.get('FLASK_DEBUG', '0') == '1',
        host=os.environ.get('FLASK_HOST', '127.0.0.1'),
        port=int(os.environ.get('PORT', '5000'))
    )
