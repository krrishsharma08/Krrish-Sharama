"""PathSurfers FAM additive final layer.

All changes are additive: existing tables/rows are not rewritten by this module.
It supersedes selected legacy UI/API handlers at request time so the original
implementation remains intact and available as a fallback/reference.
"""
import os, re, json, math, hashlib, secrets, urllib.request, urllib.error, html
from datetime import datetime, timedelta
from functools import wraps
from pathlib import Path
from flask import request, session, jsonify, render_template, redirect, url_for, flash, abort, send_file
from werkzeug.utils import secure_filename

# Load the project-local .env before any Groq availability checks.
def _load_project_env():
    env_path = Path(__file__).resolve().with_name(".env")
    if not env_path.exists():
        return
    try:
        for raw in env_path.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key:
                os.environ.setdefault(key, value)
    except OSError:
        pass

_load_project_env()

ROLES_CREATOR = {"Leader", "Non-Reliable User", "Administrator"}
AI_MODEL = os.environ.get("GROQ_MODEL", "openai/gpt-oss-120b")
GROQ_URL = os.environ.get("GROQ_BASE_URL", "https://api.groq.com/openai/v1/chat/completions")


def install_fam(app):
    root = Path(app.root_path)
    get_db = app.view_functions["home"].__globals__["get_db_connection"]
    record_assessment = app.view_functions["home"].__globals__["record_assessment"]
    gap_analysis = app.view_functions["home"].__globals__["gap_analysis"]
    eligibility = app.view_functions["home"].__globals__["eligibility"]
    issue = app.view_functions["home"].__globals__["issue"]
    log_action = app.view_functions["home"].__globals__["log_action"]
    notify = app.view_functions["home"].__globals__["notify"]

    def csrf_token():
        token = session.get("_csrf_token")
        if not token:
            token = secrets.token_urlsafe(32)
            session["_csrf_token"] = token
        return token

    def csrf_valid():
        supplied = request.form.get("_csrf_token") or request.headers.get("X-CSRF-Token")
        expected = session.get("_csrf_token")
        return bool(supplied and expected and secrets.compare_digest(str(supplied), str(expected)))

    def current():
        return session.get("user")

    def db():
        return get_db()

    def setup_schema():
        conn = db()
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS fam_login_rate_limits (
            identifier_hash TEXT PRIMARY KEY,
            attempts INTEGER NOT NULL DEFAULT 0,
            window_started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            locked_until DATETIME
        );
        CREATE TABLE IF NOT EXISTS fam_user_preferences (
            username TEXT PRIMARY KEY,
            display_name TEXT,
            theme TEXT NOT NULL DEFAULT 'light',
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS mrwhite_conversations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            title TEXT NOT NULL DEFAULT 'New chat',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(username) REFERENCES users(username) ON UPDATE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_mrw_conv_user_updated ON mrwhite_conversations(username,updated_at DESC);
        CREATE TABLE IF NOT EXISTS mrwhite_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            conversation_id INTEGER NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('user','assistant','system')),
            content TEXT NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(conversation_id) REFERENCES mrwhite_conversations(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_mrw_msg_conv ON mrwhite_messages(conversation_id,id);
        CREATE TABLE IF NOT EXISTS course_assets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            course_id INTEGER NOT NULL,
            module_id INTEGER,
            asset_type TEXT NOT NULL CHECK(asset_type IN ('pdf','photo','video')),
            filename TEXT NOT NULL,
            stored_name TEXT NOT NULL UNIQUE,
            mime_type TEXT NOT NULL,
            size_bytes INTEGER NOT NULL DEFAULT 0,
            created_by TEXT,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(course_id) REFERENCES courses(id) ON DELETE CASCADE,
            FOREIGN KEY(module_id) REFERENCES course_modules(id) ON DELETE SET NULL,
            FOREIGN KEY(created_by) REFERENCES users(username) ON DELETE SET NULL
        );
        CREATE INDEX IF NOT EXISTS idx_course_assets_course ON course_assets(course_id,created_at);
        CREATE TABLE IF NOT EXISTS emergency_drill_templates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            scenario TEXT NOT NULL,
            instructions TEXT,
            duration_seconds INTEGER NOT NULL DEFAULT 300,
            status TEXT NOT NULL DEFAULT 'Published',
            created_by TEXT,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS webinar_reminders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            webinar_id INTEGER NOT NULL,
            username TEXT NOT NULL,
            reminder_at DATETIME NOT NULL,
            UNIQUE(webinar_id,username),
            FOREIGN KEY(webinar_id) REFERENCES webinars(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS fam_ai_recommendations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            generated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            payload TEXT NOT NULL
        );
        """)
        conn.commit(); conn.close()

    setup_schema()

    @app.context_processor
    def fam_context():
        theme = "light"
        display_name = None
        if current():
            c = db()
            row = c.execute("SELECT display_name,theme FROM fam_user_preferences WHERE username=?", (current(),)).fetchone()
            c.close()
            if row:
                display_name, theme = row["display_name"], row["theme"]
        fam_assets=[]
        m=re.fullmatch(r"/course/(\d+)", request.path or "")
        if m and current():
            c=db(); fam_assets=[dict(r) for r in c.execute("SELECT * FROM course_assets WHERE course_id=? ORDER BY created_at,id",(int(m.group(1)),)).fetchall()]; c.close()
        return {"csrf_token": csrf_token, "fam_theme": theme, "fam_display_name": display_name, "fam_assets": fam_assets}

    def groq_call(messages, *, json_mode=False, temperature=0.35, max_tokens=2500, timeout=25):
        # Shared hardened client (User-Agent, model fallback, retries, timeouts).
        from services.groq_service import request_completion, parse_json
        text = request_completion(messages, json_mode=json_mode, temperature=temperature,
                                  max_tokens=max_tokens, timeout=timeout)
        return parse_json(text) if json_mode else text

    def ai_available():
        return bool(os.environ.get("GROQ_API_KEY", "").strip())

    def user_courses(conn, username):
        return conn.execute("""SELECT c.id,c.title,c.category,c.level,c.description
            FROM courses c JOIN enrollments e ON e.course_id=c.id WHERE e.username=? ORDER BY c.title""", (username,)).fetchall()

    def course_context(conn, course_ids=None, username=None, limit=12):
        params=[]; where=""
        if course_ids:
            ph=','.join('?'*len(course_ids)); where=f"WHERE c.id IN ({ph})"; params=list(course_ids)
        rows=conn.execute(f"SELECT c.id,c.title,c.category,c.level,c.description FROM courses c {where} ORDER BY c.id LIMIT {int(limit)}", params).fetchall()
        out=[]
        for c in rows:
            item=dict(c)
            item["modules"]=[dict(x) for x in conn.execute("SELECT title,content FROM course_modules WHERE course_id=? ORDER BY order_index", (c["id"],)).fetchall()]
            item["outcomes"]=[dict(x) for x in conn.execute("SELECT outcome FROM course_learning_outcomes WHERE course_id=? ORDER BY sequence_no", (c["id"],)).fetchall()]
            item["prerequisites"]=[dict(x) for x in conn.execute("SELECT prerequisite FROM course_prerequisites WHERE course_id=?", (c["id"],)).fetchall()]
            out.append(item)
        return out

    def fallback_questions(courses, count=8, subject_hint=None):
        # Offline fallback is deterministic and course-grounded, not random numbers.
        qs=[]
        templates=[
            ("Which statement best matches the course objective?", lambda c:[c["description"], "A UI styling objective", "An unrelated administrative objective", "None of these"] ,0),
            ("Which item is explicitly part of this course?", lambda c:[m["title"] for m in c.get("modules",[])[:1]]+["Payroll processing","Unrelated topic","None of these"],0),
            ("Which level is recorded for this course?", lambda c:[c["level"],"Unknown","Expert only","Not specified"],0),
            ("Which subject/category does this course belong to?", lambda c:[c["category"],"Finance","Human Resources","Unrelated domain"],0),
        ]
        i=0
        for c in courses:
            if subject_hint and c["category"].lower()!=subject_hint.lower(): continue
            for prompt, opts_fn, ans in templates:
                opts=opts_fn(c)
                if len(opts)<4: opts += ["Not listed"]*(4-len(opts))
                qs.append({"id":f"fam-{c['id']}-{i}","course_id":c["id"],"course_title":c["title"],"topic":c["category"],"question":prompt,"options":opts[:4],"answer_index":ans,"explanation":f"This is grounded in the stored course record for {c['title']}."})
                i+=1
                if len(qs)>=count: return qs
        return qs[:count]

    def generate_questions(conn, courses, count=8, purpose="competency", difficulty="mixed"):
        if not courses: return []
        ctx=json.dumps(courses, ensure_ascii=False)[:18000]
        prompt=f"""Generate {count} high-quality multiple-choice questions for PathSurfers PathSurfers.
Purpose: {purpose}. Difficulty: {difficulty}. Questions MUST be based only on the supplied course data.
Do not invent a course, module, learning outcome, prerequisite, statistic, policy or external fact not needed by the course data.
Questions should test understanding of the actual enrolled course content, not generic filler. For Meteorology/weather courses, keep the content within meteorology and IMD-relevant operational concepts present in the supplied course data.
Return strict JSON object: {{\"questions\":[{{\"course_id\":integer,\"topic\":string,\"question\":string,\"options\":[string,string,string,string],\"answer_index\":integer,\"explanation\":string}}]}}.
Exactly four options, answer_index 0-3. No markdown.
COURSE DATA:\n{ctx}"""
        try:
            data=groq_call([{"role":"system","content":"You are a careful educational assessment generator. Stay grounded in provided data."},{"role":"user","content":prompt}],json_mode=True,max_tokens=5000)
            raw=data.get("questions",[]) if isinstance(data,dict) else []
            valid=[]
            allowed={int(c["id"]):c for c in courses}
            for i,q in enumerate(raw):
                try:
                    cid=int(q.get("course_id")); opts=q.get("options",[]); ai=int(q.get("answer_index"))
                    if cid not in allowed or not isinstance(opts,list) or len(opts)!=4 or ai not in range(4): continue
                    text=str(q.get("question","")).strip()
                    if not text: continue
                    valid.append({"id":f"ai-{secrets.token_hex(5)}","course_id":cid,"course_title":allowed[cid]["title"],"topic":str(q.get("topic") or allowed[cid]["category"]),"question":text,"options":[str(x) for x in opts],"answer_index":ai,"explanation":str(q.get("explanation") or "")})
                except Exception: continue
            if valid: return valid[:count]
        except Exception:
            pass
        return fallback_questions(courses,count)

    def recommendation_data(conn, username):
        enrolled=user_courses(conn,username)
        ids=[int(x["id"]) for x in enrolled]
        all_courses=course_context(conn)
        progress=[]
        for c in enrolled:
            total=conn.execute("SELECT COUNT(*) FROM course_modules WHERE course_id=?",(c["id"],)).fetchone()[0]
            done=conn.execute("SELECT COUNT(*) FROM user_module_progress p JOIN course_modules m ON m.id=p.module_id WHERE p.username=? AND m.course_id=? AND p.completed=1",(username,c["id"])).fetchone()[0]
            latest=conn.execute("SELECT score FROM course_assessments WHERE username=? AND course_id=? ORDER BY id DESC LIMIT 1",(username,c["id"])).fetchone()
            progress.append({"course_id":c["id"],"title":c["title"],"category":c["category"],"progress_pct":round(done*100/total,1) if total else 0,"latest_assessment":float(latest[0]) if latest else None})
        # Competency is derived from live course completion + real course assessments.
        # Seeded competency_scores are intentionally ignored so the hub never presents fake proficiency.
        comps=[]
        for row in conn.execute("SELECT c.category, COUNT(cm.id) total, SUM(CASE WHEN COALESCE(ump.completed,0)=1 THEN 1 ELSE 0 END) done FROM courses c JOIN enrollments e ON e.course_id=c.id LEFT JOIN course_modules cm ON cm.course_id=c.id LEFT JOIN user_module_progress ump ON ump.username=? AND ump.module_id=cm.id WHERE e.username=? GROUP BY c.category ORDER BY c.category",(username,username)).fetchall():
            total=int(row['total'] or 0); done=int(row['done'] or 0); completion=(done*100/total) if total else 0
            assess=conn.execute("SELECT AVG(score) score FROM course_assessments ca JOIN courses c ON c.id=ca.course_id WHERE ca.username=? AND c.category=?",(username,row['category'])).fetchone()['score']
            score=round((completion+float(assess))/2,1) if assess is not None else round(completion,1)
            comps.append({'subject':row['category'],'score':score,'basis':'course progress'+(' + assessments' if assess is not None else '')})
        # PathForge target context is part of the same learner profile.
        path=conn.execute("SELECT target_role,progress,payload FROM pathforge_roadmaps WHERE username=? ORDER BY updated_at DESC LIMIT 1",(username,)).fetchone()
        path_ctx=None
        if path:
            try:
                prog=json.loads(path['progress']); payload=json.loads(path['payload'])
                closed=set(prog.get('done',[]))|set(prog.get('known',[]))|set(prog.get('skipped',[]))
                remaining=[n for n in payload.get('nodes',[]) if isinstance(n,dict) and str(n.get('id')) not in closed and n.get('type')!='target']
                path_ctx={'target_role':path['target_role'],'progress':prog,
                          'remaining_milestones':[{'title':n.get('title'),'skills':(n.get('skills') or [])[:6]} for n in remaining[:20]]}
            except Exception: path_ctx={'target_role':path['target_role']}
        return enrolled, all_courses, progress, comps, path_ctx

    _STOP={'and','the','for','with','of','to','a','an','in','on','at','&','your','role','target','fundamentals','foundations','engineering','engineer','basics','project'}
    def _terms(text):
        return {w for w in re.findall(r"[a-z][a-z0-9+#.]{1,}",str(text).lower()) if w not in _STOP}

    def roadmap_match(course, path_ctx):
        """Deterministic relevance of a real catalog course to the user's remaining PathForge route."""
        if not path_ctx: return 0, None
        ctext=_terms(" ".join([course.get('title',''),course.get('category',''),course.get('description','')]+[m.get('title','') for m in course.get('modules',[])]))
        best=(0,None)
        for m in path_ctx.get('remaining_milestones') or []:
            overlap=len(ctext & _terms(" ".join([m.get('title') or '']+list(m.get('skills') or []))))
            if overlap>best[0]: best=(overlap,m.get('title'))
        role_overlap=len(ctext & _terms(path_ctx.get('target_role','')))
        return best[0]*2+role_overlap, best[1]

    def ai_recommendations(conn, username):
        enrolled, all_courses, progress, comps, path_ctx = recommendation_data(conn,username)
        # Prefer not to recommend already-enrolled courses unless a next module is meaningful.
        payload=json.dumps({"pathforge":path_ctx,"enrolled":progress,"competencies":comps,"catalog":[dict(c) for c in all_courses]},ensure_ascii=False)[:24000]
        prompt=f"""You are PathSurfers's learning recommendation engine for PathSurfers.
Recommend what the trainee should learn NEXT. Use only the supplied database records. If a PathForge target exists, prioritize courses that close the most relevant skill gaps for that target.
Do not invent course IDs. Prefer courses not already enrolled. If every course is enrolled, recommend the enrolled course with the clearest low-progress/low-score next step.
Return strict JSON: {{\"recommendations\":[{{\"course_id\":integer,\"reason\":string,\"priority\":string,\"expected_benefit\":string}}]}}. Maximum 5.
DATA:\n{payload}"""
        try:
            data=groq_call([{"role":"system","content":"You recommend only from supplied PathSurfers course records and actual trainee progress."},{"role":"user","content":prompt}],json_mode=True,max_tokens=2500)
            valid=[]; catalog={int(c["id"]):c for c in all_courses}
            for r in data.get("recommendations",[]):
                try:
                    cid=int(r["course_id"])
                    if cid in catalog:
                        c=dict(catalog[cid]); c["reason"]=str(r.get("reason") or "Based on your recorded learning data."); c["priority"]=str(r.get("priority") or "Recommended"); c["expected_benefit"]=str(r.get("expected_benefit") or "Builds the next relevant skill."); valid.append(c)
                except Exception: pass
            if valid: return valid
        except Exception: pass
        # Deterministic fallback: rank real catalog courses by overlap with the
        # remaining PathForge milestones, then finish in-progress courses.
        enrolled_ids={int(x["id"]) for x in enrolled}
        out=[]
        ranked=sorted(((roadmap_match(c,path_ctx),c) for c in all_courses if int(c["id"]) not in enrolled_ids),key=lambda x:-x[0][0])
        for (score,milestone),c in ranked[:3]:
            reason=(f"Closes the PathForge milestone “{milestone}” on your route to {path_ctx['target_role']}." if milestone and score>0
                    else "Next un-enrolled course in the live catalog.")
            out.append({**dict(c),"reason":reason,"priority":"High" if score>=4 else "Recommended","expected_benefit":"Moves your PathForge route forward." if score>0 else "Extends your current learning path."})
        for pr in sorted(progress,key=lambda x:x["progress_pct"]):
            if pr["progress_pct"]<100 and len(out)<5:
                c=next((dict(x) for x in all_courses if int(x["id"])==int(pr["course_id"])),None)
                if c: out.append({**c,"reason":f"You are enrolled and {pr['progress_pct']}% complete — finishing it raises your {pr['category']} competency.","priority":"Continue","expected_benefit":"Converts an active course into competency."})
        return out

    def make_profile(conn, username):
        u=conn.execute("SELECT username,fullname,email,phone,role FROM users WHERE username=?",(username,)).fetchone()
        enrolled,_,progress,comps,_=recommendation_data(conn,username)
        path=conn.execute("SELECT target_role,progress,payload FROM pathforge_roadmaps WHERE username=? ORDER BY updated_at DESC LIMIT 1",(username,)).fetchone()
        path_ctx=None
        if path:
            try:
                prog=json.loads(path["progress"]); payload=json.loads(path["payload"])
                closed=set(prog.get("done",[]))|set(prog.get("known",[]))|set(prog.get("skipped",[]))
                nodes=[n for n in payload.get("nodes",[]) if isinstance(n,dict)]
                ready=[n.get("title") for n in nodes if str(n.get("id")) not in closed and all(str(p) in closed for p in (n.get("prerequisites") or []))]
                path_ctx={"target_role":path["target_role"],"total_milestones":len(nodes),
                          "completed_milestones":[n.get("title") for n in nodes if str(n.get("id")) in closed][:20],
                          "next_ready_milestones":ready[:5],"ai_generated":payload.get("aiStatus")=="groq"}
            except Exception: path_ctx={"target_role":path["target_role"]}
        return {"username":username,"name":u["fullname"] if u and u["fullname"] else username,"role":u["role"] if u else "","email":u["email"] if u else "","phone":u["phone"] if u else "","enrolled":progress,"competencies":comps,"pathforge":path_ctx}

    def nav_actions(text):
        t=text.lower()
        maps=[
            (r"dashboard|home", "/", "Dashboard"),(r"courses?|catalog", "/courses", "Courses"),
            (r"competenc", "/competencies", "Competencies"),(r"recommend", "/recommendations", "Recommendations"),
            (r"repository|resources?", "/repository", "Repository"),(r"analytic", "/analytics", "Analytics Hub"),
            (r"trainer|mentor|match", "/trainer-matching", "Trainer Matching"),(r"learning path|pathway", "/learning-path", "Learning Path"),
            (r"assessment|exam", "/competency-center", "Assessment / Competency"),(r"certificate", "/account", "Certificates / Profile"),
            (r"webinar", "/webinars", "Webinars"),(r"emergency|drill", "/emergency-drills", "Emergency Drills"),
            (r"notification", "/notifications", "Notifications"),(r"profile|account|password", "/account", "Profile & Account"),
        ]
        return [{"label":label,"url":url} for pat,url,label in maps if re.search(pat,t)]

    def conversation(conn, username, cid=None):
        if cid:
            row=conn.execute("SELECT * FROM mrwhite_conversations WHERE id=? AND username=?",(cid,username)).fetchone()
            if row: return row
        row=conn.execute("SELECT * FROM mrwhite_conversations WHERE username=? ORDER BY updated_at DESC,id DESC LIMIT 1",(username,)).fetchone()
        if row: return row
        cur=conn.execute("INSERT INTO mrwhite_conversations(username,title) VALUES(?,?)",(username,"New chat")); conn.commit()
        return conn.execute("SELECT * FROM mrwhite_conversations WHERE id=?",(cur.lastrowid,)).fetchone()

    def mrwhite_answer(conn, username, cid, text):
        p=make_profile(conn,username)
        hist=conn.execute("SELECT role,content FROM mrwhite_messages WHERE conversation_id=? ORDER BY id DESC LIMIT 12",(cid,)).fetchall()
        hist=list(reversed(hist))
        context=json.dumps(p,ensure_ascii=False)[:15000]
        routes="Dashboard / | Courses /courses | Competencies /competencies | AI Quiz /ai-quiz | Recommendations /recommendations | Repository /repository | Analytics /analytics | Trainer Matching /trainer-matching | Learning Path /learning-path | Webinars /webinars | Emergency Drills /emergency-drills | Notifications /notifications | Profile /account | Trainer Workshop /trainer | Create Course /courses/create"
        system=f"""You are Mr.White, the PathSurfers AI assistant inside PathSurfers (PathSurfers).
Speak like a helpful human Gen-Z assistant: natural Hinglish/English, light slang and emojis when appropriate, but stay respectful and clear.
You have access to the structured project context below. Never invent user scores, enrollment, course IDs, feature availability, or database facts. If a fact is absent, say so.
You can explain the whole project, calculations, study plans, features and how to navigate. For navigation, mention the exact page name/path from the route list.
For arithmetic, calculate carefully. You may answer general knowledge too, but distinguish it from project data.
When you state a fact from CURRENT USER DATA, prefix it with "📊 From your data:". When you give advice or an opinion, prefix it with "💡 Suggestion:". Keep replies under ~150 words unless asked for depth.
For "what next" questions, use pathforge.next_ready_milestones, low-progress enrolled courses and the weakest competency, and name the exact page to open.
PROJECT ROUTES: {routes}
CURRENT USER DATA: {context}"""
        messages=[{"role":"system","content":system}]+[{"role":x["role"],"content":x["content"]} for x in hist]+[{"role":"user","content":text}]
        try:
            answer=groq_call(messages,max_tokens=1800,temperature=.55,timeout=25)
            provider="Groq AI"
        except Exception as exc:
            # Grounded fallback: never fabricate database answers. Keep the real
            # reason available for diagnostics instead of falsely claiming that
            # the key is missing when the key exists but the API is unavailable.
            provider="Offline fallback"
            groq_key_present=bool(os.environ.get("GROQ_API_KEY", "").strip())
            groq_error = str(exc).strip()[:180]
            nav=nav_actions(text)
            nums=re.fullmatch(r"[0-9+\-*/().%\s]+",text.strip())
            if nums:
                try:
                    import ast as _ast
                    node=_ast.parse(text,mode='eval').body
                    def calc(n):
                        if isinstance(n,_ast.Constant) and isinstance(n.value,(int,float)): return n.value
                        if isinstance(n,_ast.UnaryOp) and isinstance(n.op,(_ast.UAdd,_ast.USub)): return +calc(n.operand) if isinstance(n.op,_ast.UAdd) else -calc(n.operand)
                        if isinstance(n,_ast.BinOp) and type(n.op) in (_ast.Add,_ast.Sub,_ast.Mult,_ast.Div,_ast.Mod,_ast.Pow): return { _ast.Add:lambda a,b:a+b,_ast.Sub:lambda a,b:a-b,_ast.Mult:lambda a,b:a*b,_ast.Div:lambda a,b:a/b,_ast.Mod:lambda a,b:a%b,_ast.Pow:lambda a,b:a**b}[type(n.op)](calc(n.left),calc(n.right))
                        raise ValueError
                    answer=f"📐 {calc(node)} — calculation done."
                except Exception: answer="I couldn't safely calculate that expression. Try something like `76 * 65`."
            elif nav:
                answer="Yep 😎 I can take you there. Use the navigation link for **%s**."%nav[0]["label"]
            else:
                pf=p.get('pathforge') or {}
                nxt=(pf.get('next_ready_milestones') or [])[:2]
                low=sorted(p['enrolled'],key=lambda x:x.get('progress_pct',0))[:1]
                facts=[f"**{len(p['enrolled'])} enrolled course(s)**", f"**{len(p['competencies'])} competency area(s)**"]
                if pf.get('target_role'): facts.append(f"target role **{pf['target_role']}**")
                tips=[]
                if nxt: tips.append("next PathForge milestone(s): " + ", ".join(f"**{x}**" for x in nxt))
                if low: tips.append(f"continue **{low[0]['title']}** ({low[0].get('progress_pct',0)}% done)")
                if groq_key_present:
                    answer=("📊 From your data: " + ", ".join(facts) + ". "
                            + (("💡 Suggestion: " + "; ".join(tips) + ". ") if tips else "")
                            + f"(Live AI is temporarily unavailable: `{groq_error}` — this answer uses stored data only.)")
                else:
                    answer=(f"I'm in offline mode rn. I still know your stored project data: **{len(p['enrolled'])} enrolled course(s)** and **{len(p['competencies'])} recorded competency area(s)**. "
                            "For live AI chat, configure GROQ_API_KEY in the project `.env`. I won't fake database answers.")
        conn.execute("INSERT INTO mrwhite_messages(conversation_id,role,content) VALUES(?,?,?)",(cid,"user",text))
        conn.execute("INSERT INTO mrwhite_messages(conversation_id,role,content) VALUES(?,?,?)",(cid,"assistant",answer))
        conn.execute("UPDATE mrwhite_conversations SET updated_at=CURRENT_TIMESTAMP,title=CASE WHEN title='New chat' THEN ? ELSE title END WHERE id=?",(text[:45],cid))
        conn.commit()
        return answer,provider,nav_actions(text)

    def rate_key():
        ip=(request.headers.get("X-Forwarded-For") or request.remote_addr or "unknown").split(',')[0].strip()
        uname=(request.form.get("username") or "").strip().lower()
        return hashlib.sha256(f"{ip}:{uname}".encode()).hexdigest()

    def login_rate_locked(conn,key):
        row=conn.execute("SELECT * FROM fam_login_rate_limits WHERE identifier_hash=?",(key,)).fetchone()
        if not row: return False,0
        now=datetime.utcnow()
        if row["locked_until"]:
            try: until=datetime.fromisoformat(row["locked_until"].replace('Z',''))
            except Exception: until=now
            if until>now: return True,max(1,int((until-now).total_seconds()))
        return False,0

    def login_rate_fail(conn,key):
        now=datetime.utcnow()
        row=conn.execute("SELECT * FROM fam_login_rate_limits WHERE identifier_hash=?",(key,)).fetchone()
        if not row:
            conn.execute("INSERT INTO fam_login_rate_limits(identifier_hash,attempts,window_started_at) VALUES(?,?,?)",(key,1,now.isoformat()))
            return
        started=datetime.fromisoformat(row["window_started_at"])
        attempts=row["attempts"]
        if (now-started).total_seconds()>600:
            attempts=0; started=now
        attempts+=1
        locked=(now+timedelta(seconds=900)).isoformat() if attempts>=5 else None
        conn.execute("UPDATE fam_login_rate_limits SET attempts=?,window_started_at=?,locked_until=? WHERE identifier_hash=?",(0 if locked else attempts,started.isoformat(),locked,key))

    def login_rate_clear(conn,key): conn.execute("DELETE FROM fam_login_rate_limits WHERE identifier_hash=?",(key,))

    def role_ok(*roles): return current() and session.get("role") in roles

    def course_asset_rows(conn,course_id):
        return conn.execute("SELECT * FROM course_assets WHERE course_id=? ORDER BY created_at,id",(course_id,)).fetchall()

    def save_uploaded_assets(conn, course_id, module_id, files, username):
        asset_dir=root/'static'/'uploads'/'course_assets'; asset_dir.mkdir(parents=True,exist_ok=True)
        allowed={"pdf":"pdf","png":"photo","jpg":"photo","jpeg":"photo","webp":"photo","gif":"photo","mp4":"video","webm":"video","mov":"video","m4v":"video"}
        max_size=100*1024*1024
        for file in files:
            if not file or not file.filename: continue
            original=secure_filename(file.filename)
            ext=original.rsplit('.',1)[-1].lower() if '.' in original else ''
            kind=allowed.get(ext)
            if not kind: raise ValueError(f"Unsupported asset type: {original}")
            data=file.read()
            if len(data)>max_size: raise ValueError(f"{original} is larger than 100 MB")
            stored=f"{course_id}_{secrets.token_hex(10)}_{original}"
            (asset_dir/stored).write_bytes(data)
            mime=file.mimetype or ({"pdf":"application/pdf","photo":"image/*","video":"video/*"}[kind])
            conn.execute("INSERT INTO course_assets(course_id,module_id,asset_type,filename,stored_name,mime_type,size_bytes,created_by) VALUES(?,?,?,?,?,?,?,?)",(course_id,module_id,kind,original,stored,mime,len(data),username))

    def render_course_create():
        c=db(); courses=c.execute("SELECT id,title FROM courses ORDER BY title").fetchall(); c.close()
        return render_template("course_create_fam.html", courses=courses)

    def render_ai_quiz(username):
        c=db(); courses=course_context(c,[int(x["id"]) for x in user_courses(c,username)])
        if not courses: courses=course_context(c)
        qs=generate_questions(c,courses,count=10,purpose="adaptive competency assessment",difficulty="mixed")
        c.close()
        session["fam_ai_quiz"]={"questions":qs,"created":datetime.utcnow().isoformat()}; session.modified=True
        return render_template("ai_quiz_fam.html",questions=qs,ai_live=ai_available(),source="Groq AI" if ai_available() else "Offline course-grounded fallback")

    def grade_ai_quiz(username):
        pack=session.get("fam_ai_quiz") or {}; qs=pack.get("questions",[])
        if not qs: flash("Quiz session expired. Please start a new AI quiz."); return redirect(url_for("ai_quiz"))
        c=db(); correct=0; by_course={}
        for q in qs:
            selected=request.form.get(f"q_{q['id']}")
            ok=selected is not None and int(selected)==int(q["answer_index"])
            correct+=int(ok); rec=by_course.setdefault(int(q["course_id"]),[0,0]); rec[1]+=1; rec[0]+=int(ok)
        total=len(qs); score=round(correct*100/total,1) if total else 0
        cur=c.execute("INSERT INTO competency_assessments(username,assessment_type,total_questions,correct_answers) VALUES(?,?,?,?)",(username,"AI Adaptive Competency Quiz",total,correct))
        aid=cur.lastrowid
        for cid,(got,n) in by_course.items():
            course=c.execute("SELECT title,category FROM courses WHERE id=?",(cid,)).fetchone()
            pct=round(got*100/n,1)
            c.execute("INSERT INTO competency_scores(assessment_id,subject,score,competency_level) VALUES(?,?,?,?)",(aid,course["category"],pct,"Strong" if pct>=80 else "Developing" if pct>=60 else "Needs Improvement"))
        c.execute("UPDATE competency_assessments SET completed_at=CURRENT_TIMESTAMP WHERE id=?",(aid,))
        record_assessment(c,username,"AI Adaptive Competency Quiz",{c.execute("SELECT category FROM courses WHERE id=?",(cid,)).fetchone()[0]:round(got*100/n,1) for cid,(got,n) in by_course.items()},total,correct)
        c.commit(); c.close(); session.pop("fam_ai_quiz",None); session.modified=True
        c2=db(); recs=ai_recommendations(c2,username); c2.close()
        return render_template("recommendations_fam.html",score=score,total=total,recommendations=recs,completed=True,ai_live=ai_available())

    def render_competencies(username):
        c=db(); enrolled=user_courses(c,username); cards=[]
        for course in enrolled:
            total=c.execute("SELECT COUNT(*) FROM course_modules WHERE course_id=?",(course["id"],)).fetchone()[0]
            done=c.execute("SELECT COUNT(*) FROM user_module_progress p JOIN course_modules m ON m.id=p.module_id WHERE p.username=? AND m.course_id=? AND p.completed=1",(username,course["id"])).fetchone()[0]
            a=c.execute("SELECT score FROM course_assessments WHERE username=? AND course_id=? ORDER BY id DESC LIMIT 1",(username,course["id"])).fetchone()
            pct=round(done*100/total,1) if total else (float(a[0]) if a else 0)
            if a: pct=round((pct+float(a[0]))/2,1) if total else float(a[0])
            cards.append({"id":course["id"],"title":course["title"],"category":course["category"],"level":course["level"],"progress":pct,"assessment":float(a[0]) if a else None})
        c.close(); return render_template("competencies_fam.html",cards=cards)

    def render_course_assessment(course_id, username):
        c=db(); course=c.execute("SELECT * FROM courses WHERE id=?",(course_id,)).fetchone(); enrolled=c.execute("SELECT 1 FROM enrollments WHERE username=? AND course_id=?",(username,course_id)).fetchone()
        if not course or not enrolled: c.close(); flash("Enroll in this course before taking its AI assessment."); return redirect(url_for("courses"))
        if request.method=='GET':
            data=course_context(c,[course_id]); qs=generate_questions(c,data,count=8,purpose=f"course assessment for {course['title']}",difficulty=course['level']); c.close()
            session[f"fam_course_assessment_{course_id}"]=qs; session.modified=True
            return render_template("course_assessment_fam.html",course=course,questions=qs,time_limit_minutes=max(5,len(qs)*2),ai_live=ai_available())
        qs=session.get(f"fam_course_assessment_{course_id}",[])
        if not qs: c.close(); flash("Assessment expired. Start again."); return redirect(url_for("course_assessment",course_id=course_id))
        correct=0
        for q in qs:
            correct+=int(request.form.get(f"q_{q['id']}") is not None and int(request.form.get(f"q_{q['id']}", -1))==int(q['answer_index']))
        total=len(qs); score=round(correct*100/total,1); passed=int(score>=70)
        cur=c.execute("INSERT INTO assessment_attempts(username,assessment_type,subject,total_questions,correct_answers,score) VALUES(?,?,?,?,?,?)",(username,f"AI Course assessment: {course['title']}",course['category'],total,correct,score)); aid=cur.lastrowid
        c.execute("INSERT INTO course_assessments(username,course_id,score,passed,total_questions) VALUES(?,?,?,?,?)",(username,course_id,score,passed,total))
        record_assessment(c,username,f"AI Course assessment: {course['title']}",{course['category']:score},total,correct)
        notify(c,username,"AI assessment result",f"{course['title']}: {score}%" + (" — passed." if passed else " — retake recommended."),"assessment")
        log_action(c,username,"ai_assessment_completion",f"Course {course_id}; score {score}"); c.commit(); c.close(); session.pop(f"fam_course_assessment_{course_id}",None); session.modified=True
        flash(f"AI assessment submitted: {score}%."); return redirect(url_for("course_detail",course_id=course_id))

    # Correct a typo safely before the module is imported by replacing this function's bad string at runtime is not possible.
    # The source uses a normal f-string below; this comment is intentionally kept short.

    def render_certificate(course_id, username):
        c=db(); course=c.execute("SELECT * FROM courses WHERE id=?",(course_id,)).fetchone()
        if not course: c.close(); flash("Course not found."); return redirect(url_for("courses"))
        ok,reason=eligibility(c,username,course_id); cert=c.execute("SELECT * FROM certificates WHERE username=? AND course_id=? AND status='Issued'",(username,course_id)).fetchone()
        pref=c.execute("SELECT display_name FROM fam_user_preferences WHERE username=?",(username,)).fetchone(); display=(pref["display_name"] if pref else None) or (c.execute("SELECT fullname FROM users WHERE username=?",(username,)).fetchone()[0] or username)
        if not ok and not cert: c.close(); flash("Certificate not available yet: "+reason); return redirect(url_for("course_detail",course_id=course_id))
        if not pref or not pref["display_name"]:
            c.close(); return render_template("certificate_name.html",course=course,display_name=display)
        if not cert:
            score=c.execute("SELECT score FROM course_assessments WHERE username=? AND course_id=? AND passed=1 ORDER BY id DESC LIMIT 1").fetchone()[0]
            cert=issue(c,username,course_id,score); log_action(c,username,'certificate_generation',f'Course {course_id}'); notify(c,username,'Certificate available',f'Your certificate for {course["title"]} is ready.','certificate'); c.commit()
        sig=app.view_functions["home"].__globals__["certificate_signature"](cert['certificate_id'],cert['verification_code'],cert['username'],cert['course_id'])
        verify=url_for('verify_certificate',verification_code=cert['verification_code'],_external=True)
        c.close(); return render_template('certificate_fam.html',course=course,username=display,certificate=cert,cert_signature=sig,verify_url=verify)

    def render_webinars(username):
        c=db(); rows=c.execute("SELECT * FROM webinars ORDER BY scheduled_time").fetchall(); c.close(); return render_template('webinars_fam.html',webinars=rows,can_manage=session.get('role') in ROLES_CREATOR)

    def render_drills(username):
        c=db(); templates=c.execute("SELECT * FROM emergency_drill_templates WHERE status='Published' ORDER BY id DESC").fetchall(); results=c.execute("SELECT * FROM emergency_drills WHERE username=? ORDER BY id DESC",(username,)).fetchall(); c.close(); return render_template('emergency_drills_fam.html',templates=templates,results=results,can_manage=session.get('role') in ROLES_CREATOR)

    @app.before_request
    def fam_router():
        path=request.path; method=request.method
        # Must run first: supersedes selected legacy handlers without deleting them.
        if method in {"POST","PUT","PATCH","DELETE"} and not csrf_valid() and not path.startswith('/static/'):
            # Login and JSON APIs get the same strict token requirement.
            if path != '/health': return jsonify(status='error',message='CSRF validation failed'),403

        if path=='/login' and method=='POST':
            conn=db(); key=rate_key(); locked,secs=login_rate_locked(conn,key)
            if locked:
                conn.close(); flash(f"Too many failed login attempts. Try again in {max(1,secs//60)} minute(s)."); return render_template('login.html')
            username=request.form.get('username','').strip(); password=request.form.get('password','')
            user=conn.execute('SELECT * FROM users WHERE username=?',(username,)).fetchone()
            if user and app.view_functions['home'].__globals__['check_password_hash'](user['password'],password):
                login_rate_clear(conn,key); session['user']=user['username']; session['role']=user['role']; session['ref_code']=user['ref_code']; session['avatar_path']=user['avatar_path'] if 'avatar_path' in user.keys() else None
                conn.execute("INSERT OR IGNORE INTO fam_user_preferences(username) VALUES(?)",(user['username'],)); log_action(conn,user['username'],'login','Successful login'); conn.commit(); conn.close(); return redirect(url_for('home'))
            login_rate_fail(conn,key); conn.commit(); conn.close(); flash('Invalid username or password!'); return render_template('login.html')

        if path=='/chat' and method=='GET':
            if not current(): return redirect(url_for('login'))
            conn=db(); convs=conn.execute("SELECT * FROM mrwhite_conversations WHERE username=? ORDER BY updated_at DESC,id DESC",(current(),)).fetchall(); conv=conversation(conn,current(),request.args.get('conversation_id',type=int)); msgs=conn.execute("SELECT role,content,created_at FROM mrwhite_messages WHERE conversation_id=? ORDER BY id",(conv['id'],)).fetchall(); conn.close(); return render_template('mrwhite_fam.html',conversations=convs,conversation=conv,messages=msgs,ai_live=ai_available())
        if path in ('/api/chat','/api/mrwhite/chat') and method=='POST':
            if not current(): return jsonify(status='error',message='Unauthorized'),401
            data=request.get_json(silent=True) or {}; text=str(data.get('message','')).strip(); cid=data.get('conversation_id')
            if not text: return jsonify(status='error',message='Empty message'),400
            conn=db(); conv=conversation(conn,current(),int(cid) if str(cid).isdigit() else None); answer,provider,actions=mrwhite_answer(conn,current(),conv['id'],text); conn.close(); return jsonify(status='success',response=answer,provider=provider,conversation_id=conv['id'],actions=actions)
        if path=='/api/mrwhite/new' and method=='POST':
            if not current(): return jsonify(status='error'),401
            conn=db(); cur=conn.execute("INSERT INTO mrwhite_conversations(username,title) VALUES(?,?)",(current(),'New chat')); conn.commit(); row=conn.execute("SELECT * FROM mrwhite_conversations WHERE id=?",(cur.lastrowid,)).fetchone(); conn.close(); return jsonify(status='success',conversation=dict(row))
        if path=='/api/mrwhite/history' and method=='GET':
            if not current(): return jsonify(status='error'),401
            conn=db(); rows=[dict(r) for r in conn.execute("SELECT * FROM mrwhite_conversations WHERE username=? ORDER BY updated_at DESC,id DESC",(current(),)).fetchall()]; conn.close(); return jsonify(status='success',conversations=rows)
        if path=='/ai-quiz' and method=='GET': return render_ai_quiz(current()) if current() else redirect(url_for('login'))
        if path=='/ai-quiz' and method=='POST': return grade_ai_quiz(current()) if current() else redirect(url_for('login'))
        if path=='/recommendations' and method=='GET':
            if not current(): return redirect(url_for('login'))
            c=db(); recs=ai_recommendations(c,current()); c.close(); return render_template('recommendations_fam.html',recommendations=recs,completed=False,ai_live=ai_available())
        if path=='/competencies' and method=='GET': return render_competencies(current()) if current() else redirect(url_for('login'))
        m=re.fullmatch(r'/assessment/(\d+)',path)
        if m and method in ('GET','POST'):
            if not current(): return redirect(url_for('login'))
            return render_course_assessment(int(m.group(1)),current())
        m=re.fullmatch(r'/certificate/(\d+)',path)
        if m and method=='GET': return render_certificate(int(m.group(1)),current()) if current() else redirect(url_for('login'))
        m=re.fullmatch(r'/certificate/(\d+)/name',path)
        if m and method=='POST':
            if not current(): return redirect(url_for('login'))
            name=re.sub(r'\s+',' ',request.form.get('display_name','').strip())
            if not re.fullmatch(r"[A-Za-z][A-Za-z .'-]{1,79}",name): flash('Please enter a valid certificate name (2–80 characters).'); return redirect(url_for('certificate',course_id=int(m.group(1))))
            conn=db(); conn.execute("INSERT INTO fam_user_preferences(username,display_name) VALUES(?,?) ON CONFLICT(username) DO UPDATE SET display_name=excluded.display_name,updated_at=CURRENT_TIMESTAMP",(current(),name)); conn.commit(); conn.close(); return redirect(url_for('certificate',course_id=int(m.group(1))))
        if path=='/account' and method=='POST' and request.form.get('action') in ('display_name','theme'):
            if not current(): return redirect(url_for('login'))
            conn=db(); action=request.form.get('action')
            if action=='display_name':
                name=re.sub(r'\s+',' ',request.form.get('display_name','').strip())
                if not name or len(name)>80: flash('Display name must be 1–80 characters.')
                else: conn.execute("INSERT INTO fam_user_preferences(username,display_name) VALUES(?,?) ON CONFLICT(username) DO UPDATE SET display_name=excluded.display_name,updated_at=CURRENT_TIMESTAMP",(current(),name)); flash('Display name updated.')
            else:
                theme=request.form.get('theme','light');
                if theme not in ('light','dark'): theme='light'
                conn.execute("INSERT INTO fam_user_preferences(username,theme) VALUES(?,?) ON CONFLICT(username) DO UPDATE SET theme=excluded.theme,updated_at=CURRENT_TIMESTAMP",(current(),theme)); session['fam_theme']=theme; flash('Theme updated.')
            conn.commit(); conn.close(); return redirect(url_for('account'))
        if path=='/courses/create' and method in ('GET','POST'):
            if not role_ok(*ROLES_CREATOR): return redirect(url_for('login')) if not current() else abort(403)
            if method=='GET': return render_course_create()
            title=request.form.get('title','').strip(); desc=request.form.get('description','').strip(); cat=request.form.get('category','').strip(); level=request.form.get('level','').strip(); duration=request.form.get('duration_minutes','').strip()
            if not title or not desc or not cat or not level: flash('Title, description, category and difficulty are required.'); return render_course_create()
            try: duration_i=int(duration) if duration else None
            except ValueError: duration_i=None
            modules=[x.strip() for x in request.form.get('modules','').splitlines() if x.strip()]
            outcomes=[x.strip() for x in request.form.get('learning_outcomes','').splitlines() if x.strip()]
            prereq=[x.strip() for x in request.form.get('prerequisites','').splitlines() if x.strip()]
            conn=db()
            try:
                cur=conn.execute("INSERT INTO courses(title,category,level,description) VALUES(?,?,?,?)",(title[:160],cat[:100],level[:50],desc[:5000])); cid=cur.lastrowid
                conn.execute("INSERT OR REPLACE INTO course_metadata(course_id,created_by,status,duration_minutes) VALUES(?,?,?,?)",(cid,current(),'Published',duration_i))
                for n,x in enumerate(outcomes,1): conn.execute("INSERT INTO course_learning_outcomes(course_id,outcome,sequence_no) VALUES(?,?,?)",(cid,x[:500],n))
                for x in prereq: conn.execute("INSERT INTO course_prerequisites(course_id,prerequisite) VALUES(?,?)",(cid,x[:500]))
                mids=[]
                for n,x in enumerate(modules,1): mids.append(conn.execute("INSERT INTO course_modules(course_id,title,content,order_index) VALUES(?,?,?,?)",(cid,x[:200],x[:200],n)).lastrowid)
                files=request.files.getlist('assets')
                save_uploaded_assets(conn,cid,mids[0] if mids else None,files,current())
                conn.commit(); log_action(conn,current(),'course_created',f'FAM course {cid}'); conn.commit(); flash('Course created. AI assessments will use its actual course data.'); return redirect(url_for('course_detail',course_id=cid))
            except Exception as e:
                conn.rollback(); flash(f'Course creation failed safely: {e}'); return render_course_create(),400
            finally: conn.close()
        if path.startswith('/course-asset/') and method=='GET':
            aid=path.rsplit('/',1)[-1]
            if not aid.isdigit(): abort(404)
            conn=db(); asset=conn.execute("SELECT ca.*,e.username enrolled FROM course_assets ca LEFT JOIN enrollments e ON e.course_id=ca.course_id AND e.username=? WHERE ca.id=?",(current(),int(aid))).fetchone()
            allowed=bool(asset and (asset['enrolled'] or (current() and session.get('role') in ROLES_CREATOR)))
            if not allowed: conn.close(); abort(403 if current() else 401)
            p=root/'static'/'uploads'/'course_assets'/asset['stored_name']; conn.close()
            if not p.exists(): abort(404)
            return send_file(str(p),mimetype=asset['mime_type'],as_attachment=request.args.get('download')=='1',download_name=asset['filename'])
        if path=='/admin/audit-logs' and method=='GET':
            if not role_ok('Administrator'): return abort(403)
            page=max(1,request.args.get('page',1,type=int)); per=40; off=(page-1)*per; conn=db(); rows=conn.execute("SELECT * FROM audit_logs ORDER BY id DESC LIMIT ? OFFSET ?",(per,off)).fetchall(); total=conn.execute('SELECT COUNT(*) FROM audit_logs').fetchone()[0]; conn.close(); return render_template('audit_logs_fam.html',logs=rows,page=page,pages=max(1,math.ceil(total/per)))
        if path=='/webinars' and method=='GET': return render_webinars(current()) if current() else redirect(url_for('login'))
        if path=='/emergency-drills' and method=='GET': return render_drills(current()) if current() else redirect(url_for('login'))
        m=re.fullmatch(r'/webinars/(\d+)/edit',path)
        if m and method=='POST':
            if not role_ok(*ROLES_CREATOR): abort(403)
            conn=db(); wid=int(m.group(1)); title=request.form.get('title','').strip(); speaker=request.form.get('speaker','').strip(); when=request.form.get('scheduled_time','').strip(); link=request.form.get('meeting_link','').strip(); status=request.form.get('status','Upcoming').strip() or 'Upcoming'
            if not all((title,speaker,when,link)): conn.close(); flash('All webinar fields are required.'); return redirect(url_for('webinars'))
            conn.execute("UPDATE webinars SET title=?,speaker=?,scheduled_time=?,meeting_link=?,status=? WHERE id=?",(title[:200],speaker[:160],when[:80],link[:500],status[:40],wid)); log_action(conn,current(),'webinar_updated',f'Webinar {wid}'); conn.commit(); conn.close(); flash('Webinar updated.'); return redirect(url_for('webinars'))
        if path=='/webinars/create' and method=='POST':
            if not role_ok(*ROLES_CREATOR): abort(403)
            conn=db(); title=request.form.get('title','').strip(); speaker=request.form.get('speaker','').strip(); when=request.form.get('scheduled_time','').strip(); link=request.form.get('meeting_link','').strip()
            if not all((title,speaker,when,link)): flash('All webinar fields are required.'); conn.close(); return redirect(url_for('webinars'))
            cur=conn.execute("INSERT INTO webinars(title,speaker,scheduled_time,meeting_link,status) VALUES(?,?,?,?,?)",(title[:200],speaker[:160],when[:80],link[:500],'Upcoming')); wid=cur.lastrowid
            users=[r[0] for r in conn.execute('SELECT username FROM users').fetchall()]
            for u in users: notify(conn,u,'New webinar',f'{title} with {speaker} is scheduled for {when}.','webinar')
            log_action(conn,current(),'webinar_created',f'Webinar {wid}'); conn.commit(); conn.close(); flash('Webinar created and users notified.'); return redirect(url_for('webinars'))
        m=re.fullmatch(r'/webinars/(\d+)/delete',path)
        if m and method=='POST':
            if not role_ok(*ROLES_CREATOR): abort(403)
            conn=db(); wid=int(m.group(1)); conn.execute('DELETE FROM webinars WHERE id=?',(wid,)); log_action(conn,current(),'webinar_deleted',f'Webinar {wid}'); conn.commit(); conn.close(); flash('Webinar deleted.'); return redirect(url_for('webinars'))
        m=re.fullmatch(r'/emergency-drills/(\d+)/edit',path)
        if m and method=='POST':
            if not role_ok(*ROLES_CREATOR): abort(403)
            conn=db(); did=int(m.group(1)); title=request.form.get('title','').strip(); scenario=request.form.get('scenario','').strip(); instructions=request.form.get('instructions','').strip(); status=request.form.get('status','Published').strip() or 'Published'
            try: dur_i=max(30,min(86400,int(request.form.get('duration_seconds','300'))))
            except: dur_i=300
            if not title or not scenario: conn.close(); flash('Drill title and scenario are required.'); return redirect(url_for('emergency_drills'))
            conn.execute("UPDATE emergency_drill_templates SET title=?,scenario=?,instructions=?,duration_seconds=?,status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(title[:200],scenario[:5000],instructions[:10000],dur_i,status[:40],did)); log_action(conn,current(),'emergency_drill_updated',f'Drill {did}'); conn.commit(); conn.close(); flash('Emergency drill updated.'); return redirect(url_for('emergency_drills'))
        if path=='/emergency-drills/create' and method=='POST':
            if not role_ok(*ROLES_CREATOR): abort(403)
            conn=db(); title=request.form.get('title','').strip(); scenario=request.form.get('scenario','').strip(); instructions=request.form.get('instructions','').strip(); dur=request.form.get('duration_seconds','300').strip()
            try: dur_i=max(30,min(86400,int(dur)))
            except: dur_i=300
            if not title or not scenario: conn.close(); flash('Drill title and scenario are required.'); return redirect(url_for('emergency_drills'))
            cur=conn.execute("INSERT INTO emergency_drill_templates(title,scenario,instructions,duration_seconds,created_by) VALUES(?,?,?,?,?)",(title[:200],scenario[:5000],instructions[:10000],dur_i,current())); did=cur.lastrowid
            for u in conn.execute('SELECT username FROM users').fetchall(): notify(conn,u,'Emergency drill available',f'{title} is available in Emergency Drills.','emergency_drill')
            log_action(conn,current(),'emergency_drill_created',f'Drill {did}'); conn.commit(); conn.close(); flash('Emergency drill created and users notified.'); return redirect(url_for('emergency_drills'))
        m=re.fullmatch(r'/emergency-drills/(\d+)/delete',path)
        if m and method=='POST':
            if not role_ok(*ROLES_CREATOR): abort(403)
            conn=db(); did=int(m.group(1)); conn.execute('DELETE FROM emergency_drill_templates WHERE id=?',(did,)); log_action(conn,current(),'emergency_drill_deleted',f'Drill {did}'); conn.commit(); conn.close(); flash('Emergency drill deleted.'); return redirect(url_for('emergency_drills'))
        if path=='/notifications' and method=='GET' and current():
            conn=db(); now=datetime.now(); upcoming=conn.execute("SELECT * FROM webinars WHERE status='Upcoming'").fetchall()
            for w in upcoming:
                if str(w['scheduled_time'])[:16] >= now.strftime('%Y-%m-%dT%H:%M'):
                    exists=conn.execute("SELECT 1 FROM notifications WHERE username=? AND notification_type='webinar' AND message LIKE ?",(current(),f'%{w["title"]}%')).fetchone()
                    if not exists: notify(conn,current(),'Webinar reminder',f'{w["title"]} is scheduled for {w["scheduled_time"]}.','webinar')
            rows=conn.execute("SELECT * FROM notifications WHERE username=? ORDER BY id DESC",(current(),)).fetchall(); conn.execute("UPDATE notifications SET is_read=1 WHERE username=?",(current(),)); conn.commit(); conn.close(); return render_template('notifications.html',notifications=rows)
        return None

    # Put the FAM router first so it can safely supersede selected legacy endpoints.
    app.before_request_funcs.setdefault(None, []).insert(0, fam_router)

    # Dark theme + offline asset cache + CSRF form safety are additive base-page helpers.
    base_path=root/'templates'/'base.html'; s=base_path.read_text(encoding='utf8')
    if 'fam-theme-style' not in s:
        marker='<body>'
        dark='''<style id="fam-theme-style">\nbody.fam-dark{background:#050914!important;color:#e5e7eb!important}.fam-dark .card,.fam-dark .form-card,.fam-dark .stat-box,.fam-dark table,.fam-dark input,.fam-dark textarea,.fam-dark select,.fam-dark .settings-card{background:#0b1220!important;color:#e5e7eb!important;border-color:#1f2937!important}.fam-dark h1,.fam-dark h2,.fam-dark h3,.fam-dark h4,.fam-dark label,.fam-dark strong,.fam-dark th{color:#f8fafc!important}.fam-dark p,.fam-dark .muted,.fam-dark td,.fam-dark small{color:#94a3b8!important}.fam-dark a{color:#67e8f9!important}.fam-dark .navbar,.fam-dark footer{background:#050914!important;border-color:#1f2937!important}.fam-dark [style*="background: #fff"],[style*="background:#fff"],[style*="background: #ffffff"],[style*="background:#ffffff"],[style*="background-color: #fff"]{background:#0b1220!important}.fam-dark [style*="color: #0f172a"],[style*="color:#0f172a"],[style*="color: #334155"],[style*="color:#334155"],[style*="color: #475569"]{color:#e5e7eb!important}\n.fam-smooth *{scroll-behavior:smooth}.fam-card-in{animation:famIn .35s ease both}@keyframes famIn{from{opacity:0;transform:translateY(7px)}to{opacity:1;transform:none}}\n</style>'''
        s=s.replace(marker,marker+'\n'+dark,1)
    s=s.replace('<body>', '<body class="{% if fam_theme == \'dark\' %}fam-dark {% endif %}fam-smooth">',1)
    # Add CSRF to legacy POST forms at render time as a defense-in-depth client helper.
    if 'FAM CSRF auto-inject' not in s:
        inject='''\n<script>/* FAM CSRF auto-inject: keeps every legacy HTML POST form protected. */\ndocument.addEventListener('DOMContentLoaded',function(){const token={{ csrf_token()|tojson }};document.querySelectorAll('form').forEach(f=>{const m=(f.getAttribute('method')||'GET').toUpperCase();if(m==='POST'&&!f.querySelector('input[name="_csrf_token"]')){const i=document.createElement('input');i.type='hidden';i.name='_csrf_token';i.value=token;f.appendChild(i);}});});</script>\n'''
        s=s.replace('</body>',inject+'</body>')
    base_path.write_text(s,encoding='utf8')
