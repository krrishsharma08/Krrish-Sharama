"""PathSurfers FAM additive: AI-generated quiz questions, course-assessment
questions and course recommendations, constrained to real platform data and
always backed by a safe non-AI fallback so the app never breaks offline or
when the Groq API is unreachable.
"""
import random
from services.groq_service import chat_json, ai_enabled

METEOROLOGY_TOPICS = [
    "Numerical Weather Prediction", "Oceanography", "Seismology", "Cyclone tracking",
    "Monsoon dynamics", "Satellite meteorology", "Climate modelling", "Python for data analysis",
    "Sensor telemetry (CTD, buoys)", "Disaster early-warning systems",
]

_SYSTEM_QUIZ = (
    "You are a question-setter for PathSurfers, a competency platform for the "
    "PathSurfers. You write short multiple-choice quiz questions "
    "strictly about the supplied course domains (programming, ML/AI, data engineering, "
    "cloud/MLOps, computer vision, AI safety and related engineering work). "
    "Never write questions about unrelated topics. "
    "Respond with ONLY a JSON object of the exact shape: "
    '{"questions": [{"question": str, "domain": str, "options": [str, str, str, str], "answer": str}]}. '
    "The 'answer' value MUST be exactly one of the 4 strings in 'options'. "
    "'domain' must be one of: Programming, Oceanography, Seismology, Meteorology. "
    "No explanations, no markdown, no text outside the JSON object."
)


def _validate_question(q):
    if not isinstance(q, dict):
        return False
    if not q.get("question") or not q.get("answer") or not q.get("domain"):
        return False
    options = q.get("options")
    if not isinstance(options, list) or len(options) < 2:
        return False
    if q["answer"] not in options:
        return False
    return True


def generate_ai_quiz_questions(count, topics=None, difficulty="Intermediate", fallback_fn=None):
    """Try Groq for `count` fresh quiz questions constrained to earth-science /
    IMD topics (optionally narrowed to the caller's enrolled-course topics).
    Falls back to fallback_fn() (the existing template generator) on any
    failure so the quiz never breaks."""
    if ai_enabled():
        topic_line = f" Focus especially on: {', '.join(topics)}." if topics else ""
        user_prompt = (
            f"Generate exactly {count} unique multiple-choice quiz questions at "
            f"{difficulty} difficulty.{topic_line} Each question needs exactly 4 options "
            f"with exactly one correct answer. Vary the domains realistically."
        )
        result = chat_json([
            {"role": "system", "content": _SYSTEM_QUIZ},
            {"role": "user", "content": user_prompt},
        ])
        if result and isinstance(result, dict) and isinstance(result.get("questions"), list):
            cleaned = [q for q in result["questions"] if _validate_question(q)]
            if len(cleaned) >= min(count, 1):
                out = []
                for i, q in enumerate(cleaned[:count]):
                    out.append({
                        "id": f"ai_{i}_{random.randint(1000,9999)}",
                        "question": str(q["question"])[:500],
                        "domain": q["domain"] if q["domain"] in
                            ("Programming", "Oceanography", "Seismology", "Meteorology") else "Meteorology",
                        "options": [str(o)[:200] for o in q["options"]],
                        "answer": str(q["answer"])[:200],
                        "source": "ai",
                    })
                return out
    # Fallback: existing deterministic template generator, unchanged behaviour.
    return fallback_fn(count) if fallback_fn else []


_SYSTEM_COURSE_Q = (
    "You are writing a short multiple-choice assessment for ONE specific training course on "
    "the PathSurfers platform. Base every question "
    "strictly on the course title, description and module list given to you — do not invent "
    "unrelated content. Respond with ONLY a JSON object: "
    '{"questions": [{"question": str, "options": [str, str, str, str], "answer": str, '
    '"explanation": str}]}. "answer" must exactly match one of the 4 "options". No text '
    "outside the JSON object."
)


def generate_course_assessment_questions(title, description, modules, count=5):
    """Generate assessment questions for a specific course from its own content.
    Returns a list of dicts, or [] if AI is unavailable/fails (caller should
    fall back to the existing generic question bank)."""
    if not ai_enabled():
        return []
    modules_text = "; ".join(modules[:20]) if modules else "(no modules listed)"
    user_prompt = (
        f"Course title: {title}\nCourse description: {description[:1500]}\n"
        f"Modules: {modules_text}\nWrite exactly {count} questions testing understanding "
        f"of this specific course content."
    )
    result = chat_json([
        {"role": "system", "content": _SYSTEM_COURSE_Q},
        {"role": "user", "content": user_prompt},
    ])
    if not result or not isinstance(result.get("questions"), list):
        return []
    cleaned = []
    for q in result["questions"][:count]:
        if _validate_question(q):
            cleaned.append({
                "question": str(q["question"])[:500],
                "options": [str(o)[:200] for o in q["options"]],
                "answer": str(q["answer"])[:200],
                "explanation": str(q.get("explanation", ""))[:500],
            })
    return cleaned


_SYSTEM_RECOMMEND = (
    "You recommend the single best next course for a learner on PathSurfers, an "
    "AI career-roadmap and learning platform. You will be given the learner's competency gaps and a list of "
    "REAL available courses (id, title, category, level). You MUST pick only from that list "
    "— never invent a course. Respond with ONLY JSON: "
    '{"course_id": int, "reason": str}. "reason" is one short sentence explaining the pick '
    "in terms of the learner's specific gaps."
)


def ai_recommend_course(weak_domains, available_courses):
    """available_courses: list of sqlite3.Row/dict with id, title, category, level.
    Returns {'course_id':.., 'reason':..} constrained to a real course id, or None."""
    if not ai_enabled() or not available_courses:
        return None
    catalogue = "\n".join(
        f"- id={c['id']} | {c['title']} | category={c['category']} | level={c['level']}"
        for c in available_courses
    )
    user_prompt = (
        f"Learner's weak competency domains: {', '.join(weak_domains) if weak_domains else 'none identified'}.\n"
        f"Available courses:\n{catalogue}\n\nPick the single best next course id from the list above."
    )
    result = chat_json([
        {"role": "system", "content": _SYSTEM_RECOMMEND},
        {"role": "user", "content": user_prompt},
    ], max_tokens=300)
    if not result or "course_id" not in result:
        return None
    valid_ids = {c["id"] for c in available_courses}
    try:
        cid = int(result["course_id"])
    except (TypeError, ValueError):
        return None
    if cid not in valid_ids:
        return None
    return {"course_id": cid, "reason": str(result.get("reason", ""))[:300]}
