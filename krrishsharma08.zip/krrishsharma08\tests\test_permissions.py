import ast, os, unittest
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
class SourceSafetyTests(unittest.TestCase):
    def test_no_eval(self):
        source=open(os.path.join(ROOT,"app.py"),encoding="utf-8").read(); tree=ast.parse(source)
        calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=="eval"]
        self.assertFalse(calls)
if __name__=="__main__": unittest.main()
