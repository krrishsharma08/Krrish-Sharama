import ast, os, sqlite3, tempfile, unittest

ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

class GheeFinalTests(unittest.TestCase):
    def setUp(self):
        self.dbpath=os.path.join(ROOT,"database.db")
        self.db=sqlite3.connect(self.dbpath)
        self.db.row_factory=sqlite3.Row

    def tearDown(self):
        self.db.close()

    def test_analytics_competency_uses_real_schema(self):
        rows=self.db.execute("""
            SELECT cs.subject,ROUND(AVG(cs.score),1) score,COUNT(*) attempts
            FROM competency_scores cs
            JOIN competency_assessments ca ON ca.id=cs.assessment_id
            GROUP BY cs.subject ORDER BY score ASC
        """).fetchall()
        self.assertIsNotNone(rows)

    def test_study_material_exists_for_every_existing_course(self):
        course_ids=[r[0] for r in self.db.execute("SELECT id FROM courses").fetchall()]
        for cid in course_ids:
            self.assertGreaterEqual(self.db.execute("SELECT COUNT(*) FROM course_study_materials WHERE course_id=?",(cid,)).fetchone()[0], 1)

    def test_repository_ownership_is_strict(self):
        self.db.execute("INSERT OR REPLACE INTO repository_ownership(repository_id,uploaded_by) VALUES(?,?)",(1,"krrish"))
        self.db.commit()
        owner=self.db.execute("SELECT uploaded_by FROM repository_ownership WHERE repository_id=1").fetchone()[0]
        self.assertEqual(owner,"krrish")
        self.assertNotEqual(owner,"kid")
        self.db.execute("DELETE FROM repository_ownership WHERE repository_id=1")
        self.db.commit()

    def test_legacy_resources_have_no_inferred_owner(self):
        missing=self.db.execute("""
            SELECT COUNT(*) FROM repository r
            LEFT JOIN repository_ownership o ON o.repository_id=r.id
            WHERE o.repository_id IS NULL
        """).fetchone()[0]
        self.assertGreaterEqual(missing,0)

    def test_ghee_module_has_no_external_ai_client_imports(self):
        src=open(os.path.join(ROOT,"ghee_enhancements.py"),encoding="utf-8").read().lower()
        for token in ["openai","google.generativeai","anthropic","groq","openrouter","requests.post"]:
            self.assertNotIn(token,src)

if __name__=="__main__":
    unittest.main()
