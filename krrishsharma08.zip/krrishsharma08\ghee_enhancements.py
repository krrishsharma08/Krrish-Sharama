
"""PathSurfers GHEE additive layer.

This module is intentionally isolated from the existing application logic. It adds
bug fixes and richer behavior through Flask hooks, new tables, and new templates.
It never rewrites or updates existing rows as part of installation.
"""
import ast
import os
import difflib
import math
import re
import sqlite3
from datetime import datetime
from flask import jsonify, render_template, request, redirect, url_for, session, abort, flash

SAFE_RESOURCE_TYPES = {"Manual", "Report", "Case Study", "SOP", "PDF", "Presentation", "Document", "Link", "Video URL", "Recorded Lecture URL"}
ROLES = {"Leader", "Non-Reliable User", "Administrator"}

STOPWORDS = {
    "a","an","the","is","are","am","i","me","my","we","our","you","your","to","for",
    "of","in","on","at","and","or","with","about","what","which","where","how","can",
    "do","does","tell","show","please","this","that","it","be","should","would","could",
    "from","have","has","had","was","were","as","into","than","then","next"
}

INTENTS = {
    "GREETING": ["hello", "hi", "hey", "good morning", "good evening", "good afternoon"],
    "HELP": ["help", "what can you do", "commands", "capabilities"],
    "COURSE_SEARCH": ["find course", "search course", "available courses", "courses available", "course catalog"],
    "COURSE_RECOMMENDATION": ["recommend", "suggest course", "what should i learn", "learn next", "next course"],
    "COURSE_DETAILS": ["course details", "what do i learn", "course covers", "tell me about course"],
    "STUDY_MATERIAL": ["study material", "study materials", "notes", "learning material", "revision", "read about"],
    "LEARNING_PROGRESS": ["my progress", "how am i doing", "learning progress", "completed modules", "completion"],
    "ASSESSMENT_RESULT": ["assessment score", "assessment result", "my score", "test score", "quiz score", "performed in"],
    "COMPETENCY": ["competency", "skill gap", "competency assessment", "weak skill", "skills"],
    "TRAINER": ["my trainer", "trainer assigned", "find trainer", "trainer matching", "mentor"],
    "REPOSITORY_SEARCH": ["repository", "report", "document", "resource", "material about"],
    "CERTIFICATE": ["certificate", "certification", "certificate eligible", "certificate status"],
    "ANALYTICS": ["analytics", "analytics hub", "statistics", "stats", "dashboard metrics"],
    "PLATFORM_INFO": ["PathSurfers", "pathforge", "PathSurfers", "what is this platform"],
    "NAVIGATION": ["open", "go to", "where can i find", "take me"],
}

def _conn(app):
    return app.view_functions["home"].__globals__["get_db_connection"]()

def _norm(text):
    text = (text or "").lower().strip()
    text = re.sub(r"[^a-z0-9\s%+\-*/().]", " ", text)
    return re.sub(r"\s+", " ", text)

def _tokens(text):
    return [x for x in _norm(text).split() if x and x not in STOPWORDS]

def _best_intent(text):
    n = _norm(text)
    toks = set(_tokens(n))
    scores = []
    for intent, phrases in INTENTS.items():
        score = 0.0
        for phrase in phrases:
            p = _norm(phrase)
            pt = set(_tokens(p))
            if p in n:
                score += 5.0 + len(pt)
            if pt:
                score += 1.5 * len(toks & pt) / len(pt)
            # typo tolerance for individual query words
            for t in toks:
                if len(t) >= 4 and any(difflib.SequenceMatcher(None, t, w).ratio() >= 0.86 for w in pt):
                    score += 0.5
        scores.append((score, intent))
    scores.sort(reverse=True)
    return scores[0][1] if scores and scores[0][0] >= 1.5 else "UNKNOWN"

def _rank_rows(query, rows, fields):
    q = _tokens(query)
    if not q:
        return []
    ranked = []
    for row in rows:
        hay = " ".join(str(row[f] or "") for f in fields).lower()
        score = 0.0
        if _norm(query) in _norm(hay):
            score += 10
        for token in q:
            if token in hay:
                score += 2
            else:
                words = re.findall(r"[a-z0-9]+", hay)
                if any(difflib.SequenceMatcher(None, token, w).ratio() >= 0.84 for w in words if len(w) >= 4):
                    score += 0.8
        if score:
            ranked.append((score, row))
    ranked.sort(key=lambda x: (-x[0], str(x[1][fields[0]]).lower()))
    return [r for _, r in ranked]

def _course_context(conn, username, query):
    courses = conn.execute("""
        SELECT c.id,c.title,c.category,c.level,c.description,
               GROUP_CONCAT(DISTINCT m.title) module_titles
        FROM courses c
        LEFT JOIN course_modules m ON m.course_id=c.id
        GROUP BY c.id
    """).fetchall()
    return _rank_rows(query, courses, ["title","category","description","module_titles"])

def _save_context(conn, username, role, intent, topic=None, course_id=None, repository_id=None):
    conn.execute("""
        INSERT INTO mrwhite_context(username,role,last_intent,last_topic,last_course_id,last_repository_id,updated_at)
        VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)
        ON CONFLICT(username) DO UPDATE SET
            role=excluded.role,last_intent=excluded.last_intent,last_topic=excluded.last_topic,
            last_course_id=COALESCE(excluded.last_course_id,mrwhite_context.last_course_id),
            last_repository_id=COALESCE(excluded.last_repository_id,mrwhite_context.last_repository_id),
            updated_at=CURRENT_TIMESTAMP
    """, (username, role, intent, topic, course_id, repository_id))

def _get_context(conn, username):
    return conn.execute("SELECT * FROM mrwhite_context WHERE username=?", (username,)).fetchone()

def _safe_calculate(raw):
    # Only activate when the query looks mathematical.
    n = raw.lower().replace("×","*").replace("^","**")
    if not any(ch.isdigit() for ch in n):
        return None
    if not any(x in n for x in ["calculate","compute","solve","what is","=", "+","-","*","/","sqrt","sin","cos","tan","log"]):
        return None
    expr = n
    expr = re.sub(r"(?i)\b(calculate|compute|solve|what is|the answer to|please)\b", "", expr)
    expr = expr.replace("x", "*")
    # Keep only an expression-like character set.
    if not re.fullmatch(r"[\d\s+\-*/().,_a-zA-Z*]+", expr):
        return None
    expr = expr.replace(",", "")
    allowed = {"sqrt": math.sqrt, "sin": math.sin, "cos": math.cos, "tan": math.tan, "log": math.log10, "pi": math.pi, "e": math.e}
    def ev(node):
        if isinstance(node, ast.Expression): return ev(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int,float)): return node.value
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd,ast.USub)):
            v=ev(node.operand); return v if isinstance(node.op,ast.UAdd) else -v
        if isinstance(node, ast.BinOp) and isinstance(node.op,(ast.Add,ast.Sub,ast.Mult,ast.Div,ast.Pow,ast.Mod)):
            a,b=ev(node.left),ev(node.right)
            if isinstance(node.op,ast.Pow) and abs(b)>12: raise ValueError()
            if isinstance(node.op,ast.Div) and b==0: raise ValueError()
            return {ast.Add:a+b,ast.Sub:a-b,ast.Mult:a*b,ast.Div:a/b,ast.Pow:a**b,ast.Mod:a%b}[type(node.op)]
        if isinstance(node, ast.Name) and node.id in allowed: return allowed[node.id]
        if isinstance(node, ast.Call) and isinstance(node.func,ast.Name) and node.func.id in allowed and len(node.args)==1:
            return allowed[node.func.id](ev(node.args[0]))
        raise ValueError()
    try:
        value=ev(ast.parse(expr, mode="eval"))
        if isinstance(value,(int,float)) and math.isfinite(value):
            return value
    except Exception:
        return None
    return None

def _assistant_response(conn, username, role, raw):
    n = _norm(raw)
    intent = _best_intent(n)
    ctx = _get_context(conn, username)
    topic = None
    course_id = None
    repo_id = None

    calc = _safe_calculate(raw)
    if calc is not None:
        return f"🧮 The result is **{calc:g}**.", "GENERAL_KNOWLEDGE", None, None, None

    if intent == "GREETING":
        return "Hello! I'm Mr.White. I can search your courses and repository, explain study material, check your progress and assessments, and guide you around PathSurfers.", intent, None, None, None

    if intent == "HELP":
        return ("I can help with your actual platform data. Try **“recommend a course”**, **“show my progress”**, "
                "**“find Python material”**, **“what was my assessment score?”**, **“what is my weakest competency?”**, "
                "or **“who is my trainer?”**."), intent, None, None, None

    if intent == "PLATFORM_INFO":
        return ("PathSurfers is the PathSurfers digital capacity-building and learning platform. "
                "It brings courses, competency development, assessments, trainers, knowledge resources and learning progress into one place."), intent, "PathSurfers", None, None

    if intent == "COURSE_SEARCH":
        rows = _course_context(conn, username, n)
        if not rows:
            rows = conn.execute("SELECT id,title,category,level,description,'' module_titles FROM courses ORDER BY title").fetchall()
        if not rows:
            return "There are no courses in the catalog yet.", intent, None, None, None
        top=rows[:5]
        return "I found these relevant courses: " + "; ".join(f"**{r['title']}** ({r['level']}, {r['category']})" for r in top) + ".", intent, top[0]["category"], top[0]["id"], None

    if intent in {"COURSE_RECOMMENDATION","STUDY_MATERIAL","COURSE_DETAILS"}:
        query=n
        if ctx and (ctx["last_topic"] or ctx["last_course_id"]):
            # Follow-up questions inherit the previous course when they lack a new subject.
            if len(_tokens(n)) <= 5 and ctx["last_course_id"]:
                course_id=ctx["last_course_id"]
        rows=_course_context(conn, username, query)
        if course_id:
            rows=[r for r in rows if r["id"]==course_id] or conn.execute("""
                SELECT c.id,c.title,c.category,c.level,c.description,GROUP_CONCAT(m.title) module_titles
                FROM courses c LEFT JOIN course_modules m ON m.course_id=c.id WHERE c.id=? GROUP BY c.id
            """,(course_id,)).fetchall()
        if not rows and ctx and ctx["last_topic"]:
            rows=_course_context(conn, ctx["last_topic"])
        if not rows:
            return "I couldn't find a matching course in the current catalog. Try the course name or subject, such as Python, Seismology, Oceanography or Meteorology.", intent, None, None, None
        c=rows[0]; course_id=c["id"]; topic=c["category"]
        modules=conn.execute("SELECT title,content FROM course_modules WHERE course_id=? ORDER BY order_index,id",(course_id,)).fetchall()
        materials=conn.execute("SELECT section_title,material FROM course_study_materials WHERE course_id=? ORDER BY sequence_no,id",(course_id,)).fetchall()
        if intent=="COURSE_RECOMMENDATION":
            reason=c["description"] or f"{c['category']} learning at {c['level']} level"
            return f"I'd start with **{c['title']}**. It is a {c['level'].lower()}-level {c['category']} course; {reason}", intent, topic, course_id, None
        if intent=="COURSE_DETAILS":
            module_names=", ".join(m["title"] for m in modules[:5]) or "module content is not published yet"
            return f"**{c['title']}** covers {c['category']} at {c['level']} level. Current modules include: {module_names}.", intent, topic, course_id, None
        if materials:
            material=materials[0]
            return f"Here is the **{material['section_title']}** study material for **{c['title']}**:\n\n{material['material']}", intent, topic, course_id, None
        if modules:
            return f"**{c['title']}** has these learning modules: " + "; ".join(m["title"] for m in modules) + ". Detailed study material has not been published for this course yet.", intent, topic, course_id, None
        return f"The course **{c['title']}** is in the catalog, but its detailed study material is not published yet.", intent, topic, course_id, None

    if intent=="LEARNING_PROGRESS":
        rows=conn.execute("""
            SELECT c.title,COUNT(m.id) total_modules,
                   SUM(CASE WHEN COALESCE(p.completed,0)=1 THEN 1 ELSE 0 END) completed_modules
            FROM enrollments e JOIN courses c ON c.id=e.course_id
            LEFT JOIN course_modules m ON m.course_id=c.id
            LEFT JOIN user_module_progress p ON p.module_id=m.id AND p.username=?
            WHERE e.username=? GROUP BY c.id ORDER BY c.title
        """,(username,username)).fetchall()
        if not rows: return "You are not enrolled in a course yet, so there is no course progress to report.", intent, None, None, None
        details=[]
        for r in rows:
            total=int(r["total_modules"] or 0); done=int(r["completed_modules"] or 0)
            pct=round(done/total*100) if total else 0
            details.append(f"**{r['title']}**: {done}/{total} modules ({pct}%)")
        return "Your current learning progress is: " + "; ".join(details) + ".", intent, None, None, None

    if intent=="ASSESSMENT_RESULT":
        rows=conn.execute("""
            SELECT c.title,ca.course_id,ca.score,ca.passed,ca.completed_at
            FROM course_assessments ca JOIN courses c ON c.id=ca.course_id
            WHERE ca.username=? ORDER BY ca.completed_at DESC,ca.id DESC LIMIT 5
        """,(username,)).fetchall()
        if not rows: return "You haven't completed a course assessment yet, so I don't have a score to report.", intent, None, None, None
        r=rows[0]
        return f"Your latest recorded assessment is **{r['title']}**: **{r['score']}%** — {'passed' if r['passed'] else 'not passed'}.", intent, r["title"], r["course_id"] if "course_id" in r.keys() else None, None

    if intent=="UNKNOWN" and ctx and ctx["last_intent"]=="ASSESSMENT_RESULT" and any(w in n for w in ["improve","better","increase","raise","weak"]):
        row=conn.execute("""
            SELECT c.title,ca.score
            FROM course_assessments ca JOIN courses c ON c.id=ca.course_id
            WHERE ca.username=? ORDER BY ca.completed_at DESC,ca.id DESC LIMIT 1
        """,(username,)).fetchone()
        if row:
            return (f"Your latest recorded score is **{row['score']}%** in **{row['title']}**. To improve, review the course's study material, revisit the modules where you were least confident, then retake the assessment when the platform allows it."), "ASSESSMENT_IMPROVEMENT", row["title"], None, None

    if intent=="COMPETENCY":
        rows=conn.execute("""
            SELECT cs.subject,ROUND(AVG(cs.score),1) score,COUNT(*) attempts
            FROM competency_scores cs JOIN competency_assessments ca ON ca.id=cs.assessment_id
            WHERE ca.username=? GROUP BY cs.subject ORDER BY score ASC
        """,(username,)).fetchall()
        if not rows: return "You don't have a competency score recorded yet. Complete a competency assessment to build your learning-gap picture.", intent, None, None, None
        weak=rows[0]
        return f"Your lowest recorded competency area is **{weak['subject']}** at **{weak['score']}%** across {weak['attempts']} record(s). I'd use that area as the next learning priority.", intent, weak["subject"], None, None

    if intent=="TRAINER":
        rows=conn.execute("""
            SELECT ta.subject,COALESCE(u.fullname,u.username) trainer,ta.status,ta.match_score
            FROM trainer_assignments ta JOIN users u ON u.username=ta.trainer_username
            WHERE ta.trainee_username=? ORDER BY ta.id DESC LIMIT 3
        """,(username,)).fetchall()
        if not rows: return "You don't have a trainer assignment recorded yet. Open Trainer Matching to find an available match.", intent, None, None, None
        return "Your recent trainer assignment(s): " + "; ".join(f"**{r['trainer']}** for {r['subject']} ({r['status']})" for r in rows) + ".", intent, rows[0]["subject"], None, None

    if intent=="REPOSITORY_SEARCH":
        rows=conn.execute("SELECT id,title,category,type,summary,content FROM repository ORDER BY id DESC").fetchall()
        ranked=_rank_rows(n, rows, ["title","category","type","summary","content"])
        if not ranked: return "I couldn't find a matching repository resource. Try a topic or document title.", intent, None, None, None
        top=ranked[:5]
        return "I found these repository resources: " + "; ".join(f"**{r['title']}** ({r['type']}, {r['category']})" for r in top) + ".", intent, top[0]["category"], None, top[0]["id"]

    if intent=="CERTIFICATE":
        rows=conn.execute("""
            SELECT c.title,cert.status,cert.issued_at
            FROM certificates cert JOIN courses c ON c.id=cert.course_id
            WHERE cert.username=? ORDER BY cert.issued_at DESC LIMIT 5
        """,(username,)).fetchall()
        if rows:
            return "Your recorded certificates: " + "; ".join(f"**{r['title']}** ({r['status']})" for r in rows) + ".", intent, None, None, None
        return "I don't see an issued certificate for your account yet. Eligibility depends on the course's server-side completion and assessment requirements.", intent, None, None, None

    if intent=="ANALYTICS":
        if role in ("Administrator","Leader"):
            u=conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
            c=conn.execute("SELECT COUNT(*) FROM courses").fetchone()[0]
            e=conn.execute("SELECT COUNT(*) FROM enrollments").fetchone()[0]
            return f"The organization currently has **{u} users**, **{c} courses**, and **{e} enrollments** recorded. Open Analytics Hub for the detailed breakdown.", intent, None, None, None
        rows=conn.execute("""
            SELECT COUNT(DISTINCT e.course_id) enrolled,
                   COALESCE(ROUND(AVG(ca.score),1),0) avg_score
            FROM users u LEFT JOIN enrollments e ON e.username=u.username
            LEFT JOIN course_assessments ca ON ca.username=u.username
            WHERE u.username=?
        """,(username,)).fetchone()
        return f"Your account currently shows **{rows['enrolled']} enrolled course(s)** and an average recorded assessment score of **{rows['avg_score']}%**. Open Analytics Hub for the full view.", intent, None, None, None

    if intent=="NAVIGATION":
        mappings={"analytics":"analytics","course":"courses","repository":"repository","trainer":"trainer","competency":"competencies","certificate":"account","progress":"analytics","chat":"chat"}
        for key,target in mappings.items():
            if key in n:
                return f"Open **{target.title()}** from the navigation menu.", intent, target, None, None

    # Follow-up awareness: use last context for short questions.
    if ctx and ctx["last_course_id"] and len(_tokens(n)) <= 6:
        c=conn.execute("SELECT title,category FROM courses WHERE id=?",(ctx["last_course_id"],)).fetchone()
        if c:
            return f"You're referring to **{c['title']}**. Ask me about its modules, study material, learning outcomes or assessment.", intent, c["category"], c["id"], None

    return ("I can work with the information stored in PathSurfers, but I don't want to invent an answer. "
            "Try asking about a course, study material, your progress, assessment, competency, trainer, repository, certificate, or Analytics Hub."), "UNKNOWN", None, None, None

def install_ghee(app):
    # Apply only the new schema. Existing rows are never updated here.
    with app.app_context():
        conn=_conn(app)
        migration_path=app.config.get("GHEE_MIGRATION") or os.path.join(app.root_path, "migrations", "004_ghee_enhancements.sql")
        if migration_path:
            with open(migration_path, encoding="utf-8") as fh:
                conn.executescript(fh.read())
            conn.commit()
        conn.close()

    @app.context_processor
    def ghee_context():
        owned=set()
        if session.get("user"):
            conn=_conn(app)
            owned={r[0] for r in conn.execute("SELECT repository_id FROM repository_ownership WHERE uploaded_by=?", (session["user"],)).fetchall()}
            conn.close()
        return {"ghee_owned_repository_ids": owned}

    @app.before_request
    def ghee_interceptor():
        # The existing Analytics rule is the source of the reported 500. Handle the
        # URL here with a corrected, isolated query path before the legacy handler.
        if request.path == "/analytics" and request.method == "GET":
            if not session.get("user"):
                return redirect(url_for("login"))
            conn=_conn(app); username=session["user"]; role=session.get("role")
            try:
                if role in ("Administrator","Leader"):
                    users_count=conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
                    trainees=conn.execute("SELECT COUNT(*) FROM users WHERE role='Trainee'").fetchone()[0]
                    trainers=conn.execute("SELECT COUNT(*) FROM users WHERE role IN ('Leader','Non-Reliable User')").fetchone()[0]
                    courses=conn.execute("SELECT COUNT(*) FROM courses").fetchone()[0]
                    enrollments=conn.execute("SELECT COUNT(*) FROM enrollments").fetchone()[0]
                    completions=conn.execute("""SELECT COUNT(*) FROM (
                        SELECT e.username,e.course_id
                        FROM enrollments e JOIN course_modules cm ON cm.course_id=e.course_id
                        LEFT JOIN user_module_progress p ON p.username=e.username AND p.module_id=cm.id AND p.completed=1
                        GROUP BY e.username,e.course_id
                        HAVING COUNT(cm.id)>0 AND COUNT(p.id)=COUNT(cm.id)
                    )""").fetchone()[0]
                    attempts=conn.execute("SELECT COUNT(*) FROM assessment_attempts").fetchone()[0]
                    avg_assessment=conn.execute("SELECT AVG(score) FROM course_assessments").fetchone()[0] or 0
                    certs=conn.execute("SELECT COUNT(*) FROM certificates WHERE status='Issued'").fetchone()[0]
                    competency=conn.execute("""
                        SELECT cs.subject,ROUND(AVG(cs.score),1) score,COUNT(*) attempts
                        FROM competency_scores cs JOIN competency_assessments ca ON ca.id=cs.assessment_id
                        GROUP BY cs.subject ORDER BY score ASC LIMIT 8
                    """).fetchall()
                    feedback=conn.execute("SELECT AVG(rating) average_rating,COUNT(*) responses FROM course_feedback").fetchone()
                    metrics={"users":users_count,"trainees":trainees,"trainers":trainers,"courses":courses,"enrollments":enrollments,
                             "completed_courses":completions,"completed_modules":conn.execute("SELECT COUNT(*) FROM user_module_progress WHERE completed=1").fetchone()[0],
                             "assessment_attempts":attempts,"average_assessment_score":round(float(avg_assessment),1),
                             "certificates":certs}
                    scope="Organization-wide"
                else:
                    enrolled_count=conn.execute("SELECT COUNT(DISTINCT course_id) FROM enrollments WHERE username=?", (username,)).fetchone()[0]
                    completed_modules_count=conn.execute("SELECT COUNT(*) FROM user_module_progress WHERE username=? AND completed=1",(username,)).fetchone()[0]
                    avg_score=conn.execute("SELECT AVG(score) FROM course_assessments WHERE username=?",(username,)).fetchone()[0] or 0
                    cert_count=conn.execute("SELECT COUNT(*) FROM certificates WHERE username=? AND status='Issued'",(username,)).fetchone()[0]
                    completed=conn.execute("""
                        SELECT COUNT(*) FROM (
                          SELECT e.course_id
                          FROM enrollments e JOIN course_modules cm ON cm.course_id=e.course_id
                          LEFT JOIN user_module_progress p ON p.username=? AND p.module_id=cm.id AND p.completed=1
                          WHERE e.username=?
                          GROUP BY e.course_id
                          HAVING COUNT(cm.id)>0 AND COUNT(p.id)=COUNT(cm.id)
                        )
                    """,(username,username)).fetchone()[0]
                    metrics_row={"enrolled":enrolled_count,"completed_modules":completed_modules_count,
                                 "average_assessment_score":round(float(avg_score),1),"certificates":cert_count}
                    competency=conn.execute("""
                        SELECT cs.subject,ROUND(AVG(cs.score),1) score,COUNT(*) attempts
                        FROM competency_scores cs JOIN competency_assessments ca ON ca.id=cs.assessment_id
                        WHERE ca.username=? GROUP BY cs.subject ORDER BY score ASC LIMIT 8
                    """,(username,)).fetchall()
                    feedback=conn.execute("""SELECT AVG(rating) average_rating,COUNT(*) responses
                                             FROM course_feedback WHERE trainee_username=?""",(username,)).fetchone()
                    metrics=dict(metrics_row); metrics["completed_courses"]=completed
                    scope="Private learning view"
                return render_template("analytics_ghee.html",metrics=metrics,competency=competency,feedback=feedback,role=role,username=username,scope=scope)
            finally:
                conn.close()

        # Enforce repository ownership for the existing delete URL. This is a backend
        # check, so changing the resource ID cannot bypass it.
        m=re.fullmatch(r"/repository/delete/(\d+)", request.path)
        if m and request.method=="POST":
            if not session.get("user"):
                return redirect(url_for("login"))
            doc_id=int(m.group(1)); conn=_conn(app)
            row=conn.execute("""
                SELECT r.id,o.uploaded_by FROM repository r
                LEFT JOIN repository_ownership o ON o.repository_id=r.id WHERE r.id=?
            """,(doc_id,)).fetchone()
            if not row:
                conn.close(); flash("Resource not found."); return redirect(url_for("repository"))
            if row["uploaded_by"] != session["user"]:
                conn.close()
                abort(403)
            conn.execute("DELETE FROM repository WHERE id=?",(doc_id,))
            conn.commit(); conn.close()
            flash("Your resource was deleted successfully.")
            return redirect(url_for("repository"))

        # Add ownership to all newly-created repository records through a dedicated,
        # isolated handler. The old endpoint remains available but its records cannot
        # be deleted without an ownership record.
        if request.path=="/repository/add-ghee" and request.method=="POST":
            if not session.get("user") or session.get("role") not in ROLES:
                abort(403)
            title=request.form.get("title","").strip()
            category=request.form.get("category","").strip()
            typ=request.form.get("resource_type","Manual").strip()
            summary=(request.form.get("description","").strip() or request.form.get("summary","").strip())
            content=request.form.get("content","").strip() or summary
            if not title or not category or not summary:
                flash("Title, category and description are required."); return redirect(url_for("repository"))
            if typ not in SAFE_RESOURCE_TYPES: abort(400)
            conn=_conn(app)
            cur=conn.execute("""INSERT INTO repository(title,category,type,summary,content,published_date)
                               VALUES(?,?,?,?,?,DATE('now'))""",(title[:160],category[:100],typ,summary[:500],content[:10000]))
            conn.execute("INSERT INTO repository_ownership(repository_id,uploaded_by) VALUES(?,?)",(cur.lastrowid,session["user"]))
            conn.commit(); conn.close()
            flash("Your knowledge resource was published.")
            return redirect(url_for("repository"))

        if request.path=="/api/chat" and request.method=="POST":
            if not session.get("user"):
                return jsonify({"status":"error","message":"Unauthorized"}),401
            data=request.get_json(silent=True) or {}
            raw=str(data.get("message","")).strip()
            if not raw: return jsonify({"status":"error","message":"Empty message"}),400
            conn=_conn(app)
            try:
                response,intent,topic,course_id,repo_id=_assistant_response(conn,session["user"],session.get("role"),raw)
                _save_context(conn,session["user"],session.get("role"),intent,topic,course_id,repo_id)
                conn.commit()
            finally:
                conn.close()
            return jsonify({"status":"success","response":response,"intent":intent})

    # The course detail route remains untouched. This context processor supplies
    # study material based on its course_id, and the template renders it.
    @app.context_processor
    def ghee_course_material_context():
        course_id=request.view_args.get("course_id") if request.view_args else None
        if not course_id:
            return {"ghee_study_materials":[]}
        try:
            conn=_conn(app)
            rows=conn.execute("SELECT section_title,material FROM course_study_materials WHERE course_id=? ORDER BY sequence_no,id",(course_id,)).fetchall()
            conn.close()
            return {"ghee_study_materials":rows}
        except sqlite3.Error:
            return {"ghee_study_materials":[]}
