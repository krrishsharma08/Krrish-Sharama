-- PathSurfers course-content completeness: every published course has at least
-- one first-party study guide so Course Detail never opens to an empty study tab.
INSERT INTO course_study_materials(course_id, section_title, material, sequence_no)
SELECT c.id, 'Core study guide',
       CASE c.id
       WHEN 5 THEN 'SQL: master SELECT, JOIN, GROUP BY and window functions; model facts and dimensions before querying. Statistics: review probability, distributions, confidence intervals and hypothesis tests, then connect each method to a concrete experiment. Data engineering: build a reproducible CSV/JSON ETL pipeline with validation, idempotent runs and clear data-quality checks.'
       WHEN 6 THEN 'LLM engineering: understand tokens, embeddings, context windows and transformer behavior at a practical level. Reliable applications should use explicit prompts, structured outputs, schema validation, retries, grounding and evaluation. For a portfolio project, define an input/output contract, safety boundaries, observability and a deterministic fallback.'
       WHEN 7 THEN 'MLOps: make environments and builds reproducible, version models and datasets, and track experiments. Serving: design a small inference API with latency budgets, caching and concurrency limits. Production readiness: add health checks, structured logs, monitoring, rollback strategy and secret management.'
       WHEN 8 THEN 'Responsible AI: document data provenance, intended use, limitations and human oversight. Evaluate bias, robustness, privacy and distribution shift. Practice threat modeling for prompt injection and unsafe outputs, then create a risk register with measurable acceptance criteria and a red-team test plan.'
       WHEN 9 THEN 'Backend and cloud foundations: understand HTTP, REST, authentication, databases, object storage and queues. Deployment: use environment-based configuration, health checks and container concepts. Scaling: combine indexes, caching, rate limits and asynchronous work while designing graceful degradation.'
       WHEN 10 THEN 'Computer vision systems: build image/video pipelines with reproducible preprocessing and dataset-quality checks. Evaluate models using confusion matrices, precision/recall, thresholds and failure-case slices. Finish with a complete CV portfolio application that includes reproducible inference, tests, latency measurements and documented limitations.'
       END,
       1
FROM courses c
WHERE c.id BETWEEN 5 AND 10
  AND NOT EXISTS (SELECT 1 FROM course_study_materials m WHERE m.course_id = c.id);

-- Clean up orphaned auxiliary rows that can be left by legacy demo-data deletion.
DELETE FROM mrwhite_conversations WHERE username NOT IN (SELECT username FROM users);
DELETE FROM user_regions WHERE username NOT IN (SELECT username FROM users);
