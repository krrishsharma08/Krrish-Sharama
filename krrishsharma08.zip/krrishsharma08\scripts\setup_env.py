import getpass, os, secrets
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
path=os.path.join(ROOT,'.env')
print('PathSurfers FAM — local environment setup')
print('Leave the Groq key blank if you want offline fallback only.')
key=getpass.getpass('GROQ_API_KEY: ').strip()
secret=secrets.token_urlsafe(48)
lines=[
 f'SECRET_KEY={secret}', 'FLASK_ENV=production','FLASK_DEBUG=0','AI_PROVIDER=groq' if key else 'AI_PROVIDER=offline',
 f'GROQ_API_KEY={key}','GROQ_MODEL=openai/gpt-oss-120b','GROQ_BASE_URL=https://api.groq.com/openai/v1/chat/completions',''
]
with open(path,'w',encoding='utf8') as f:f.write('\n'.join(lines))
print(f'Created {path}')
print('Your API key is stored only in the local .env file and is ignored by git.')
