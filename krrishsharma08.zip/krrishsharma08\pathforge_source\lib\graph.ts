import type { Roadmap } from "./schema";

export type Status = "completed" | "progress" | "available" | "locked";

export function computeStatus(nodes: Roadmap["nodes"], done: Set<string>, doing: Set<string>): Record<string, Status> {
  const out: Record<string, Status> = {};
  for (const n of nodes) {
    if (done.has(n.id)) out[n.id] = "completed";
    else if (n.prerequisites.every((p) => done.has(p))) out[n.id] = doing.has(n.id) ? "progress" : "available";
    else out[n.id] = "locked";
  }
  return out;
}

export const COL_W = 320;
export const ROW_H = 140;

export function layoutNodes(r: Roadmap): Record<string, { x: number; y: number }> {
  const pos: Record<string, { x: number; y: number }> = {};
  const groups = r.phases.map((p) => r.nodes.filter((n) => n.phaseId === p.id));
  const max = Math.max(1, ...groups.map((g) => g.length));
  groups.forEach((g, pi) => {
    const offset = ((max - g.length) * ROW_H) / 2;
    g.forEach((n, i) => (pos[n.id] = { x: pi * COL_W, y: offset + i * ROW_H }));
  });
  return pos;
}
