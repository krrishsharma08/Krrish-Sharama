import { z } from "zod";

const str = (max = 600) => z.string().transform((s) => s.trim().slice(0, max));

export const InputSchema = z.object({
  dreamJob: z.string().trim().min(3, "Describe your dream job in a few words").max(200, "Please keep it under 200 characters"),
  level: z.enum(["Beginner", "Intermediate", "Advanced"]).catch("Beginner"),
  skills: z.string().max(300).optional().default(""),
  hoursPerWeek: z.coerce.number().min(1).max(80).catch(10),
  months: z.coerce.number().min(1).max(36).catch(6),
  companyType: z.string().max(60).optional().default(""),
});
export type GenInput = z.infer<typeof InputSchema>;

export const NodeSchema = z.object({
  id: z.string().min(1),
  phaseId: z.string().min(1),
  title: str(80).pipe(z.string().min(1)),
  type: z.enum(["skill", "project", "role", "cert", "interview", "target"]).catch("skill"),
  description: str(400).catch(""),
  skills: z.array(str(60)).catch([]).transform((a) => a.slice(0, 8)),
  prerequisites: z.array(z.string()).catch([]),
  hours: z.coerce.number().catch(10).transform((n) => Math.min(400, Math.max(1, Math.round(n)))),
  difficulty: z.enum(["easy", "medium", "hard"]).catch("medium"),
  optional: z.boolean().catch(false),
});

export const PhaseSchema = z.object({
  id: z.string().min(1),
  title: str(60),
  description: str(300).catch(""),
});

export const RoadmapSchema = z.object({
  title: str(100),
  targetRole: str(100),
  companyType: str(60).catch(""),
  summary: str(600),
  phases: z.array(PhaseSchema).min(2).max(8),
  nodes: z.array(NodeSchema).min(6).max(40),
});
export type Roadmap = z.infer<typeof RoadmapSchema>;
export type RoadmapNode = Roadmap["nodes"][number];
export type StoredRoadmap = Roadmap & { id: string; createdAt: string; input: GenInput };

export const NodeDetailsSchema = z.object({
  whyItMatters: str(600),
  concepts: z.array(str(100)).catch([]).transform((a) => a.slice(0, 8)),
  weekendProject: z.object({
    title: str(100),
    description: str(500),
    hours: z.coerce.number().catch(6),
  }),
  githubSuggestion: str(300).catch(""),
  portfolioEvidence: str(400).catch(""),
  interviewQuestions: z.array(str(250)).catch([]).transform((a) => a.slice(0, 5)),
  commonMistakes: z.array(str(250)).catch([]).transform((a) => a.slice(0, 4)),
  resources: z
    .array(z.object({ name: str(100), kind: str(40).catch("Resource"), why: str(200).catch("") }))
    .catch([])
    .transform((a) => a.slice(0, 5)),
});
export type NodeDetails = z.infer<typeof NodeDetailsSchema>;

export const ReplanSchema = z.object({
  explanation: str(500),
  skipNodeIds: z.array(z.string()).catch([]),
  thisWeek: z.array(str(120)).catch([]).transform((a) => a.slice(0, 4)),
});

/** Guarantees a valid DAG: prerequisites may only point to EARLIER nodes, one target, valid phases. */
export function sanitizeRoadmap(r: Roadmap): Roadmap {
  const phaseIds = new Set(r.phases.map((p) => p.id));
  const seen = new Set<string>();
  const nodes: RoadmapNode[] = [];
  for (const n of r.nodes) {
    if (seen.has(n.id)) continue;
    const prerequisites = n.prerequisites.filter((p) => seen.has(p));
    seen.add(n.id);
    nodes.push({ ...n, prerequisites, phaseId: phaseIds.has(n.phaseId) ? n.phaseId : r.phases[0].id });
  }
  let ti = nodes.findIndex((n) => n.type === "target");
  if (ti === -1) {
    ti = nodes.length - 1;
    nodes[ti] = { ...nodes[ti], type: "target" };
  }
  if (nodes[ti].prerequisites.length === 0) {
    const referenced = new Set(nodes.flatMap((n) => n.prerequisites));
    nodes[ti].prerequisites = nodes.filter((n, i) => i < ti && !n.optional && !referenced.has(n.id)).map((n) => n.id);
  }
  return { ...r, nodes };
}
