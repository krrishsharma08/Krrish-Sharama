#!/usr/bin/env bash
set -euo pipefail

# PathSurfers reproducible development bootstrap.
# Requires an internet connection only for the first installation.
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PYTHON_BIN="${PYTHON_BIN:-python3}"
NODE_BIN="${NODE_BIN:-node}"
NPM_BIN="${NPM_BIN:-npm}"

say(){ printf '\n[PathSurfers] %s\n' "$*"; }
fail(){ printf '\n[PathSurfers][ERROR] %s\n' "$*" >&2; exit 1; }

command -v "$PYTHON_BIN" >/dev/null || fail "Python 3 is required."
command -v "$NODE_BIN" >/dev/null || fail "Node.js 20+ is required for the PathForge source build."
command -v "$NPM_BIN" >/dev/null || fail "npm is required."

say "Checking Python environment"
"$PYTHON_BIN" -m venv "$ROOT/.venv" 2>/dev/null || true
# shellcheck disable=SC1091
source "$ROOT/.venv/bin/activate"
python -m pip install --upgrade pip
python -m pip install -r "$ROOT/requirements.txt"

say "Installing PathForge frontend dependencies"
cd "$ROOT/pathforge_source"
"$NPM_BIN" ci
cd "$ROOT"

say "Running deterministic verification"
python scripts/verify_database.py
python -m compileall -q app.py app_original.py enhancements.py fam_enhancements.py ghee_enhancements.py ok_chat_enhancements.py pathforge_api.py services scripts models tests
node --check static/js/pathforge.js
node --check static/js/script.js

say "Bootstrap complete. Start Flask with:"
printf '  source .venv/bin/activate && python app.py\n'
