
import os, sqlite3, sys
BASE=os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0,BASE); DB=os.path.join(BASE,"database.db")
QUESTIONS=[
("Programming","Python basics","Beginner","Which Python type stores an ordered collection that can be changed?","list",["list","tuple","str","int"]),
("Programming","Pandas","Intermediate","Which Pandas method removes rows containing missing values?","dropna()",["dropna()","fillna()","merge()","groupby()"]),
("Data Analysis","Data cleaning","Beginner","Which measure represents the middle value of an ordered dataset?","Median",["Mean","Median","Mode","Range"]),
("Oceanography","CTD","Intermediate","Which CTD measurement is used with temperature to help derive salinity?","Conductivity",["Conductivity","Wind speed","Pressure only","Seismic amplitude"]),
("Seismology","Seismic waves","Beginner","Which body wave generally arrives first because it travels faster?","P-Wave",["P-Wave","S-Wave","Love Wave","Rayleigh Wave"]),
("Meteorology","Pressure","Intermediate","A rapid fall in atmospheric pressure can be an indicator of what?","Approaching storm system",["Approaching storm system","Stable clear weather","Tectonic uplift","Ocean salinity change"])
]
def main():
    con=sqlite3.connect(DB); con.row_factory=sqlite3.Row
    # Fill the existing empty course-module table without changing courses/enrollments.
    for c in con.execute("SELECT * FROM courses").fetchall():
        if con.execute("SELECT 1 FROM course_modules WHERE course_id=? LIMIT 1",(c["id"],)).fetchone(): continue
        modules=[("Core Concepts","Understand core concepts, terminology and operational context.",1),
                 ("Practical Workflow","Apply concepts to realistic industry datasets and workflows.",2),
                 ("Assessment & SOP","Review procedures and prepare for competency assessment.",3)]
        con.executemany("INSERT INTO course_modules(course_id,title,content,order_index) VALUES(?,?,?,?)",
                        [(c["id"],a,b,o) for a,b,o in modules])
    # Use existing non-trainee accounts as trainer profiles; no new personal identities are invented.
    trainer_specs=[
      ("krrish","Team Lead","PathSurfers","Professional qualification",3,"Python, Data Analysis, Seismology"),
      ("shubh","Domain Trainer","PathSurfers","Professional qualification",2,"Meteorology, Oceanography")
    ]
    for u,desig,org,qual,exp,spec in trainer_specs:
        if con.execute("SELECT 1 FROM users WHERE username=? AND role!='Trainee'",(u,)).fetchone():
            con.execute("""INSERT OR IGNORE INTO trainer_profiles(username,designation,organization,qualification,experience_years,bio,specialization,performance_score,availability_status)
                           VALUES(?,?,?,?,?,?,?,?,?)""",(u,desig,org,qual,exp,"Trainer profile added by the PathSurfers enhancement layer.",spec,0,"Available"))
    expertise=[
      ("krrish","Programming","Python","Advanced"),("krrish","Data Analysis","Scientific data","Advanced"),
      ("krrish","Seismology","Seismic analysis","Expert"),("krrish","Meteorology","Operational data","Intermediate"),
      ("shubh","Meteorology","Forecasting","Expert"),("shubh","Oceanography","Telemetry","Advanced"),
      ("shubh","Data Analysis","Scientific data","Intermediate")
    ]
    for row in expertise: con.execute("INSERT OR IGNORE INTO trainer_expertise(trainer_username,subject,topic,skill_level) VALUES(?,?,?,?)",row)
    for u in ["krrish","shubh"]:
        for day in ["Monday","Wednesday","Friday"]:
            con.execute("INSERT OR IGNORE INTO trainer_availability(trainer_username,day,start_time,end_time,available) VALUES(?,?,?,?,1)",
                        (u,day,"10:00","16:00"))
    # Database-backed question bank.
    if con.execute("SELECT COUNT(*) FROM questions").fetchone()[0]==0:
        for subject,topic,diff,q,correct,opts in QUESTIONS:
            cur=con.execute("INSERT INTO questions(subject,topic,difficulty,question,explanation,marks,active) VALUES(?,?,?,?,?,?,1)",
                            (subject,topic,diff,q,"Review the related competency topic in the learning path.",1))
            qid=cur.lastrowid
            for i,opt in enumerate(opts,1):
                con.execute("INSERT INTO question_options(question_id,option_text,is_correct,option_order) VALUES(?,?,?,?)",(qid,opt,int(opt==correct),i))
    # Seed a baseline only when this existing demo account has no assessment history.
    if con.execute("SELECT 1 FROM users WHERE username='kid'").fetchone() and not con.execute("SELECT 1 FROM competency_assessments WHERE username='kid'").fetchone():
        cur=con.execute("INSERT INTO competency_assessments(username,assessment_type,total_questions,correct_answers) VALUES(?,?,?,?)",("kid","Demo baseline",5,2))
        aid=cur.lastrowid
        for subject,score in [("Programming",45),("Oceanography",82),("Seismology",55),("Meteorology",71),("Data Analysis",65)]:
            level="Beginner" if score<40 else "Developing" if score<60 else "Intermediate" if score<80 else "Advanced"
            con.execute("INSERT INTO competency_scores(assessment_id,subject,score,competency_level) VALUES(?,?,?,?)",(aid,subject,score,level))
    # Course-resource links for the existing repository records.
    if not con.execute("SELECT 1 FROM course_resources LIMIT 1").fetchone():
        for c in con.execute("SELECT id,category FROM courses").fetchall():
            r=con.execute("SELECT id FROM repository WHERE lower(category)=lower(?) ORDER BY id LIMIT 1",(c["category"],)).fetchone()
            m=con.execute("SELECT id FROM course_modules WHERE course_id=? ORDER BY order_index LIMIT 1",(c["id"],)).fetchone()
            if r: con.execute("INSERT OR IGNORE INTO course_resources(course_id,module_id,resource_id,resource_type) VALUES(?,?,?,?)",(c["id"],m["id"] if m else None,r["id"],"Repository"))
    # Add a real deadline/approval only if the new tables are empty, using existing accounts.
    if con.execute("SELECT COUNT(*) FROM training_deadlines").fetchone()[0]==0:
        con.execute("INSERT INTO training_deadlines(title,description,assigned_to,due_date,status) VALUES(?,?,?,?,?)",
                    ("Complete competency reassessment","Reassess identified critical gaps.","kid","2026-10-15","Pending"))
    if con.execute("SELECT COUNT(*) FROM approvals").fetchone()[0]==0:
        con.execute("INSERT INTO approvals(entity_type,entity_id,requested_by,status,reason) VALUES(?,?,?,?,?)",
                    ("Trainer profile","krrish","krrish","Pending","Demo approval workflow for PathSurfers presentation."))
    # Seed one feedback + completed assignment for dynamic trainer performance, only once.
    for trainer,subject,rating,score in [("krrish","Programming",5,78),("shubh","Oceanography",4,82)]:
        if con.execute("SELECT 1 FROM trainer_feedback WHERE trainee_username='kid' AND trainer_username=?",(trainer,)).fetchone() is None:
            con.execute("INSERT INTO trainer_feedback(trainee_username,trainer_username,rating,comments) VALUES(?,?,?,?)",
                        ("kid",trainer,rating,"Demo feedback record for performance analytics."))
        if con.execute("SELECT 1 FROM trainer_assignments WHERE trainee_username='kid' AND trainer_username=?",(trainer,)).fetchone() is None:
            con.execute("INSERT INTO trainer_assignments(trainer_username,trainee_username,subject,reason,match_score,status) VALUES(?,?,?,?,?,?)",
                        (trainer,"kid",subject,"Existing trainer profile matches the stored competency gap.",88.0,"Completed"))
        if not con.execute("SELECT 1 FROM course_assessments WHERE username='kid' AND score=?",(score,)).fetchone():
            cid=con.execute("SELECT id FROM courses WHERE category=? LIMIT 1",(subject,)).fetchone()
            if cid:
                con.execute("INSERT INTO course_assessments(username,course_id,score,passed,total_questions) VALUES(?,?,?,?,?)",
                            ("kid",cid["id"],score,1,5))
    if not con.execute("SELECT 1 FROM notifications WHERE username='kid'").fetchone():
        con.execute("INSERT INTO notifications(username,title,message,notification_type) VALUES(?,?,?,?)",
                    ("kid","Critical competency gap detected","Programming is below the configured critical threshold. Review the recommended learning path and trainer match.","competency"))
    if not con.execute("SELECT 1 FROM user_badges WHERE username='kid'").fetchone():
        con.execute("INSERT INTO user_badges(username,badge_code,title) VALUES(?,?,?)",
                    ("kid","ASSESSMENT_STARTED","Competency Explorer"))
    con.commit(); con.close(); print("Enhancement seed complete; existing records preserved.")
if __name__=="__main__": main()
