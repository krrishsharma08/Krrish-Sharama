import type { z } from "zod";

export class AIError extends Error {
  status: number;
  constructor(message: string, status = 500) {
    super(message);
    this.status = status;
  }
}

export type Msg = { role: "system" | "user" | "assistant"; content: string };
const API_URL = "https://api.x.ai/v1/chat/completions";

export async function askGrok(messages: Msg[], opts: { json?: boolean; temperature?: number } = {}): Promise<string> {
  const key = process.env.XAI_API_KEY;
  if (!key || key.includes("YOUR")) {
    throw new AIError("The server has no XAI_API_KEY. Add it to .env.local and restart the dev server.", 500);
  }
  const models = Array.from(new Set([process.env.XAI_MODEL || "grok-4", "grok-4", "grok-3"]));
  for (const model of models) {
    let res: Response;
    try {
      res = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
        body: JSON.stringify({
          model,
          messages,
          temperature: opts.temperature ?? 0.4,
          ...(opts.json ? { response_format: { type: "json_object" } } : {}),
        }),
        signal: AbortSignal.timeout(55000),
      });
    } catch (e) {
      const timeout = e instanceof Error && (e.name === "TimeoutError" || e.name === "AbortError");
      throw new AIError(timeout ? "The AI took too long. Please try again." : "Could not reach the AI service. Check your internet.", timeout ? 504 : 502);
    }
    if (res.ok) {
      const data = await res.json().catch(() => null);
      const content = data?.choices?.[0]?.message?.content;
      if (typeof content === "string" && content.trim()) return content;
      throw new AIError("The AI returned an empty answer. Please try again.", 502);
    }
    if (res.status === 401 || res.status === 403) throw new AIError("The AI key was rejected. Check XAI_API_KEY in .env.local.", 500);
    if (res.status === 429) throw new AIError("The AI is rate-limited right now. Wait a few seconds and retry.", 429);
    // 400/404 usually means this model name is unavailable: try the next one
  }
  throw new AIError("No AI model was available. Set XAI_MODEL in .env.local to a model your key can use (e.g. grok-4).", 502);
}

function extractJson(text: string): unknown {
  let t = text.trim().replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
  const a = t.indexOf("{");
  const b = t.lastIndexOf("}");
  if (a === -1 || b === -1) throw new Error("No JSON object found");
  t = t.slice(a, b + 1);
  return JSON.parse(t);
}

export async function generateStructured<T>(schema: z.ZodType<T, z.ZodTypeDef, any>, messages: Msg[], tries = 2): Promise<T> {
  let msgs = messages;
  for (let i = 0; i < tries; i++) {
    const raw = await askGrok(msgs, { json: true });
    let problem = "";
    try {
      const parsed = schema.safeParse(extractJson(raw));
      if (parsed.success) return parsed.data;
      problem = parsed.error.issues.slice(0, 6).map((x) => `${x.path.join(".")}: ${x.message}`).join("; ");
    } catch (e) {
      problem = "Invalid JSON: " + (e instanceof Error ? e.message : "parse error");
    }
    msgs = [
      ...messages,
      { role: "assistant", content: raw.slice(0, 6000) },
      { role: "user", content: `Your JSON failed validation (${problem}). Return ONLY the corrected, complete JSON object.` },
    ];
  }
  throw new AIError("The AI returned an unusable result. Please try again.", 502);
}
