import os,py_compile,glob
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
errors=[]
for p in glob.glob(os.path.join(ROOT,"**","*.py"),recursive=True):
    try: py_compile.compile(p,doraise=True)
    except Exception as e: errors.append((p,str(e)))
print("Python compile verification:", "PASS" if not errors else "FAIL")
for e in errors: print(e)
