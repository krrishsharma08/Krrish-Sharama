"""PathSurfers career-roadmap API.

Flask owns these endpoints so the whole product can run as one web application.
The original PathForge client remains a typed React/Next static application;
Groq is called only server-side and all model output is validated/sanitized.
"""
from __future__ import annotations

import json
import os
import re
import secrets
import urllib.error
import urllib.request
from datetime import datetime
from functools import wraps

from flask import jsonify, request, session, redirect, url_for

GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"
DEFAULT_MODEL = "llama-3.3-70b-versatile"
MAX_TEXT = 600

ROADMAP_SYSTEM = """You are PathSurfers, an expert career-roadmapping engine. Reverse-engineer a hyper-specific target job into a realistic dependency graph.
Return ONLY JSON with: title,targetRole,companyType,summary,phases,nodes.
phases: 5-6 chronological objects with id,title,description.
nodes: 16-24 objects in topological order. Each has id,phaseId,title,type,description,skills,prerequisites,hours,difficulty,optional. type is skill|project|role|cert|interview|target; difficulty is easy|medium|hard.
The graph must branch and merge. Include realistic portfolio projects and stepping-stone roles. Include 1-3 optional alternatives. Exactly one target node, last in the list.
Prerequisites may reference only earlier node ids. Do not invent certifications, companies, repositories or URLs. Respect the learner's current level, known skills, weekly hours and timeframe. Node titles under 50 characters. Make every node specific to the requested role."""

DETAILS_SYSTEM = """You are PathSurfers' milestone coach. Return ONLY JSON with whyItMatters,concepts,weekendProject,githubSuggestion,portfolioEvidence,interviewQuestions,commonMistakes,resources. Keep the advice specific to the target role. Resources must be real, well-known resources; never invent URLs or repositories. Weekend project must be achievable in one weekend."""

REPLAN_SYSTEM = """You are PathSurfers' conservative replanning engine. Given a student who already knows a skill and a list of remaining roadmap nodes, identify only nodes that are clearly redundant. Return ONLY JSON: explanation,skipNodeIds,thisWeek. Never remove nodes merely because they are related."""


def _current_user_required():
    return bool(session.get("user"))


def _clean(value, limit=MAX_TEXT):
    return str(value or "").strip()[:limit]


def _groq(messages, *, json_mode=False, temperature=0.35, max_tokens=3000, timeout=30):
    # Shared hardened client (User-Agent, model fallback, retries, timeouts).
    from services.groq_service import request_completion
    return request_completion(messages, json_mode=json_mode, temperature=temperature,
                              max_tokens=max_tokens, timeout=timeout)


def _json_response(text):
    from services.groq_service import parse_json
    return parse_json(text)


def _bounded_list(value, limit):
    return value if isinstance(value, list) else []


def sanitize_roadmap(r):
    if not isinstance(r, dict):
        raise ValueError("Roadmap must be an object")
    phases = r.get("phases") if isinstance(r.get("phases"), list) else []
    nodes_in = r.get("nodes") if isinstance(r.get("nodes"), list) else []
    if len(phases) < 2 or len(nodes_in) < 6:
        raise ValueError("The AI returned too little roadmap structure")
    phases = phases[:8]
    phase_ids = []
    phase_out = []
    for i, p in enumerate(phases):
        pid = _clean(p.get("id") or f"p{i+1}", 40)
        if pid in phase_ids:
            pid = f"p{i+1}"
        phase_ids.append(pid)
        phase_out.append({"id": pid, "title": _clean(p.get("title"), 60) or f"Phase {i+1}", "description": _clean(p.get("description"), 300)})
    seen = set()
    nodes = []
    for i, n in enumerate(nodes_in[:40]):
        nid = _clean(n.get("id") or f"n{i+1}", 60)
        if not nid or nid in seen:
            continue
        seen.add(nid)
        prereq = [str(x) for x in n.get("prerequisites", [])] if isinstance(n.get("prerequisites"), list) else []
        prereq = [x for x in prereq if x in seen]
        typ = n.get("type") if n.get("type") in {"skill","project","role","cert","interview","target"} else "skill"
        diff = n.get("difficulty") if n.get("difficulty") in {"easy","medium","hard"} else "medium"
        try: hours = max(1, min(400, round(float(n.get("hours", 10)))))
        except Exception: hours = 10
        skills = n.get("skills") if isinstance(n.get("skills"), list) else []
        nodes.append({
            "id": nid,
            "phaseId": n.get("phaseId") if n.get("phaseId") in phase_ids else phase_ids[0],
            "title": _clean(n.get("title"), 80) or f"Milestone {i+1}",
            "type": typ,
            "description": _clean(n.get("description"), 400),
            "skills": [_clean(x, 60) for x in skills[:8]],
            "prerequisites": prereq,
            "hours": hours,
            "difficulty": diff,
            "optional": bool(n.get("optional", False)),
        })
    if not nodes:
        raise ValueError("No valid roadmap nodes")
    target_indexes = [i for i, n in enumerate(nodes) if n["type"] == "target"]
    target_i = target_indexes[0] if target_indexes else len(nodes) - 1
    target_i = min(target_i, len(nodes) - 1)
    for i, n in enumerate(nodes):
        if i != target_i and n["type"] == "target":
            n["type"] = "skill"
    nodes[target_i]["type"] = "target"
    if target_i != len(nodes) - 1:
        target = nodes.pop(target_i)
        nodes.append(target)
        target_i = len(nodes) - 1
    referenced = {p for n in nodes for p in n["prerequisites"]}
    if not nodes[target_i]["prerequisites"]:
        nodes[target_i]["prerequisites"] = [n["id"] for n in nodes[:target_i] if not n["optional"] and n["id"] not in referenced][-4:]
    return {
        "title": _clean(r.get("title"), 100),
        "targetRole": _clean(r.get("targetRole"), 100),
        "companyType": _clean(r.get("companyType"), 60),
        "summary": _clean(r.get("summary"), 600),
        "phases": phase_out,
        "nodes": nodes,
    }


def _roadmap_input(body):
    if not isinstance(body, dict):
        raise ValueError("Invalid request")
    job = _clean(body.get("dreamJob"), 200)
    if len(job) < 3:
        raise ValueError("Describe your dream job in a few words")
    level = body.get("level") if body.get("level") in {"Beginner","Intermediate","Advanced"} else "Beginner"
    try: hours = max(1, min(80, int(body.get("hoursPerWeek", 10))))
    except Exception: hours = 10
    try: months = max(1, min(36, int(body.get("months", 6))))
    except Exception: months = 6
    return {"dreamJob": job, "level": level, "skills": _clean(body.get("skills"), 300), "hoursPerWeek": hours, "months": months, "companyType": _clean(body.get("companyType"), 60)}



def fallback_roadmap(i, reason='Groq temporarily unavailable'):
    """Deterministic, useful PathForge graph so AI failure never blocks the product."""
    job=i['dreamJob']
    skills=[x.strip() for x in i.get('skills','').split(',') if x.strip()]
    phases=[
        {'id':'p1','title':'Foundation','description':'Build the core technical base required for the target role.'},
        {'id':'p2','title':'Core Skills','description':'Develop the role-specific engineering and AI skills.'},
        {'id':'p3','title':'Applied Projects','description':'Turn skills into measurable portfolio evidence.'},
        {'id':'p4','title':'Production Readiness','description':'Practice testing, deployment, systems thinking and collaboration.'},
        {'id':'p5','title':'Interview & Target','description':'Convert your evidence into interview-ready proof.'},
    ]
    base=[
        ('n1','Python & problem solving','skill','p1',12),('n2','Git, Linux & developer workflow','skill','p1',8),
        ('n3','Data structures & algorithms','skill','p1',20),('n4','SQL & data modeling','skill','p1',12),
        ('n5','Statistics & probability','skill','p2',16),('n6','Machine learning fundamentals','skill','p2',24),
        ('n7','Model evaluation & error analysis','skill','p2',14),('n8','Deep learning foundations','skill','p2',24),
        ('n9','Target-role mini project','project','p3',24),('n10','End-to-end portfolio project','project','p3',36),
        ('n11','APIs, testing & deployment','skill','p4',18),('n12','Production ML / system design','skill','p4',22),
        ('n13','Portfolio review & technical storytelling','interview','p5',10),('n14','Target-role interview loop','interview','p5',14),
        ('n15',job,'target','p5',8),
    ]
    deps={
        'n2':['n1'],'n3':['n1'],'n4':['n1'],'n5':['n3'],'n6':['n5','n4'],'n7':['n6'],
        'n8':['n6'],'n9':['n7'],'n10':['n8','n9'],'n11':['n10'],'n12':['n7','n11'],
        'n13':['n10','n12'],'n14':['n3','n13'],'n15':['n12','n14']
    }
    nodes=[]
    for nid,title,typ,pid,hours in base:
        nodes.append({'id':nid,'phaseId':pid,'title':title,'type':typ,'description':f'Practical milestone for {job}.',
                      'skills':skills[:4] if nid=='n1' else [],'prerequisites':deps.get(nid,[]),'hours':hours,'difficulty':'hard' if hours>=24 else 'medium','optional':False})
    return {'title':f'PathForge roadmap · {job}','targetRole':job,'companyType':i.get('companyType',''),'summary':f'A resilient career route toward {job}, calibrated to {i["hoursPerWeek"]} hours/week for {i["months"]} months. Groq can enrich this route after the graph is available.','phases':phases,'nodes':nodes,'aiStatus':'fallback','aiNotice':reason}

def install_pathforge(app):
    """Install the unified PathForge/PathSurfers endpoints."""
    from flask import current_app
    # Persistent bridge table is created during application startup so the
    # Recommendations/Mr.White layers can safely query it before the first sync.
    conn = app.view_functions["home"].__globals__["get_db_connection"]()
    try:
        conn.execute("""CREATE TABLE IF NOT EXISTS pathforge_roadmaps(
            id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, roadmap_id TEXT NOT NULL,
            title TEXT NOT NULL, target_role TEXT NOT NULL, payload TEXT NOT NULL, progress TEXT NOT NULL,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, UNIQUE(username,roadmap_id))""")
        conn.commit()
    finally:
        conn.close()

    @app.get("/sw.js")
    def pathsurfers_service_worker():
        # Served from the site root so the worker's scope covers the whole app (PWA install).
        from flask import send_from_directory
        resp = send_from_directory(current_app.root_path, "sw.js", mimetype="application/javascript")
        resp.headers["Cache-Control"] = "no-cache"
        resp.headers["Service-Worker-Allowed"] = "/"
        return resp

    @app.get("/api/ai/status")
    def pathsurfers_ai_status():
        if not _current_user_required(): return jsonify(error="Unauthorized"), 401
        from services.groq_service import status
        return jsonify(status())

    @app.get("/pathforge")
    def pathforge_root():
        if not _current_user_required():
            return redirect(url_for("login", next="/pathforge/"))
        return redirect("/pathforge/")

    @app.route("/pathforge/", methods=["GET"])
    def pathforge_index():
        if not _current_user_required():
            return redirect(url_for("login", next="/pathforge/"))
        from flask import render_template
        return render_template("pathforge.html")

    @app.route("/pathforge/<path:asset>", methods=["GET"])
    def pathforge_static(asset):
        if not _current_user_required():
            return redirect(url_for("login", next=request.path))
        from flask import send_from_directory
        root = os.path.join(current_app.root_path, "static", "pathforge")
        wanted = os.path.normpath(os.path.join(root, asset))
        if not wanted.startswith(os.path.abspath(root) + os.sep) and wanted != os.path.abspath(root):
            return ("Not found", 404)
        if os.path.isdir(wanted):
            wanted = os.path.join(wanted, "index.html")
        if not os.path.exists(wanted):
            return ("Not found", 404)
        rel = os.path.relpath(wanted, root)
        return send_from_directory(root, rel)

    @app.post("/api/pathforge/generate")
    def pathforge_generate():
        if not _current_user_required(): return jsonify(error="Unauthorized"), 401
        # CRITICAL UX RULE: never block the main PathForge screen on an AI/network call.
        # Return a validated deterministic graph immediately; the browser then asks
        # /enrich for Groq and swaps the graph in only if the AI response validates.
        try:
            i = _roadmap_input(request.get_json(silent=True) or {})
        except Exception as exc:
            return jsonify(error=str(exc)), 400
        data = fallback_roadmap(i, "Groq enrichment is loading in the background.")
        roadmap = {**data, "id": secrets.token_hex(16), "createdAt": datetime.utcnow().isoformat() + "Z", "input": i, "aiStatus":"pending"}
        return jsonify(roadmap=roadmap, aiPending=True)

    @app.post("/api/pathforge/enrich")
    def pathforge_enrich():
        if not _current_user_required(): return jsonify(error="Unauthorized"), 401
        try:
            i = _roadmap_input(request.get_json(silent=True) or {})
            weeks = round(i["months"] * 4.3)
            prompt = (f"Target job: {i['dreamJob']}\nCurrent level: {i['level']}\nSkills already known: {i['skills'] or 'none stated'}\n"
                      f"Hours per week: {i['hoursPerWeek']}\nTimeframe: {i['months']} months (~{weeks} weeks; about {i['hoursPerWeek'] * weeks} total hours)\n"
                      f"Preferred company type: {i['companyType'] or 'not specified'}")
            raw = _groq([{"role":"system","content":ROADMAP_SYSTEM},{"role":"user","content":prompt}], json_mode=True, temperature=.25, max_tokens=6000, timeout=40)
            data = sanitize_roadmap(_json_response(raw))
            return jsonify(roadmap={**data, "id": secrets.token_hex(16), "createdAt": datetime.utcnow().isoformat() + "Z", "input": i, "aiStatus":"groq"})
        except Exception as exc:
            return jsonify(error=str(exc)[:180] or "Groq enrichment unavailable"), 503

    @app.post("/api/pathforge/node-details")
    def pathforge_details():
        if not _current_user_required(): return jsonify(error="Unauthorized"), 401
        try:
            b = request.get_json(silent=True) or {}
            node = b.get("node") or {}
            title = _clean(node.get("title"), 100)
            if not title: raise ValueError("Invalid milestone")
            prompt = (f"Target role: {_clean(b.get('targetRole'),120)} ({_clean(b.get('companyType'),80) or 'any company'}). Student level: {_clean(b.get('level'),20) or 'Beginner'}.\n"
                      f"Milestone: {title} ({_clean(node.get('type'),20)}). {_clean(node.get('description'),500)}\nSkills: {', '.join(map(str,(node.get('skills') or [])[:10]))}")
            raw = _groq([{"role":"system","content":DETAILS_SYSTEM},{"role":"user","content":prompt}], json_mode=True, temperature=.35, max_tokens=2200)
            d = _json_response(raw)
            d.setdefault("concepts", []); d.setdefault("interviewQuestions", []); d.setdefault("commonMistakes", []); d.setdefault("resources", [])
            return jsonify(details=d)
        except Exception as exc:
            return jsonify(error=str(exc) or "Could not load milestone details."), 502

    @app.post("/api/pathforge/replan")
    def pathforge_replan():
        if not _current_user_required(): return jsonify(error="Unauthorized"), 401
        try:
            b=request.get_json(silent=True) or {}
            remaining=(b.get("remaining") or [])[:40]
            prompt=(f"Target role: {_clean(b.get('targetRole'),120)}. Hours/week: {b.get('hoursPerWeek',10)}.\n"
                    f"Already knows: {_clean(b.get('justKnown'),120)}\nREMAINING: {json.dumps(remaining)[:10000]}")
            raw=_groq([{"role":"system","content":REPLAN_SYSTEM},{"role":"user","content":prompt}],json_mode=True,temperature=.25,max_tokens=1300)
            plan=_json_response(raw)
            valid={str(x.get('id')) for x in remaining if isinstance(x,dict)}
            plan["skipNodeIds"]=[str(x) for x in plan.get("skipNodeIds",[]) if str(x) in valid][:20]
            plan["thisWeek"]=[_clean(x,120) for x in (plan.get("thisWeek") or [])[:4]]
            plan["explanation"]=_clean(plan.get("explanation"),500)
            return jsonify(plan=plan)
        except Exception as exc:
            return jsonify(error=str(exc) or "Could not replan the roadmap."), 502

    @app.post("/api/pathforge/sync")
    def pathforge_sync():
        if not _current_user_required(): return jsonify(error="Unauthorized"), 401
        data=request.get_json(silent=True) or {}
        roadmap=data.get("roadmap")
        if not isinstance(roadmap,dict) or not roadmap.get("nodes"):
            return jsonify(error="Invalid roadmap"),400
        done=[str(x) for x in (data.get("done") or [])][:100]
        known=[str(x) for x in (data.get("known") or [])][:100]
        skipped=[str(x) for x in (data.get("skipped") or [])][:100]
        progress={"done":done,"known":known,"skipped":skipped,"synced_at":datetime.utcnow().isoformat()+"Z"}
        conn=app.view_functions["home"].__globals__["get_db_connection"]()
        try:
            conn.execute("""CREATE TABLE IF NOT EXISTS pathforge_roadmaps(
                id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, roadmap_id TEXT NOT NULL,
                title TEXT NOT NULL, target_role TEXT NOT NULL, payload TEXT NOT NULL, progress TEXT NOT NULL,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, UNIQUE(username,roadmap_id))""")
            conn.execute("""INSERT INTO pathforge_roadmaps(username,roadmap_id,title,target_role,payload,progress,updated_at)
                VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)
                ON CONFLICT(username,roadmap_id) DO UPDATE SET title=excluded.title,target_role=excluded.target_role,
                payload=excluded.payload,progress=excluded.progress,updated_at=CURRENT_TIMESTAMP""",
                (session["user"],str(roadmap.get("id") or secrets.token_hex(8)),_clean(roadmap.get("title"),100),_clean(roadmap.get("targetRole"),100),json.dumps(roadmap),json.dumps(progress)))
            # Learning Path is the persistent bridge used by recommendations/analytics.
            path_id=conn.execute("SELECT id FROM learning_paths WHERE username=? AND title=? ORDER BY id DESC LIMIT 1",(session["user"],f"PathForge: {roadmap.get('targetRole','Career path')}" )).fetchone()
            if path_id: pid=path_id[0]
            else: pid=conn.execute("INSERT INTO learning_paths(username,title,status) VALUES(?,?,?)",(session["user"],f"PathForge: {roadmap.get('targetRole','Career path')}","Active")).lastrowid
            conn.execute("DELETE FROM learning_path_items WHERE path_id=?",(pid,))
            for idx,n in enumerate(roadmap.get("nodes",[])[:60],1):
                nid=str(n.get("id")); state="Completed" if nid in done else "Known" if nid in known else "Skipped" if nid in skipped else "Recommended"
                conn.execute("INSERT INTO learning_path_items(path_id,item_type,item_id,title,sequence_no,status) VALUES(?,?,?,?,?,?)",(pid,"pathforge_node",None,_clean(n.get("title"),200),idx,state))
            # Compact context makes the path available to Mr.White without exposing the full payload to prompts.
            ctx={"target_role":_clean(roadmap.get("targetRole"),120),"progress_pct":round((len(set(done)|set(known))*100/max(1,len(roadmap.get("nodes",[])))),1),"next":next((_clean(n.get("title"),120) for n in roadmap.get("nodes",[]) if str(n.get("id")) not in set(done)|set(known)|set(skipped)),"Complete your current roadmap milestones" )}
            conn.execute("INSERT INTO chat_context(username,context_key,context_value,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(username,context_key) DO UPDATE SET context_value=excluded.context_value,updated_at=CURRENT_TIMESTAMP",(session["user"],"pathforge",json.dumps(ctx)))
            conn.commit()
            return jsonify(status="success", progress=ctx["progress_pct"])
        except Exception as exc:
            conn.rollback()
            return jsonify(error=f"Roadmap sync failed: {exc}"),500
        finally:
            conn.close()
