
def average_trainer_rating(conn, username):
    r=conn.execute("SELECT AVG(rating) v FROM trainer_feedback WHERE trainer_username=?",(username,)).fetchone()
    return round(float(r["v"] or 0),2)
def average_course_rating(conn, course_id):
    r=conn.execute("SELECT AVG(rating) v FROM course_feedback WHERE course_id=?",(course_id,)).fetchone()
    return round(float(r["v"] or 0),2)
