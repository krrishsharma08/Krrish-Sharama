
-- PathSurfers FINAL additive security/account/relationship migration
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username_unique ON users(username);

CREATE TABLE IF NOT EXISTS account_recovery_codes (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL,
 channel TEXT NOT NULL CHECK(channel IN ('email','phone')),
 destination TEXT NOT NULL,
 code_hash TEXT NOT NULL,
 expires_at DATETIME NOT NULL,
 attempts INTEGER DEFAULT 0,
 used INTEGER DEFAULT 0,
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_recovery_username ON account_recovery_codes(username);
CREATE INDEX IF NOT EXISTS idx_recovery_active ON account_recovery_codes(username, used, expires_at);
