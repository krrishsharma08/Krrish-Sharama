-- PathSurfers FAM additive migration.
-- Purely additive: new tables only, nothing existing is altered here.
-- Re-run-safe (CREATE TABLE/INDEX IF NOT EXISTS), matching the existing
-- migrations/*.sql auto-loader convention in app.py.

CREATE TABLE IF NOT EXISTS mrwhite_conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    title TEXT NOT NULL DEFAULT 'New chat',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_mrwhite_conv_user ON mrwhite_conversations(username);

CREATE TABLE IF NOT EXISTS mrwhite_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id INTEGER NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (conversation_id) REFERENCES mrwhite_conversations(id)
);
CREATE INDEX IF NOT EXISTS idx_mrwhite_msg_conv ON mrwhite_messages(conversation_id);

CREATE TABLE IF NOT EXISTS login_rate_limits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    rate_key TEXT NOT NULL,
    window_started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    attempts INTEGER NOT NULL DEFAULT 1,
    locked_until DATETIME
);
CREATE INDEX IF NOT EXISTS idx_login_rate_limits_key ON login_rate_limits(rate_key);

-- Note: AI-generated course-assessment questions are inserted directly into the
-- existing questions/question_options tables (see enhancements.py create_course)
-- so they flow through the existing, already-audited grading pipeline unchanged.

CREATE TABLE IF NOT EXISTS course_files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    course_id INTEGER NOT NULL,
    file_type TEXT NOT NULL,
    original_name TEXT NOT NULL,
    stored_path TEXT NOT NULL,
    uploaded_by TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(id)
);
CREATE INDEX IF NOT EXISTS idx_course_files_course ON course_files(course_id);
