# PathSurfers — Final Release Checklist

## Run immediately (no pip/npm install required for the supplied private local build)

### Linux / macOS / WSL / Git Bash

```bash
cd PathSurfers
chmod +x run_pathsurfers.sh
./run_pathsurfers.sh
```

Open: `http://127.0.0.1:5000`

### Windows CMD / PowerShell

```bat
cd PathSurfers
run_pathsurfers.bat
```

## Verification

```bash
cd PathSurfers
PYTHONPATH="$PWD/vendor/python:$PWD" python3 -m pytest -q tests
```

The final validation performed for this release: **26 tests passed**, Jinja template compilation passed, JavaScript syntax checks passed, SQLite integrity passed, and SQLite foreign-key checks returned zero violations.

## Groq

The private build reads `GROQ_API_KEY` from `.env` on the server. Never expose the key in frontend JavaScript, screenshots, README files or a public repository. Rotate the supplied key before public deployment/submission if it has been exposed anywhere.

## Android APK

1. Install Android Studio with Java and Android SDK Platform 35.
2. Open `android_wrapper`.
3. Sync Gradle.
4. Build **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK appears at `android_wrapper/app/build/outputs/apk/debug/app-debug.apk`.

Or, with Gradle 8.9+ installed:

```bash
cd PathSurfers/android_wrapper
gradle clean assembleDebug
```

Install directly with USB debugging:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

For the Android emulator, the wrapper defaults to `http://10.0.2.2:5000/`. For a physical phone on the same Wi-Fi network, change `START_URL` in `MainActivity.java` to the PC's LAN address. For the final submission, point it to an HTTPS deployment.

## Product flow

Dream job → PathForge → AI dependency graph → synchronized Learning Path → real course/module progress → competency evidence → Groq recommendations → Analytics Hub → Mr.White.

The existing platform features remain available: courses, assessments, competencies, recommendations, repository, trainers, feedback, certificates, notifications, learning paths, webinars, emergency drills, control center, PWA and Mr.White. Mr.K is removed.
