# Additive migrations
`001_enhancements.sql` only creates new tables with `CREATE TABLE IF NOT EXISTS`.
It never drops or rewrites the original tables or rows.
