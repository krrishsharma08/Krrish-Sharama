import os, sqlite3, tempfile, unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

class CristianoEnhancementTests(unittest.TestCase):
    def test_migration_is_additive_and_idempotent(self):
        source = os.path.join(ROOT, "database.db")
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            target = f.name
        try:
            with open(source, "rb") as a, open(target, "wb") as b:
                b.write(a.read())
            con = sqlite3.connect(target)
            before = {t: con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
                      for t in ["users","courses","enrollments","repository"]}
            sql = open(os.path.join(ROOT,"migrations","003_cristiano_enhancements.sql"), encoding="utf-8").read()
            con.executescript(sql); con.commit()
            con.executescript(sql); con.commit()
            after = {t: con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
                     for t in before}
            self.assertEqual(before, after)
            self.assertIsNotNone(con.execute("SELECT 1 FROM sqlite_master WHERE name='user_regions'").fetchone())
            self.assertIsNotNone(con.execute("SELECT 1 FROM sqlite_master WHERE name='trainer_resources'").fetchone())
            con.close()
        finally:
            if os.path.exists(target):
                os.remove(target)

    def test_original_enrollment_data_has_no_duplicates(self):
        con = sqlite3.connect(os.path.join(ROOT, "database.db"))
        dup = con.execute("""SELECT COUNT(*) FROM (
            SELECT username,course_id FROM enrollments
            GROUP BY username,course_id HAVING COUNT(*) > 1
        )""").fetchone()[0]
        self.assertEqual(dup, 0)
        con.close()

if __name__ == "__main__":
    unittest.main()
