-- PathSurfers OK: additive messaging schema. Existing tables/rows untouched.
CREATE TABLE IF NOT EXISTS chat_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sender_username TEXT NOT NULL,
    receiver_username TEXT NOT NULL,
    message TEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_read INTEGER NOT NULL DEFAULT 0 CHECK(is_read IN (0,1)),
    read_at DATETIME,
    FOREIGN KEY(sender_username) REFERENCES users(username) ON UPDATE CASCADE,
    FOREIGN KEY(receiver_username) REFERENCES users(username) ON UPDATE CASCADE,
    CHECK(sender_username <> receiver_username)
);
CREATE INDEX IF NOT EXISTS idx_chat_messages_receiver_unread ON chat_messages(receiver_username,is_read,created_at);
CREATE INDEX IF NOT EXISTS idx_chat_messages_conversation ON chat_messages(sender_username,receiver_username,created_at);
CREATE INDEX IF NOT EXISTS idx_chat_messages_reverse_conversation ON chat_messages(receiver_username,sender_username,created_at);
