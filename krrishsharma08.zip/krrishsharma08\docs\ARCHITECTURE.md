# PathSurfers Architecture

## Runtime

```text
Browser / PWA / Android wrapper
          |
          v
      Flask 3.x
   /       |        \
  UI     API       Auth/CSRF
   |       |          |
Jinja   PathForge    SQLite
        Groq AI        |
           \-----------/

PathForge roadmap -> learning_paths -> recommendations / analytics / Mr.White
Course modules -> progress -> competency -> recommendations / analytics / certificates
```

## Why Flask is the integration layer

PathSurfers already owns authentication, persistence, role controls, course state and platform workflows. Keeping that server as the single runtime avoids duplicated sessions and databases. PathForge is integrated as a responsive client surface and its AI API is implemented server-side in `pathforge_api.py`.

## Data synchronization

`/api/pathforge/sync` persists the current roadmap and progress in `pathforge_roadmaps`, mirrors milestones into `learning_path_items`, and stores a compact PathForge context in `chat_context`.

## AI trust boundary

The browser sends user input -> Flask validates bounds -> Groq receives the request -> Flask parses JSON -> Flask sanitizes the structure -> only sanitized data is returned/persisted.

No API key is embedded in JavaScript, HTML, CSS, the APK wrapper, or roadmap JSON.
