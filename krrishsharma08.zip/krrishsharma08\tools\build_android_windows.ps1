param([string]$SdkRoot = $env:ANDROID_HOME)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$wrapper = Join-Path $root 'android_wrapper'
if (-not $SdkRoot) { Write-Host 'Set ANDROID_HOME to your Android SDK path first.'; exit 1 }
if (-not (Get-Command java -ErrorAction SilentlyContinue)) { throw 'Java 17+ is required.' }
if (-not (Test-Path (Join-Path $wrapper 'gradlew.bat'))) { throw 'Gradle wrapper is missing. Open android_wrapper in Android Studio and sync once, or install Gradle 8.9+.' }
Push-Location $wrapper
try { .\gradlew.bat clean assembleDebug }
finally { Pop-Location }
Write-Host "APK: $wrapper\app\build\outputs\apk\debug\app-debug.apk"
