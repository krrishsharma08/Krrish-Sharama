"""PathSurfers: the single hardened Groq chat-completions client.

Every AI feature (PathForge, Mr.White, recommendations, AI quiz, analytics
insight) goes through request_completion() so they share one set of fixes:

  * An explicit User-Agent. Groq sits behind Cloudflare, which rejects the
    default "Python-urllib/x.y" agent with HTTP 403 / error 1010. This was the
    real reason Mr.White fell back to offline mode even with a valid key.
  * A model fallback chain. Retired models return 404 model_not_found, so we
    try GROQ_MODEL first and then currently-served models.
  * Timeouts, one retry on 429/5xx, and a recorded last error for /api/ai/status.
  * Zero third-party dependencies (stdlib urllib).

The key is read from the environment only (loaded from the project .env) and
is never logged, returned, or sent to the browser.
"""
import json
import os
import re
import time
import urllib.error
import urllib.request
from pathlib import Path

GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions"
GROQ_MODEL = "openai/gpt-oss-120b"
FALLBACK_MODELS = ("openai/gpt-oss-120b", "openai/gpt-oss-20b", "qwen/qwen3.8-27b")
USER_AGENT = "PathSurfers/1.0 (+https://localhost; python-urllib)"
_TIMEOUT_SECONDS = 20

_state = {"last_error": None, "last_ok_model": None, "last_ok_at": None}
_dead_models = set()


class GroqError(RuntimeError):
    pass


def _load_env_runtime():
    """Load this app's .env even when launched from another directory. Existing env vars win."""
    try:
        env_path = Path(__file__).resolve().parents[1] / ".env"
        if not env_path.exists():
            return
        for raw in env_path.read_text(encoding="utf-8-sig", errors="ignore").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and value and not os.environ.get(key, "").strip():
                os.environ[key] = value
    except OSError:
        pass


def _key():
    _load_env_runtime()
    return os.environ.get("GROQ_API_KEY", "").strip()


def ai_enabled():
    """True when a Groq key is configured, regardless of launch directory."""
    return bool(_key())


def _models():
    wanted = os.environ.get("GROQ_MODEL", "").strip()
    chain = ([wanted] if wanted else []) + [m for m in FALLBACK_MODELS if m != wanted]
    live = [m for m in chain if m not in _dead_models]
    return live or chain


def status():
    """Diagnostics safe to show in the UI: never includes the key."""
    return {
        "configured": ai_enabled(),
        "model": _state["last_ok_model"] or (_models()[0] if _models() else None),
        "last_ok_at": _state["last_ok_at"],
        "last_error": _state["last_error"],
    }


def _strip_reasoning(text):
    # Some reasoning models prepend <think>...</think>; never show that to users.
    return re.sub(r"<think>.*?</think>", "", text or "", flags=re.S).strip()


def request_completion(messages, *, json_mode=False, temperature=0.4, max_tokens=1200, timeout=None):
    """Return the assistant text. Raises GroqError with a short, key-free reason."""
    key = _key()
    if not key:
        raise GroqError("GROQ_API_KEY is not configured in .env")
    timeout = timeout or _TIMEOUT_SECONDS
    deadline = time.monotonic() + timeout
    last = "Groq request failed"
    for model in _models():
        payload = {"model": model, "messages": messages, "temperature": temperature,
                   "max_completion_tokens": max_tokens}
        if model.startswith("openai/gpt-oss"):
            payload["reasoning_effort"] = "low"
            payload["include_reasoning"] = False
        elif model.startswith("qwen/"):
            payload["reasoning_format"] = "hidden"
        if json_mode:
            payload["response_format"] = {"type": "json_object"}
        for attempt in range(2):
            remaining = deadline - time.monotonic()
            if remaining <= 1:
                _state["last_error"] = "Groq timed out"
                raise GroqError("Groq timed out")
            req = urllib.request.Request(
                GROQ_API_URL, data=json.dumps(payload).encode("utf-8"), method="POST",
                headers={"Content-Type": "application/json", "Accept": "application/json",
                         "User-Agent": USER_AGENT, "Authorization": f"Bearer {key}"})
            try:
                with urllib.request.urlopen(req, timeout=remaining) as resp:
                    data = json.loads(resp.read().decode("utf-8", errors="ignore"))
                text = _strip_reasoning(data["choices"][0]["message"].get("content") or "")
                if not text:
                    raise GroqError("Groq returned an empty response")
                _state.update(last_error=None, last_ok_model=model, last_ok_at=time.strftime("%Y-%m-%d %H:%M:%S"))
                return text
            except urllib.error.HTTPError as exc:
                detail = ""
                try:
                    detail = json.loads(exc.read().decode("utf-8", "ignore")).get("error", {}).get("message", "")
                except Exception:
                    pass
                if exc.code in (401,):
                    last = "Groq rejected the API key (401). Create a new key at console.groq.com"
                    _state["last_error"] = last
                    raise GroqError(last) from exc
                if exc.code == 403:
                    last = "Groq blocked the request (403). Check the key/network"
                    _state["last_error"] = last
                    raise GroqError(last) from exc
                if exc.code in (400, 404) and ("model" in detail.lower() or exc.code == 404):
                    _dead_models.add(model)
                    last = f"Model {model} unavailable"
                    break  # next model
                if exc.code == 400 and json_mode and "json" in detail.lower():
                    last = "Groq could not produce valid JSON"
                    break
                if exc.code == 429 or exc.code >= 500:
                    last = "Groq is rate-limited" if exc.code == 429 else f"Groq server error ({exc.code})"
                    if attempt == 0:
                        time.sleep(1.2)
                        continue
                    break
                last = f"Groq request failed ({exc.code}) {detail[:120]}".strip()
                break
            except GroqError as exc:
                last = str(exc)
                break
            except (urllib.error.URLError, TimeoutError, OSError) as exc:
                last = "Could not reach Groq (network/timeout)"
                if attempt == 0 and deadline - time.monotonic() > 3:
                    continue
                break
            except (KeyError, IndexError, ValueError, TypeError):
                last = "Groq returned a malformed response"
                break
    _state["last_error"] = last
    raise GroqError(last)


def parse_json(text):
    """Defensive JSON extraction: strips fences, falls back to the outermost {...}."""
    raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", (text or "").strip(), flags=re.I)
    try:
        return json.loads(raw)
    except (ValueError, TypeError):
        a, b = raw.find("{"), raw.rfind("}")
        if a >= 0 and b > a:
            return json.loads(raw[a:b + 1])
        raise ValueError("AI did not return JSON")


def chat_completion(messages, temperature=0.7, max_tokens=600, json_mode=False):
    """Legacy helper: returns text or None on any failure (callers fall back)."""
    try:
        return request_completion(messages, json_mode=json_mode, temperature=temperature, max_tokens=max_tokens)
    except GroqError:
        return None


def chat_json(messages, temperature=0.4, max_tokens=1200):
    """Legacy helper: returns a dict/list or None if the model didn't return valid JSON."""
    text = chat_completion(messages, temperature=temperature, max_tokens=max_tokens, json_mode=True)
    if not text:
        return None
    try:
        return parse_json(text)
    except ValueError:
        return None
