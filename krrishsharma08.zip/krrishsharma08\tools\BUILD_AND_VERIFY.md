# PathSurfers — build & verification

## Fast local run (Linux/macOS/WSL/Git Bash)

```bash
cd PathSurfers
chmod +x run_pathsurfers.sh
./run_pathsurfers.sh
```

Open `http://127.0.0.1:5000`.

## Windows PowerShell

```powershell
cd PathSurfers
.\run_pathsurfers.bat
```

## Tests

The supplied build includes vendored Flask runtime sources so the test suite can run without downloading packages:

```bash
PYTHONPATH="$PWD/vendor/python:$PWD" python3 -m pytest -q tests
```

Expected current result: **26 passed**.

## Groq

The private local `.env` contains the configured key. Do not commit or upload that file publicly. The browser never receives the key.

For a public machine, copy `.env.example` to `.env` and set your own `GROQ_API_KEY` and `SECRET_KEY`.

## Android APK

The included `android_wrapper` is a WebView shell. A real APK build requires Android SDK + Java + Gradle/Android Studio on the machine doing the build.

1. Start PathSurfers on the PC.
2. For an Android emulator, use `http://10.0.2.2:5000/`.
3. For a physical phone, change the wrapper's `START_URL` to the PC's LAN URL, e.g. `http://192.168.1.20:5000/`, and allow the port through the firewall.
4. Open `android_wrapper` in Android Studio, sync Gradle, then **Build → Build APK(s)**.
5. Install `app-debug.apk` on the phone.

For the final hackathon build, deploy PathSurfers over HTTPS and point the wrapper to the HTTPS URL before generating a release APK.
