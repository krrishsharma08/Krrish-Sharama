#!/usr/bin/env bash
# PATHSURFERS launcher for Linux / macOS. Dependencies are vendored; no pip needed.
set -e
cd "$(dirname "$0")"
export PYTHONPATH="$PWD/vendor/python:${PYTHONPATH:-}"
export PORT="${PORT:-5000}"
export FLASK_HOST="${FLASK_HOST:-0.0.0.0}"
[ -f .env ] || echo "[!] .env not found - copy .env.example to .env and add GROQ_API_KEY"
echo "PATHSURFERS on http://127.0.0.1:$PORT"
exec python3 app.py
