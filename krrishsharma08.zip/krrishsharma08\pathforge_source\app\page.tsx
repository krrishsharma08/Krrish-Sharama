"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowRight, Compass, Gauge, Map, Sparkles, Wand2 } from "lucide-react";
import Carousel from "@/components/Carousel";
import { loadState, newState, saveState } from "@/lib/store";
import { SAMPLE } from "@/lib/sample";

const EXAMPLES = ["AI Ethics Engineer at a robotics company", "Machine Learning Engineer at a fintech startup", "Frontend Engineer at a climate-tech startup", "Cybersecurity Engineer at a bank"];
const COMPANIES = ["Startup", "Big Tech", "FinTech", "Healthcare", "Robotics", "Research"];
const STEPS = ["Analyzing destination…", "Mapping prerequisite skills…", "Finding realistic stepping stones…", "Building your career graph…"];

export default function Home() {
  const router = useRouter();
  const [job, setJob] = useState("");
  const [level, setLevel] = useState("Beginner");
  const [skills, setSkills] = useState("");
  const [hours, setHours] = useState(10);
  const [months, setMonths] = useState(6);
  const [company, setCompany] = useState("");
  const [busy, setBusy] = useState(false);
  const [step, setStep] = useState(0);
  const [err, setErr] = useState("");
  const [hasSaved, setHasSaved] = useState(false);

  useEffect(() => { setHasSaved(!!loadState()); }, []);
  useEffect(() => {
    if (!busy) return;
    const t = setInterval(() => setStep((s) => Math.min(s + 1, STEPS.length - 1)), 2600);
    return () => clearInterval(t);
  }, [busy]);

  async function forge(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    if (job.trim().length < 3) { setErr("Tell us the job you want, e.g. “ML Engineer at a fintech startup”."); return; }
    setErr(""); setBusy(true); setStep(0);
    try {
      const res = await fetch("/api/pathforge/generate", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ dreamJob: job, level, skills, hoursPerWeek: hours, months, companyType: company }),
      });
      const j = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(j.error || "Could not generate your roadmap.");
      saveState(newState(j.roadmap));
      router.push("/roadmap");
    } catch (e2) {
      setErr(e2 instanceof Error ? e2.message : "Network problem. Please try again.");
      setBusy(false);
    }
  }

  function demo() { saveState(newState(SAMPLE)); router.push("/roadmap"); }

  return (
    <main>
      <nav className="nav glass wrap">
        <div className="brand"><span className="logo"><Compass size={18} /></span> PATHFORGE</div>
        <div className="nav-r">
          {hasSaved && <button className="btn btn-ghost sm" onClick={() => router.push("/roadmap")}>Continue my roadmap</button>}
          <a className="btn btn-ghost sm" href="#forge">Forge</a>
        </div>
      </nav>

      <section className="hero wrap">
        <div className="pill"><Sparkles size={14} /> AI career reverse-engineering</div>
        <h1>Your dream job.<br /><span className="grad">Reverse-engineered.</span></h1>
        <p className="lead">Tell us exactly where you want to go. PathForge turns your destination into an AI-generated, interactive career skill tree.</p>

        <form id="forge" className="forge glass" onSubmit={forge}>
          <label className="lbl" htmlFor="job">Your target job</label>
          <input id="job" className="big-input" value={job} onChange={(e) => setJob(e.target.value)} maxLength={200} placeholder="AI Ethics Engineer at a robotics company" autoComplete="off" />
          <div className="tags">{EXAMPLES.map((x) => <button type="button" key={x} className="tag btn-tag" onClick={() => setJob(x)}>{x}</button>)}</div>

          <div className="grid2">
            <div>
              <span className="lbl">Current level</span>
              <div className="seg" role="radiogroup">{["Beginner", "Intermediate", "Advanced"].map((l) => <button type="button" key={l} role="radio" aria-checked={level === l} className={level === l ? "on" : ""} onClick={() => setLevel(l)}>{l}</button>)}</div>
            </div>
            <div>
              <label className="lbl" htmlFor="sk">Skills you already have (optional)</label>
              <input id="sk" className="input" value={skills} onChange={(e) => setSkills(e.target.value)} maxLength={300} placeholder="Python basics, Git…" />
            </div>
            <div>
              <label className="lbl" htmlFor="hr">Hours per week: <b>{hours}</b></label>
              <input id="hr" type="range" min={2} max={40} value={hours} onChange={(e) => setHours(+e.target.value)} />
            </div>
            <div>
              <label className="lbl" htmlFor="mo">Target timeline</label>
              <select id="mo" className="input" value={months} onChange={(e) => setMonths(+e.target.value)}>
                {[3, 6, 9, 12, 18, 24].map((m) => <option key={m} value={m}>{m} months</option>)}
              </select>
            </div>
          </div>
          <span className="lbl">Company type (optional)</span>
          <div className="tags">{COMPANIES.map((c) => <button type="button" key={c} className={company === c ? "tag btn-tag on" : "tag btn-tag"} onClick={() => setCompany(company === c ? "" : c)}>{c}</button>)}</div>

          {err && <div className="err" role="alert">{err}</div>}
          <div className="cta-row">
            <button className="btn btn-primary lg" disabled={busy}>Forge My Path <ArrowRight size={18} /></button>
            <button type="button" className="btn btn-ghost lg" onClick={demo} disabled={busy}>Explore Demo</button>
          </div>
          <p className="tiny">“Explore Demo” opens a pre-written sample roadmap. We only use what you type here to build your roadmap.</p>
        </form>
      </section>

      <section className="wrap"><Carousel /></section>

      <section className="wrap trio">
        {[{ i: Map, t: "Interactive skill tree", d: "Zoom, pan and click every milestone on a live dependency graph." }, { i: Wand2, t: "Reroutes as you grow", d: "Mark skills as known and the path, unlocks and timeline adapt." }, { i: Gauge, t: "Built around your time", d: "Hours per week and your deadline shape the whole plan." }].map(({ i: I, t, d }) => (
          <div key={t} className="feat glass"><I size={22} /><h3>{t}</h3><p>{d}</p></div>
        ))}
      </section>
      <footer className="wrap foot">PathForge · PathSurfers Career Intelligence · Roadmaps are AI-generated suggestions: verify resources before relying on them.</footer>

      {busy && (
        <div className="overlay" role="status" aria-live="polite">
          <div className="orb"><Compass size={30} /></div>
          <h2 key={step} className="fade-up">{STEPS[step]}</h2>
          <div className="loadbar"><span /></div>
          <p className="tiny">This usually takes 20–40 seconds.</p>
        </div>
      )}
    </main>
  );
}
