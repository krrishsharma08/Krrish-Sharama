import type { NodeDetails, StoredRoadmap } from "./schema";

export type Chat = { role: "user" | "assistant"; content: string };
export type AppState = {
  roadmap: StoredRoadmap;
  done: string[];
  doing: string[];
  known: string[];
  skipped: string[];
  details: Record<string, NodeDetails>;
  chat: Chat[];
  note: string;
  baseHours: number;
};

const KEY = "pathforge_state_v1";

export function newState(roadmap: StoredRoadmap): AppState {
  return {
    roadmap,
    done: [],
    doing: [],
    known: [],
    skipped: [],
    details: {},
    chat: [],
    note: "",
    baseHours: roadmap.nodes.filter((n) => !n.optional).reduce((a, n) => a + n.hours, 0),
  };
}

export function loadState(): AppState | null {
  try {
    if (typeof window === "undefined") return null;
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const s = JSON.parse(raw) as AppState;
    return s?.roadmap?.nodes?.length ? s : null;
  } catch {
    return null;
  }
}

export function saveState(s: AppState) {
  try {
    localStorage.setItem(KEY, JSON.stringify(s));
  } catch {
    /* storage full or blocked: ignore */
  }
}
