import os, sqlite3

BASE=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB=os.path.join(BASE,"database.db")
MIG_DIR=os.path.join(BASE,"migrations")

def main():
    con=sqlite3.connect(DB)
    con.execute("PRAGMA foreign_keys=ON")
    for filename in sorted(os.listdir(MIG_DIR)):
        if filename.endswith(".sql"):
            with open(os.path.join(MIG_DIR,filename),encoding="utf-8") as f:
                con.executescript(f.read())
    con.commit()
    con.close()
    print("All additive migrations applied successfully.")

if __name__=="__main__":
    main()
