import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "PathSurfers — Your dream job. Reverse-engineered.",
  description: "Turn your exact dream job into an AI-generated, interactive career skill tree inside PathSurfers.",
};
export const viewport: Viewport = { themeColor: "#05050A", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <div className="bg-grid" aria-hidden />
        <div className="glow g1" aria-hidden />
        <div className="glow g2" aria-hidden />
        {children}
      </body>
    </html>
  );
}
