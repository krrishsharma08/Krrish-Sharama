"""PathSurfers OK additive chat + analytics + Mr.White layer.
No external AI services. Existing tables/rows are read-only; new messaging state uses new tables.
"""
import ast, difflib, math, re, secrets, json
from datetime import datetime, timedelta
from functools import wraps
from flask import request, session, jsonify, render_template, redirect, url_for, abort
from services.groq_service import chat_completion as groq_completion

ROLES_WITH_TRAINEE_ACCESS = {'Leader','Non-Reliable User','Administrator'}

def install_ok_layer(app):
    base_get_db = app.view_functions['home'].__globals__['get_db_connection']

    def db():
        return base_get_db()

    def norm(s):
        s = (s or '').lower()
        s = re.sub(r'[^a-z0-9\s]', ' ', s)
        return re.sub(r'\s+', ' ', s).strip()

    aliases = {
        'dashbord':'dashboard','dashbordz':'dashboard','repositry':'repository','repo':'repository',
        'analitics':'analytics','analytical':'analytics','comptency':'competency','assesment':'assessment',
        'trainner':'trainer','leder':'leader','mesages':'messages','notifcation':'notification',
        'certificat':'certificate','cours':'course','progres':'progress','groth':'growth'
    }
    def canonical(text):
        words=[]
        for w in norm(text).split():
            if w in aliases: words.append(aliases[w]); continue
            close=difflib.get_close_matches(w, aliases.values(), n=1, cutoff=.80)
            words.append(close[0] if close else w)
        return ' '.join(words)

    def ensure_csrf_token():
        token = session.get('_csrf_token')
        if not token:
            token = secrets.token_urlsafe(32)
            session['_csrf_token'] = token
        return token

    def csrf_ok():
        expected=ensure_csrf_token()
        supplied=request.form.get('_csrf_token') or request.headers.get('X-CSRF-Token')
        return bool(expected and supplied and secrets.compare_digest(supplied, expected))

    def current_user():
        return session.get('user')

    def allowed_contact(conn, me, other):
        if not me or not other or me == other: return False
        a=conn.execute('SELECT username,role,ref_code,leader_ref_code FROM users WHERE username=?',(me,)).fetchone()
        b=conn.execute('SELECT username,role,ref_code,leader_ref_code FROM users WHERE username=?',(other,)).fetchone()
        if not a or not b: return False
        if a['role'] == 'Non-Reliable User': return False
        # Trainee -> their selected leader or an explicitly assigned trainer/mentor.
        if a['role']=='Trainee':
            if b['ref_code'] and a['leader_ref_code'] == b['ref_code'] and b['role']!='Trainee': return True
            return bool(conn.execute("""SELECT 1 FROM trainer_assignments
                WHERE trainee_username=? AND trainer_username=? AND status IN ('Recommended','Pending','Accepted','Active') LIMIT 1""",(me,other)).fetchone())
        # Supervisory role -> a trainee linked by leader code or trainer assignment.
        if b['role']=='Trainee':
            if a['ref_code'] and b['leader_ref_code']==a['ref_code']: return True
            return bool(conn.execute("""SELECT 1 FROM trainer_assignments
                WHERE trainee_username=? AND trainer_username=? AND status IN ('Recommended','Pending','Accepted','Active') LIMIT 1""",(other,me)).fetchone())
        return False

    def contacts_for(conn, me):
        user=conn.execute('SELECT username,role,ref_code,leader_ref_code FROM users WHERE username=?',(me,)).fetchone()
        if not user: return []
        if user['role']=='Trainee':
            rows=conn.execute("""SELECT u.username,u.fullname,u.role,u.ref_code,u.email,u.phone
                FROM users u WHERE u.role!='Trainee' AND (
                    (u.ref_code IS NOT NULL AND u.ref_code=?) OR EXISTS(
                        SELECT 1 FROM trainer_assignments ta WHERE ta.trainer_username=u.username
                        AND ta.trainee_username=? AND ta.status IN ('Recommended','Pending','Accepted','Active')
                    )) ORDER BY COALESCE(u.fullname,u.username)""",(user['leader_ref_code'],me)).fetchall()
        else:
            rows=conn.execute("""SELECT u.username,u.fullname,u.role,u.ref_code,u.email,u.phone
                FROM users u WHERE u.role='Trainee' AND (
                    (? IS NOT NULL AND u.leader_ref_code=?) OR EXISTS(
                        SELECT 1 FROM trainer_assignments ta WHERE ta.trainer_username=?
                        AND ta.trainee_username=u.username AND ta.status IN ('Recommended','Pending','Accepted','Active')
                    )) ORDER BY COALESCE(u.fullname,u.username)""",(user['ref_code'],user['ref_code'],me)).fetchall()
        return [dict(r) for r in rows if r['username'] != me]

    def growth(conn, username):
        # Growth is derived only from actual course completion and assessments.
        mods=conn.execute("SELECT COUNT(*) total, SUM(CASE WHEN completed=1 THEN 1 ELSE 0 END) done FROM user_module_progress WHERE username=?",(username,)).fetchone()
        assess=conn.execute('SELECT AVG(score) FROM course_assessments WHERE username=?',(username,)).fetchone()[0]
        vals=[]
        if mods['total']: vals.append(float(mods['done'] or 0)/float(mods['total'])*100)
        if assess is not None: vals.append(float(assess))
        path=conn.execute("SELECT progress FROM pathforge_roadmaps WHERE username=? ORDER BY updated_at DESC LIMIT 1",(username,)).fetchone()
        if path:
            try: vals.append(float(json.loads(path['progress']).get('progress_pct',0)))
            except Exception: pass
        return round(sum(vals)/len(vals),1) if vals else None

    def profile(conn, username):
        u=conn.execute('SELECT username,fullname,role,email,phone,ref_code FROM users WHERE username=?',(username,)).fetchone()
        if not u: return None
        comp_rows=[]
        for r in conn.execute("""SELECT c.category,COUNT(cm.id) total,COALESCE(SUM(CASE WHEN p.completed=1 THEN 1 ELSE 0 END),0) done
            FROM courses c JOIN enrollments e ON e.course_id=c.id LEFT JOIN course_modules cm ON cm.course_id=c.id
            LEFT JOIN user_module_progress p ON p.username=? AND p.module_id=cm.id WHERE e.username=? GROUP BY c.category""",(username,username)).fetchall():
            total=int(r['total'] or 0); done=int(r['done'] or 0); completion=(done*100/total) if total else 0
            a=conn.execute("SELECT AVG(score) score,COUNT(*) attempts FROM course_assessments ca JOIN courses c ON c.id=ca.course_id WHERE ca.username=? AND c.category=?",(username,r['category'])).fetchone()
            score=round((completion+float(a['score']))/2,1) if a['score'] is not None else round(completion,1)
            comp_rows.append({'subject':r['category'],'score':score,'attempts':int(a['attempts'] or 0)})
        comps=sorted(comp_rows,key=lambda x:x['score'])[:6]
        enrolled=conn.execute('SELECT COUNT(*) FROM enrollments WHERE username=?',(username,)).fetchone()[0]
        completed=conn.execute("""SELECT COUNT(*) FROM (SELECT e.course_id FROM enrollments e JOIN course_modules m ON m.course_id=e.course_id
          LEFT JOIN user_module_progress p ON p.username=? AND p.module_id=m.id AND p.completed=1 WHERE e.username=? GROUP BY e.course_id
          HAVING COUNT(m.id)>0 AND COUNT(p.id)=COUNT(m.id))""",(username,username)).fetchone()[0]
        avg=conn.execute('SELECT AVG(score) FROM course_assessments WHERE username=?',(username,)).fetchone()[0]
        return {'username':u['username'],'name':u['fullname'] or u['username'],'role':u['role'],'email':u['email'],'phone':u['phone'],
                'growth':growth(conn,username),'competencies':[dict(x) for x in comps[:6]],'enrolled':enrolled,'completed':completed,
                'assessment':round(float(avg),1) if avg is not None else None}

    def unread_for(conn, me, other=None):
        if other:
            return conn.execute("SELECT COUNT(*) FROM chat_messages WHERE receiver_username=? AND sender_username=? AND is_read=0",(me,other)).fetchone()[0]
        return conn.execute("SELECT COUNT(*) FROM chat_messages WHERE receiver_username=? AND is_read=0",(me,)).fetchone()[0]

    def analytics_payload(conn, me, role):
        own=profile(conn,me)
        contacts=[]
        for c in contacts_for(conn,me):
            p=profile(conn,c['username'])
            if p:
                p['unread']=unread_for(conn,me,c['username'])
                contacts.append(p)
        return own,contacts

    # Insert this guard FIRST so it can safely supersede the older GHEE analytics/chat interceptor
    # without deleting or rewriting that code.
    # Apply the dedicated additive schema at startup as well as through the migration runner.
    with app.app_context():
        c=db()
        try:
            c.executescript(open(app.config.get('OK_MIGRATION') or __import__('os').path.join(app.root_path,'migrations','005_ok_chat.sql'), encoding='utf-8').read())
            c.commit()
        finally: c.close()

    def ok_interceptor():
        if request.path == '/analytics' and request.method == 'GET':
            if not current_user(): return redirect(url_for('login'))
            conn=db()
            try:
                me=current_user(); role=session.get('role')
                own,contacts=analytics_payload(conn,me,role)
                ai_insight=None
                if own:
                    try:
                        context=json.dumps({'growth':own.get('growth'),'enrolled':own.get('enrolled'),'completed':own.get('completed'),'assessment':own.get('assessment'),'competencies':own.get('competencies')},ensure_ascii=False)
                        ai_insight=groq_completion([{'role':'system','content':'You are PathSurfers Analytics Coach. Give a concise, evidence-based learner insight using only supplied stored metrics. No invented facts. Mention one strength, one gap and one concrete next action in under 90 words.'},{'role':'user','content':context}],temperature=.25,max_tokens=180)
                    except Exception:
                        ai_insight=None
                if role in ('Administrator','Leader'):
                    org={
                      'users':conn.execute('SELECT COUNT(*) FROM users').fetchone()[0],
                      'trainees':conn.execute("SELECT COUNT(*) FROM users WHERE role='Trainee'").fetchone()[0],
                      'trainers':conn.execute("SELECT COUNT(*) FROM users WHERE role!='Trainee' AND role!='Administrator'").fetchone()[0],
                      'courses':conn.execute('SELECT COUNT(*) FROM courses').fetchone()[0],
                      'enrollments':conn.execute('SELECT COUNT(*) FROM enrollments').fetchone()[0],
                      'messages':conn.execute('SELECT COUNT(*) FROM chat_messages').fetchone()[0],
                    }
                else: org=None
                return render_template('analytics_ok.html', own=own, contacts=contacts, role=role, org=org, csrf=ensure_csrf_token(), ai_insight=ai_insight)
            finally: conn.close()
        if request.path == '/api/chat' and request.method == 'POST':
            if not current_user(): return jsonify(status='error',message='Unauthorized'),401
            if not csrf_ok(): return jsonify(status='error',message='CSRF validation failed'),403
            conn=db()
            try:
                raw=str((request.get_json(silent=True) or {}).get('message','')).strip()
                if not raw: return jsonify(status='error',message='Empty message'),400
                response=mrwhite(conn=conn, username=current_user(), raw=raw)
                # Keep only lightweight context in the existing dedicated MrWhite table.
                conn.execute("INSERT INTO mrwhite_context(username,role,last_intent,last_topic,updated_at) VALUES(?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(username) DO UPDATE SET role=excluded.role,last_intent=excluded.last_intent,last_topic=excluded.last_topic,updated_at=CURRENT_TIMESTAMP",(current_user(),session.get('role'),'OK_LOCAL',canonical(raw)[:160]))
                conn.commit()
                return jsonify(status='success',response=response)
            finally: conn.close()
        return None

    app.before_request_funcs.setdefault(None, []).insert(0, ok_interceptor)

    @app.get('/mentor-chat/<username>')
    def mentor_chat(username):
        if not current_user(): return redirect(url_for('login'))
        conn=db()
        try:
            if not allowed_contact(conn,current_user(),username): abort(403)
            person=profile(conn,username)
            messages=conn.execute("""SELECT id,sender_username,receiver_username,message,created_at,is_read,read_at
                FROM chat_messages WHERE (sender_username=? AND receiver_username=?) OR (sender_username=? AND receiver_username=?)
                ORDER BY id ASC""",(current_user(),username,username,current_user())).fetchall()
            conn.execute("""UPDATE chat_messages SET is_read=1,read_at=CURRENT_TIMESTAMP
                WHERE receiver_username=? AND sender_username=? AND is_read=0""",(current_user(),username))
            conn.commit()
            return render_template('mentor_chat.html',person=person,messages=messages,csrf=ensure_csrf_token())
        finally: conn.close()

    @app.post('/api/mentor-chat/<username>')
    def mentor_chat_send(username):
        if not current_user(): return jsonify(status='error',message='Unauthorized'),401
        if not csrf_ok(): return jsonify(status='error',message='CSRF validation failed'),403
        data=request.get_json(silent=True) or {}
        msg=str(data.get('message','')).strip()
        if not msg: return jsonify(status='error',message='Message cannot be empty'),400
        if len(msg)>2000: return jsonify(status='error',message='Message is too long'),400
        conn=db()
        try:
            if not allowed_contact(conn,current_user(),username): abort(403)
            cur=conn.execute('INSERT INTO chat_messages(sender_username,receiver_username,message) VALUES(?,?,?)',(current_user(),username,msg))
            conn.commit()
            return jsonify(status='success',message_id=cur.lastrowid,created_at=conn.execute('SELECT created_at FROM chat_messages WHERE id=?',(cur.lastrowid,)).fetchone()[0])
        finally: conn.close()

    @app.get('/api/mentor-chat/unread')
    def mentor_unread():
        if not current_user(): return jsonify(status='error',message='Unauthorized'),401
        conn=db()
        try:
            allowed={x['username'] for x in contacts_for(conn,current_user())}
            rows=conn.execute("""SELECT sender_username,COUNT(*) count FROM chat_messages
                WHERE receiver_username=? AND is_read=0 GROUP BY sender_username""",(current_user(),)).fetchall()
            return jsonify(status='success',total=sum(r['count'] for r in rows if r['sender_username'] in allowed),by_user={r['sender_username']:r['count'] for r in rows if r['sender_username'] in allowed})
        finally: conn.close()

    # --- local Mr.White intelligence ---
    # Safe local scientific calculator. It intentionally uses AST parsing instead of eval().
    MATH_NAMES = {
        'pi': math.pi, 'e': math.e, 'tau': math.tau,
        'inf': math.inf,
    }
    MATH_FUNCS = {
        'sqrt': math.sqrt, 'cbrt': lambda x: math.copysign(abs(x) ** (1/3), x),
        'abs': abs, 'round': round, 'floor': math.floor, 'ceil': math.ceil,
        'exp': math.exp, 'ln': math.log, 'log': math.log10, 'log10': math.log10,
        'log2': math.log2, 'pow': pow, 'factorial': math.factorial,
        # Trig functions use degrees because that is friendlier for a chat-style calculator.
        'sin': lambda x: math.sin(math.radians(x)),
        'cos': lambda x: math.cos(math.radians(x)),
        'tan': lambda x: math.tan(math.radians(x)),
        'asin': lambda x: math.degrees(math.asin(x)),
        'acos': lambda x: math.degrees(math.acos(x)),
        'atan': lambda x: math.degrees(math.atan(x)),
    }

    def calculate_expression(expr):
        expr = str(expr or '').strip()
        expr = expr.replace('×', '*').replace('÷', '/').replace('−', '-').replace('π', 'pi')
        expr = expr.replace('^', '**')
        if len(expr) > 180:
            raise ValueError('expression too long')
        tree = ast.parse(expr, mode='eval')

        def evaluate(node):
            if isinstance(node, ast.Expression):
                return evaluate(node.body)
            if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
                if abs(float(node.value)) > 1e100:
                    raise ValueError('number too large')
                return node.value
            if isinstance(node, ast.Name) and node.id in MATH_NAMES:
                return MATH_NAMES[node.id]
            if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
                value = evaluate(node.operand)
                return +value if isinstance(node.op, ast.UAdd) else -value
            if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod, ast.Pow)):
                left, right = evaluate(node.left), evaluate(node.right)
                if isinstance(node.op, ast.Pow) and abs(float(right)) > 1000:
                    raise ValueError('exponent too large')
                if isinstance(node.op, ast.Add): return left + right
                if isinstance(node.op, ast.Sub): return left - right
                if isinstance(node.op, ast.Mult): return left * right
                if isinstance(node.op, ast.Div): return left / right
                if isinstance(node.op, ast.FloorDiv): return left // right
                if isinstance(node.op, ast.Mod): return left % right
                return left ** right
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in MATH_FUNCS and not node.keywords:
                args = [evaluate(a) for a in node.args]
                if node.func.id == 'factorial' and (len(args) != 1 or not float(args[0]).is_integer() or args[0] < 0 or args[0] > 1000):
                    raise ValueError('factorial range')
                return MATH_FUNCS[node.func.id](*args)
            raise ValueError('unsupported expression')

        value = evaluate(tree)
        if isinstance(value, complex) or not math.isfinite(float(value)):
            raise ValueError('non-finite result')
        return value

    def format_number(value):
        if isinstance(value, float) and value.is_integer():
            return str(int(value))
        return f'{value:.12g}' if isinstance(value, float) else str(value)

    def try_calculation(raw):
        candidate = str(raw or '').strip()
        lowered = candidate.lower().strip()
        prefixes = ('calculate ', 'calc ', 'solve ', 'what is ', "what's ", 'compute ', 'evaluate ')
        for prefix in prefixes:
            if lowered.startswith(prefix):
                candidate = candidate[len(prefix):].strip()
                break
        # Human-friendly numeric input: accept leading-zero integers such as 09 or 073.
        # Normalize each standalone integer token while preserving decimals and scientific notation.
        def strip_leading_zeros(match):
            token = match.group(0)
            digits = token.lstrip('0')
            return digits or '0'
        candidate = re.sub(r'(?<![A-Za-z0-9_.])0+\d+(?![A-Za-z0-9_.])', strip_leading_zeros, candidate)
        # Do not steal normal English questions. Math-only expressions can contain
        # whitelisted scientific function/name tokens plus numbers/operators.
        if not candidate or len(candidate) > 180:
            return None
        if not re.fullmatch(r'[0-9eEpiτπxX_\.\+\-\*\/\%\(\)\,\^\s×÷−a-zA-Z]+', candidate):
            return None
        words = set(re.findall(r'[A-Za-z]+', candidate.lower()))
        allowed_words = set(MATH_NAMES) | set(MATH_FUNCS) | {'x'}
        if words - allowed_words:
            return None
        has_math_signal = bool(re.search(r'\d.*[+\-*/%^×÷−]|[+\-*/%^×÷−].*\d|\d\s*(?:pi|tau|e)\b|\b(?:sqrt|sin|cos|tan|asin|acos|atan|log|ln|exp|factorial|pi|tau|cbrt)\b', candidate, re.I))
        if not has_math_signal:
            return None
        candidate = candidate.replace('τ', 'tau')
        # Support calculator-style implicit multiplication such as 2pi and 2(3+4).
        candidate = re.sub(r'(\d|\))\s*(?=(pi|tau|e)\b)', r'\1*', candidate, flags=re.I)
        candidate = re.sub(r'(\d|\))\s*(?=\()', r'\1*', candidate)
        try:
            result = calculate_expression(candidate)
            return f"📐 **{format_number(result)}** — math secured. No cap, just computation 😎"
        except (SyntaxError, ValueError, TypeError, ZeroDivisionError, OverflowError, ArithmeticError):
            # If it looked like an explicit calculation request, return a useful error.
            if lowered.startswith(prefixes):
                return "I couldn't compute that one 😅. Check the expression and try something like `25 * 4`, `sqrt(144)`, `sin(30)`, `2^10`, or `log(100)`."
            return None

    def mrwhite(conn, username, raw):
        text=canonical(raw); toks=set(text.split())
        if not text: return 'Ask me something about PathSurfers and I will use the platform data to help.'
        calc=try_calculation(raw)
        if calc: return calc
        def has(*words): return any(w in toks for w in words)
        # Lightweight everyday conversation + Gen-Z shorthand. Keep platform/data
        # answers grounded, but let casual chat feel natural instead of robotic.
        now = datetime.now()
        if has('hello','hi','hey','heyy','heyyy','yo','sup','wassup','whatsup','hii','hiii','hola','namaste'):
            return "Yo 👋 I'm Mr.White. What's good? I can crunch numbers, explain PathSurfers, check your learning data, or just vibe/chat. 😎"
        if any(x in text for x in ('hru','how are you','how r u','how are u','how you doing','how u doing','how doin','how u doin','how you doin','hows it going','how is it going')):
            return "I'm good 😎 zero sleep, zero drama, fully ready. Wbu?"
        if any(x in text for x in ('what u doin','what are you doing','what r u doing','wyd','wut u doin')):
            return "Just chilling in the codebase, waiting for your next message 🤖⚡."
        if any(x in text for x in ('what about you','wbu','hbu')):
            return "Me? Just vibing in the codebase 😎. What's the move?"
        if any(x in text for x in ('lol','lmao','lmfao','haha','hehe','rofl')):
            return "LMAO 😭😂 fr."
        if any(x in text for x in ('thanks','thank you','thx','ty','tysm','thanx')):
            return "Anytime bro 😎🤝 no cap."
        if any(x in text for x in ('brb','be right back')):
            return "Bet 😎 I'll be here."
        if any(x in text for x in ('idk','i dont know','i do not know')):
            return "No stress 😎. Tell me what part is confusing and we'll figure it out."
        if any(x in text for x in ('ngl','not gonna lie','fr','for real','tbh','to be honest')):
            return "Facts 😎. I'm listening."
        if any(x in text for x in ('omg','oh my god','wtf','wth')):
            return "😭💀 Okayyy, what happened?"
        if any(x in text for x in ('good morning','gm')):
            return "Good morninggg ☀️😎 Hope the day is treating you nicely."
        if any(x in text for x in ('good night','gn')):
            return "Good night 🌙😴 Go recharge, legend."
        if any(x in text for x in ('bye','goodbye','see ya','cya','later')):
            return "Later bro 👋 Stay goated."
        if any(x in text for x in ('who are you','what are you','your name')):
            return "I'm Mr.White 🤖 — the local PathSurfers assistant. I can chat casually, calculate stuff, and use the platform's stored data when your question is about the app."
        if 'tomorrow' in text:
            d=now+timedelta(days=1); return f"Tomorrow is **{d.strftime('%A, %d %B %Y')}**. 📅"
        if 'yesterday' in text:
            d=now-timedelta(days=1); return f"Yesterday was **{d.strftime('%A, %d %B %Y')}**. 📅"
        if any(x in text for x in ('date today','today date','what date','todays date','today')):
            return f"Today is **{now.strftime('%A, %d %B %Y')}**. 📅"
        # WEB fix: this combined check must run BEFORE the plain 'what time' check below,
        # since that check matches on the bare word 'time' and would otherwise swallow
        # "date and time" queries before they ever reach this branch.
        if any(x in text for x in ('date and time','time and date','datetime')):
            return f"Right now it's **{now.strftime('%A, %d %B %Y')} · {now.strftime('%I:%M %p')}**. Full combo unlocked 🔓."
        if any(x in text for x in ('what time','time is it','current time','time now','abhi time','time')):
            return f"It's **{now.strftime('%I:%M %p')}** right now (server local time). ⏰"
        if any(x in text for x in ('what day','which day','day is it','today day')):
            return f"It's **{now.strftime('%A')}**. 📅"
        # WEB additive: week/year/month coverage, same genz voice, same "no data changed" rule —
        # these are brand-new branches, nothing above this line was touched.
        if any(x in text for x in ('what year','which year','current year','this year')):
            return f"We're locked into **{now.year}** rn. Time's flying, ngl 🚀."
        if any(x in text for x in ('what month','which month','current month','this month')):
            return f"It's **{now.strftime('%B %Y')}** right now. 🗓️"
        if any(x in text for x in ('what week','which week','week number','week is it','week of the year')):
            iso_year, iso_week, iso_day = now.isocalendar()
            return f"We're in **Week {iso_week}** of {iso_year} — day {iso_day} of the week. No cap, weeks fly by fast 🌀."
        if any(x in text for x in ('day after tomorrow',)):
            d=now+timedelta(days=2); return f"Day after tomorrow is **{d.strftime('%A, %d %B %Y')}**. 📅"
        if any(x in text for x in ('next week',)):
            d=now+timedelta(days=7); return f"Same day next week lands on **{d.strftime('%A, %d %B %Y')}**. 📅"
        # Gen-Z tone, while keeping answers grounded in actual platform data.
        if 'dashboard' in text:
            return "The Dashboard is basically your main learning HQ. It pulls your courses, progress and key activity together so you can keep moving without the tab chaos. 🚀"
        if 'repository' in text or 'repo' in text:
            return "The Repository is PathSurfers's shared knowledge zone for reports, manuals, case studies and learning resources. Search by topic, category or type and get straight to the useful stuff. 📚"
        if 'analytics' in text or 'analytical' in text:
            return "Analytics Hub is the numbers brain 🧠📊. It turns stored platform activity into role-aware insights: your growth, competencies, courses and assessments, plus authorized trainee/mentor connections where applicable."
        if 'competency' in text:
            rows=conn.execute('SELECT cs.subject,ROUND(AVG(cs.score),1) score FROM competency_scores cs JOIN competency_assessments ca ON ca.id=cs.assessment_id WHERE ca.username=? GROUP BY cs.subject ORDER BY score ASC',(username,)).fetchall()
            if rows: return 'Your current lowest recorded competency is **%s — %s%%**. That is the first place I would focus if you want the biggest learning ROI. 📈'% (rows[0]['subject'],rows[0]['score'])
            return 'Competency mapping uses subject-level assessment records to show where you are strong and where the gaps are. Your account does not have a competency score recorded yet.'
        if 'assessment' in text or 'score' in text:
            r=conn.execute('SELECT c.title,ca.score,ca.passed FROM course_assessments ca JOIN courses c ON c.id=ca.course_id WHERE ca.username=? ORDER BY ca.completed_at DESC,ca.id DESC LIMIT 1',(username,)).fetchone()
            return ('Your latest recorded assessment is **%s: %s%%** (%s). Keep cooking 🔥.'%(r['title'],r['score'],'passed' if r['passed'] else 'not passed')) if r else "No assessment attempt is recorded for your account yet."
        if 'progress' in text or 'growth' in text or 'doing' in text:
            p=profile(conn,username)
            if not p['enrolled']: return 'You have no course enrollments recorded yet, so there is not enough learning activity to calculate course progress.'
            growth_txt=(f" Your combined growth indicator is **{p['growth']}%**." if p['growth'] is not None else '')
            return f"You're on **{p['enrolled']}** enrolled course(s), with **{p['completed']}** completed based on stored module records.{growth_txt} That's the actual data, no vibes-only analytics. 📊"
        if 'course' in text or 'learn' in text or 'study' in text:
            query=' '.join(toks-{'course','courses','learn','learning','study','material','materials','find','recommend','me','for'})
            rows=conn.execute('SELECT id,title,category,level,description FROM courses ORDER BY title').fetchall()
            ranked=[]
            for r in rows:
                hay=norm(' '.join(str(r[k] or '') for k in ('title','category','level','description')))
                score=sum(3 if t in hay else .8 if any(difflib.SequenceMatcher(None,t,w).ratio()>.82 for w in hay.split()) else 0 for t in query.split())
                if score: ranked.append((score,r))
            ranked.sort(key=lambda x:(-x[0],x[1]['title']))
            if ranked: return 'I found %d relevant course(s). Closest match: **%s** (%s, %s). Pretty solid fit 🎯.'%(min(5,len(ranked)),ranked[0][1]['title'],ranked[0][1]['level'],ranked[0][1]['category'])
            return 'I searched the current course catalog, but no close match showed up. Try the subject or course name and I\'ll take another swing.'
        if 'trainer' in text or 'leader' in text or 'mentor' in text:
            rows=contacts_for(conn,username)
            if rows: return 'Your authorized contact(s): '+', '.join(f"**{x['fullname'] or x['username']}** ({x['role']})" for x in rows)+'. 🔗'
            return 'No assigned or selected mentor/leader/trainer relationship is recorded for your account yet.'
        if 'message' in text or 'chat' in text or 'notification' in text:
            rows=contacts_for(conn,username); total=unread_for(conn,username)
            return f"You have **{total} unread message(s)** from authorized contacts. Your Analytics Hub shows the appropriate one-to-one chat option." if rows else 'No authorized one-to-one chat contact is recorded for your account yet.'
        if 'certificate' in text:
            n=conn.execute("SELECT COUNT(*) FROM certificates WHERE username=? AND status='Issued'",(username,)).fetchone()[0]
            return f"You have **{n} issued certificate(s)** on record." if n else "No issued certificates are recorded on your account yet."
        if 'help' in text or 'what can' in text:
            return 'I can do math too 😎 Try `25 * 4`, `sqrt(144)`, `sin(30)`, `2^10`, or `log(100)`. Ask me the date, time, day, week or year too. For the platform, ask about your progress, competencies, assessments, courses, trainer, messages, Dashboard, Repository or Analytics Hub.'
        ctx=conn.execute('SELECT last_topic,last_intent,last_course_id FROM mrwhite_context WHERE username=?',(username,)).fetchone()
        if ctx and len(text.split())<=6 and ctx['last_course_id']:
            c=conn.execute('SELECT title FROM courses WHERE id=?',(ctx['last_course_id'],)).fetchone()
            if c: return f"You're referring to **{c['title']}**. Ask me about its modules, study material, learning outcomes, prerequisites or assessment."
        return "I know PathSurfers and can work from its stored data. And yep, calculator mode is live 🤓 — hit me with an expression like `18 / 3 + 7 * 2`."

    # Persist context for our answers too, without changing existing application rows other than the dedicated context row.
    old_mrwhite=mrwhite
