# PathSurfers Android app wrapper

This is a lightweight Android WebView shell for the unified PathSurfers web application. The same responsive web UI is used on Android, desktop and iOS/PWA, so product logic remains in one place.

## Build a debug APK

### Android Studio (recommended)

1. Install Android Studio.
2. Install **Android SDK Platform 35** and an Android SDK Build-Tools version compatible with Android Gradle Plugin 8.7.3.
3. Open this `android_wrapper` folder.
4. Let Android Studio sync Gradle.
5. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. The APK is created at:
   `app/build/outputs/apk/debug/app-debug.apk`

### Command line

If Gradle 8.9+ is installed:

```bash
cd android_wrapper
gradle clean assembleDebug
```

Then install with USB debugging enabled:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## Local Flask development

- Android emulator → `http://10.0.2.2:5000/`
- Physical Android phone → replace `START_URL` in `MainActivity.java` with the PC's LAN URL, e.g. `http://192.168.1.20:5000/`.
- Production → use the deployed HTTPS PathSurfers URL.

For a hackathon submission, use the deployed HTTPS URL for the final APK rather than a LAN address.
