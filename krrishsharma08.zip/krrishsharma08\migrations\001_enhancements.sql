
CREATE TABLE IF NOT EXISTS competency_assessments (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL,
 assessment_type TEXT NOT NULL,
 total_questions INTEGER DEFAULT 0,
 correct_answers INTEGER DEFAULT 0,
 started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
 completed_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS competency_scores (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 assessment_id INTEGER NOT NULL,
 subject TEXT NOT NULL,
 score REAL NOT NULL,
 competency_level TEXT NOT NULL,
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (assessment_id) REFERENCES competency_assessments(id)
);
CREATE TABLE IF NOT EXISTS questions (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 subject TEXT NOT NULL,
 topic TEXT NOT NULL,
 difficulty TEXT NOT NULL,
 question TEXT NOT NULL,
 explanation TEXT,
 marks INTEGER DEFAULT 1,
 active INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS question_options (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 question_id INTEGER NOT NULL,
 option_text TEXT NOT NULL,
 is_correct INTEGER DEFAULT 0,
 option_order INTEGER DEFAULT 1,
 FOREIGN KEY(question_id) REFERENCES questions(id)
);
CREATE TABLE IF NOT EXISTS assessment_attempts (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL,
 assessment_type TEXT NOT NULL,
 subject TEXT,
 total_questions INTEGER DEFAULT 0,
 correct_answers INTEGER DEFAULT 0,
 score REAL DEFAULT 0,
 started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
 completed_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS assessment_answers (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 attempt_id INTEGER NOT NULL,
 question_id INTEGER NOT NULL,
 selected_option_id INTEGER,
 is_correct INTEGER DEFAULT 0,
 FOREIGN KEY(attempt_id) REFERENCES assessment_attempts(id)
);
CREATE TABLE IF NOT EXISTS trainer_profiles (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT UNIQUE NOT NULL,
 designation TEXT,
 organization TEXT,
 qualification TEXT,
 experience_years REAL DEFAULT 0,
 bio TEXT,
 specialization TEXT,
 performance_score REAL DEFAULT 0,
 availability_status TEXT DEFAULT 'Available'
);
CREATE TABLE IF NOT EXISTS trainer_expertise (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 trainer_username TEXT NOT NULL,
 subject TEXT NOT NULL,
 topic TEXT,
 skill_level TEXT DEFAULT 'Intermediate',
 UNIQUE(trainer_username,subject,topic)
);
CREATE TABLE IF NOT EXISTS trainer_availability (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 trainer_username TEXT NOT NULL,
 day TEXT NOT NULL,
 start_time TEXT NOT NULL,
 end_time TEXT NOT NULL,
 available INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS trainer_questionnaires (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 trainer_username TEXT UNIQUE NOT NULL,
 teaching_experience TEXT,
 technical_expertise TEXT,
 subjects_handled TEXT,
 preferred_trainee_level TEXT,
 training_methodology TEXT,
 available_hours TEXT,
 certifications TEXT,
 research_interests TEXT,
 practical_expertise TEXT,
 updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS trainer_assignments (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 trainer_username TEXT NOT NULL,
 trainee_username TEXT NOT NULL,
 subject TEXT NOT NULL,
 reason TEXT,
 match_score REAL NOT NULL,
 status TEXT DEFAULT 'Recommended',
 assigned_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS course_resources (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 course_id INTEGER NOT NULL,
 module_id INTEGER,
 resource_id INTEGER NOT NULL,
 resource_type TEXT NOT NULL,
 UNIQUE(course_id,module_id,resource_id)
);
CREATE TABLE IF NOT EXISTS course_feedback (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 trainee_username TEXT NOT NULL,
 course_id INTEGER NOT NULL,
 module_id INTEGER,
 rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
 comments TEXT,
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS trainer_feedback (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 trainee_username TEXT NOT NULL,
 trainer_username TEXT NOT NULL,
 course_id INTEGER,
 rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
 comments TEXT,
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS certificates (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 certificate_id TEXT UNIQUE NOT NULL,
 username TEXT NOT NULL,
 course_id INTEGER NOT NULL,
 verification_code TEXT UNIQUE NOT NULL,
 issued_at DATETIME DEFAULT CURRENT_TIMESTAMP,
 score REAL NOT NULL,
 status TEXT DEFAULT 'Issued'
);
CREATE TABLE IF NOT EXISTS course_assessments (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL,
 course_id INTEGER NOT NULL,
 score REAL NOT NULL,
 passed INTEGER DEFAULT 0,
 total_questions INTEGER DEFAULT 0,
 completed_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS approvals (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 entity_type TEXT NOT NULL,
 entity_id TEXT NOT NULL,
 requested_by TEXT NOT NULL,
 reviewed_by TEXT,
 status TEXT DEFAULT 'Pending',
 reason TEXT,
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
 reviewed_at DATETIME
);
CREATE TABLE IF NOT EXISTS notifications (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL,
 title TEXT NOT NULL,
 message TEXT NOT NULL,
 notification_type TEXT DEFAULT 'system',
 is_read INTEGER DEFAULT 0,
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS training_deadlines (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL,
 description TEXT,
 assigned_to TEXT NOT NULL,
 course_id INTEGER,
 module_id INTEGER,
 due_date TEXT NOT NULL,
 status TEXT DEFAULT 'Pending'
);
CREATE TABLE IF NOT EXISTS learning_paths (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL,
 title TEXT NOT NULL,
 status TEXT DEFAULT 'Active',
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS learning_path_items (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 path_id INTEGER NOT NULL,
 item_type TEXT NOT NULL,
 item_id INTEGER,
 title TEXT NOT NULL,
 sequence_no INTEGER NOT NULL,
 status TEXT DEFAULT 'Recommended',
 FOREIGN KEY(path_id) REFERENCES learning_paths(id)
);
CREATE TABLE IF NOT EXISTS user_badges (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL,
 badge_code TEXT NOT NULL,
 title TEXT NOT NULL,
 awarded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(username,badge_code)
);
CREATE TABLE IF NOT EXISTS learning_streaks (
 username TEXT PRIMARY KEY,
 current_streak INTEGER DEFAULT 0,
 last_activity TEXT
);
