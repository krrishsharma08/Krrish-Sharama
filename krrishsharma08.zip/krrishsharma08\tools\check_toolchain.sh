#!/usr/bin/env bash
set -u
printf '%-18s %s\n' "Tool" "Status"
for pair in \
  "python3:Python" "node:Node.js" "npm:npm" "java:Java" "gradle:Gradle" "adb:Android ADB" "sdkmanager:Android SDK Manager"; do
  cmd="${pair%%:*}"; label="${pair#*:}"
  if command -v "$cmd" >/dev/null 2>&1; then
    printf '%-18s %s\n' "$label" "OK ($(command -v "$cmd"))"
  else
    printf '%-18s %s\n' "$label" "MISSING"
  fi
done
