# PathSurfers Changelog

## Unified build

- Merged the PathForge career-roadmapping experience into the Flask learning platform.
- Added server-side Groq career generation, milestone details and replanning.
- Added persistent PathForge-to-Learning-Path synchronization.
- Reworked competencies to derive from actual course progress and assessments.
- Added PathForge-aware Groq recommendations.
- Added Groq Analytics Coach insight.
- Activated the final Mr.White/FAM layer.
- Reduced registration to Trainee, Leader and Non-Reliable User.
- Added 5-digit Leader code flow and mandatory trainee code selection.
- Added real CSE/AI course curriculum.
- Fixed enrollment idempotency and CSRF-aware module completion.
- Added responsive cyberpunk/glass UI and PWA metadata.
