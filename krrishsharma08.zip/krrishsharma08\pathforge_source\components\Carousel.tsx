"use client";
import { useEffect, useRef, useState } from "react";
import { Brain, Users, Workflow, Sparkles, Bot, GitBranch, ChevronLeft, ChevronRight } from "lucide-react";

const SLIDES = [
  { icon: Brain, k: "What is PathForge?", t: "AI-powered career reverse engineering.", d: "Type the exact job you want. PathForge works backwards into the skills, roles and projects that lead there." },
  { icon: Users, k: "Who is it for?", t: "Students going after real roles.", d: "Internships, placements and niche technology jobs, for students and self-taught developers." },
  { icon: Workflow, k: "How it works", t: "Dream Role → AI → Career Graph → Projects → Interviews.", d: "Every step is generated for your goal, level and weekly hours." },
  { icon: Sparkles, k: "Why it's different", t: "Not a checklist. A living career map.", d: "Zoom, pan, unlock nodes and watch the whole path react to your progress." },
  { icon: Bot, k: "Mr.White", t: "Your AI career copilot inside PathSurfers.", d: "Ask why a step matters, replan your week, or practise interview questions for any node." },
  { icon: GitBranch, k: "Dynamic roadmap", t: "Already know something? We reroute.", d: "Mark a skill as known and the graph, unlocks and timeline update instantly." },
];

export default function Carousel() {
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);
  const [reduced, setReduced] = useState(false);
  const startX = useRef<number | null>(null);
  const resume = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    setReduced(window.matchMedia("(prefers-reduced-motion: reduce)").matches);
    return () => {
      if (resume.current) clearTimeout(resume.current);
    };
  }, []);

  useEffect(() => {
    if (paused || reduced) return;
    const t = setInterval(() => setI((v) => (v + 1) % SLIDES.length), 3000);
    return () => clearInterval(t);
  }, [paused, reduced]);

  const go = (n: number) => setI((n + SLIDES.length) % SLIDES.length);
  const S = SLIDES[i];
  const Icon = S.icon;

  return (
    <section
      className="carousel glass"
      role="region"
      aria-roledescription="carousel"
      aria-label="About PathForge"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocus={() => setPaused(true)}
      onBlur={() => setPaused(false)}
      onTouchStart={(e) => {
        startX.current = e.touches[0].clientX;
        setPaused(true);
        if (resume.current) clearTimeout(resume.current);
      }}
      onTouchEnd={(e) => {
        const dx = e.changedTouches[0].clientX - (startX.current ?? 0);
        if (Math.abs(dx) > 40) go(i + (dx < 0 ? 1 : -1));
        resume.current = setTimeout(() => setPaused(false), 3500);
      }}
    >
      <div className="slide" key={i} aria-live="polite">
        <div className="slide-ico"><Icon size={26} /></div>
        <div>
          <div className="eyebrow">{S.k}</div>
          <h3>{S.t}</h3>
          <p>{S.d}</p>
        </div>
      </div>
      <div className="car-foot">
        <button className="icon-btn" aria-label="Previous slide" onClick={() => go(i - 1)}><ChevronLeft size={18} /></button>
        <div className="dots" role="tablist">
          {SLIDES.map((_, n) => (
            <button key={n} role="tab" aria-selected={n === i} aria-label={`Slide ${n + 1}`} className={n === i ? "dot on" : "dot"} onClick={() => go(n)} />
          ))}
        </div>
        <button className="icon-btn" aria-label="Next slide" onClick={() => go(i + 1)}><ChevronRight size={18} /></button>
      </div>
      {!reduced && <div className="car-bar"><span key={i} style={{ animationPlayState: paused ? "paused" : "running" }} /></div>}
    </section>
  );
}
