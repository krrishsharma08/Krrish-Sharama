import os,sqlite3
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
con=sqlite3.connect(os.path.join(ROOT,"database.db"))
required=["users","courses","enrollments","messages","repository","competency_assessments","competency_scores","questions","trainer_profiles","trainer_expertise","trainer_availability","trainer_assignments","course_feedback","trainer_feedback","certificates","approvals","notifications","training_deadlines","learning_paths","learning_path_items"]
missing=[t for t in required if not con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(t,)).fetchone()]
print("Database verification:", "PASS" if not missing else "FAIL", "missing:",missing)
con.close()
