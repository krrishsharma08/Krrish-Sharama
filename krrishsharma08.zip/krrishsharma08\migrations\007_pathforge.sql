-- PathSurfers PathForge persistence bridge.
CREATE TABLE IF NOT EXISTS pathforge_roadmaps (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL,
  roadmap_id TEXT NOT NULL,
  title TEXT NOT NULL,
  target_role TEXT NOT NULL,
  payload TEXT NOT NULL,
  progress TEXT NOT NULL,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(username, roadmap_id)
);
