import os, sqlite3, unittest
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
from services.trainer_matching import match_trainers_for_trainee
class MatchingTests(unittest.TestCase):
    def test_programming_match(self):
        con=sqlite3.connect(os.path.join(ROOT,"database.db")); con.row_factory=sqlite3.Row
        rows=match_trainers_for_trainee(con,"kid","Programming"); con.close()
        self.assertTrue(rows); self.assertIn("match_score",rows[0]); self.assertIn("reason",rows[0])
if __name__=="__main__": unittest.main()
