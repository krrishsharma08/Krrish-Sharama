(function(){
  'use strict';
  const KEY='pathsurfers_pathforge_v2';
  const $=id=>document.getElementById(id);
  const examples=['ML Engineer · robotics','AI Safety Researcher · lab','Quant ML Engineer · fintech','Computer Vision Engineer · autonomy'];
  const state={roadmap:null,done:[],doing:[],known:[],skipped:[],details:{},baseHours:0,note:''};
  let selected=null;

  function esc(v){return String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
  function unique(a){return [...new Set(a||[])];}
  function save(){try{localStorage.setItem(KEY,JSON.stringify(state));}catch(e){}}
  function load(){try{const x=JSON.parse(localStorage.getItem(KEY)||'null');if(x&&x.roadmap){Object.assign(state,x);return true;}}catch(e){}return false;}
  function showError(msg){const el=$('pfError');el.textContent=msg;el.hidden=!msg;}
  function loading(on,text){$('pfLoading').hidden=!on;if(text)$('pfLoadingText').textContent=text;}
  const CSRF=(document.querySelector('meta[name="csrf-token"]')||{}).content||'';
  // Every call has a hard client timeout so no spinner or "preparing" state can hang.
  async function post(url,body,ms){
    const ctl=new AbortController();const timer=setTimeout(()=>ctl.abort(),ms||30000);
    try{
      const r=await fetch(url,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRF-Token':CSRF},body:JSON.stringify(body),signal:ctl.signal});
      const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error||j.message||('Request failed ('+r.status+')'));return j;
    }catch(e){throw new Error(e.name==='AbortError'?'AI request timed out — the local route stays active.':e.message);}
    finally{clearTimeout(timer);}
  }
  function aiPill(mode,text){const p=document.querySelector('.pf-ai-pill');if(!p)return;p.dataset.mode=mode;p.innerHTML='<i></i> '+esc(text);}
  function setNote(msg){state.note=msg;save();const n=$('pfNote');n.textContent=msg;n.hidden=!msg;if(msg)setTimeout(()=>{n.hidden=true;},4500);}

  $('pfExamples').innerHTML=examples.map(x=>`<button type="button" class="pf-chip">${esc(x)}</button>`).join('');
  $('pfExamples').addEventListener('click',e=>{const b=e.target.closest('.pf-chip');if(b)$('pfJob').value=b.textContent.split(' · ')[0]+' at a '+b.textContent.split(' · ')[1]+' company';});
  $('pfHours').addEventListener('input',()=>{$('pfHoursValue').textContent=$('pfHours').value+'h';});

  function status(node){
    if(state.done.includes(node.id)||state.known.includes(node.id)||state.skipped.includes(node.id))return state.known.includes(node.id)?'done':'done';
    if(state.doing.includes(node.id))return 'doing';
    const prereq=node.prerequisites||[];
    return prereq.every(x=>state.done.includes(x)||state.known.includes(x)||state.skipped.includes(x))?'ready':'locked';
  }
  function stats(){
    const r=state.roadmap,n=r.nodes||[],done=n.filter(x=>state.done.includes(x.id)||state.known.includes(x.id)||state.skipped.includes(x.id)).length;
    const rem=n.filter(x=>!state.done.includes(x.id)&&!state.known.includes(x.id)&&!state.skipped.includes(x.id)&&!x.optional).reduce((a,x)=>a+(+x.hours||0),0);
    const pct=Math.round(done*100/Math.max(1,n.length));
    const phase=r.phases.find(p=>n.some(x=>x.phaseId===p.id&&!['done'].includes(status(x))))?.title||'Complete';
    const weeks=Math.ceil(rem/Math.max(1,+r.input.hoursPerWeek||1));
    $('pfStats').innerHTML=[
      ['Progress',pct+'%',`<div class="pf-progress"><i style="width:${pct}%"></i></div>`],
      ['Milestones',`${done} / ${n.length}`,''],['Current phase',phase,''],['Remaining',`~${weeks} wks`,'' ],['Weekly target',(r.input.hoursPerWeek||0)+' h','']
    ].map(x=>`<div class="pf-stat"><small>${esc(x[0])}</small><b>${esc(x[1])}</b>${x[2]||''}</div>`).join('');
  }
  function layout(){
    const r=state.roadmap,n=r.nodes,phaseIndex=Object.fromEntries(r.phases.map((p,i)=>[p.id,i]));
    const groups={};n.forEach(x=>{const k=phaseIndex[x.phaseId]??0;(groups[k]??=[]).push(x);});
    const pos={};const colW=260,rowH=125;
    Object.keys(groups).forEach(k=>groups[k].forEach((node,i)=>pos[node.id]={x:+k*colW,y:75+i*rowH}));
    return {pos,width:Math.max(900,r.phases.length*colW+250),height:Math.max(520,Math.max(...Object.values(groups).map(g=>g.length),1)*rowH+180)};
  }
  function edgeHtml(a,b,locked){
    const x1=a.x+185,y1=a.y+48,x2=b.x,y2=b.y+48,dx=x2-x1,dy=y2-y1,len=Math.sqrt(dx*dx+dy*dy),ang=Math.atan2(dy,dx)*180/Math.PI;
    return `<div class="pf-edge ${locked?'locked':''}" style="left:${x1}px;top:${y1}px;width:${Math.max(0,len)}px;transform:rotate(${ang}deg)"></div>`;
  }
  function renderGraph(){
    const r=state.roadmap;if(!r)return;const g=$('pfGraph'),l=layout();g.style.width=l.width+'px';g.style.height=l.height+'px';
    let html='';
    r.phases.forEach((p,i)=>html+=`<div class="pf-phase" style="left:${i*260}px">PHASE ${i+1} · ${esc(p.title)}</div>`);
    const pos=l.pos;
    r.nodes.forEach(n=>(n.prerequisites||[]).forEach(pid=>{if(pos[pid]&&pos[n.id])html+=edgeHtml(pos[pid],pos[n.id],status(n)==='locked');}));
    r.nodes.forEach(n=>{const st=status(n),sel=selected===n.id?' selected':'';html+=`<button type="button" class="pf-node ${st} ${n.type==='target'?'target':''}${sel}" data-node="${esc(n.id)}" style="left:${pos[n.id].x}px;top:${pos[n.id].y}px"><span class="kind">${esc(n.type)} <span class="state">${st==='done'?'✓':st==='locked'?'◈':st==='doing'?'◆':'○'}</span></span><div class="title">${esc(n.title)}</div><div class="meta">${n.hours||0}h${n.optional?' · alternative':''}</div></button>`;});
    g.innerHTML=html;g.querySelectorAll('.pf-node').forEach(b=>b.addEventListener('click',()=>select(b.dataset.node)));
    lastW=l.width;applyZoom();
    stats();
  }
  // Graph viewport: auto-fit to the canvas width, with manual zoom (CSS zoom keeps scroll sizes correct).
  let zoom=null,lastW=900;
  function fitZoom(){const c=$('pfCanvas');return Math.max(.7,Math.min(1,(c.clientWidth-60)/Math.max(1,lastW)));}
  function applyZoom(){const g=$('pfGraph');if(!g)return;const z=zoom??fitZoom();g.style.zoom=z;}
  (function zoomUi(){const c=$('pfCanvas');if(!c||c.querySelector('.pf-zoom'))return;
    c.insertAdjacentHTML('afterbegin','<div class="pf-zoom" role="toolbar" aria-label="Graph zoom"><button type="button" data-z="-" aria-label="Zoom out">−</button><button type="button" data-z="fit" aria-label="Fit to screen">⤢</button><button type="button" data-z="+" aria-label="Zoom in">+</button></div>');
    c.querySelector('.pf-zoom').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;const cur=zoom??fitZoom();
      zoom=b.dataset.z==='fit'?null:Math.max(.4,Math.min(1.6,cur+(b.dataset.z==='+'?.15:-.15)));applyZoom();});
    let t;window.addEventListener('resize',()=>{clearTimeout(t);t=setTimeout(()=>{if(zoom===null)applyZoom();},120);},{passive:true});
  })();
  function panel(){
    const r=state.roadmap,n=r.nodes.find(x=>x.id===selected),p=$('pfPanelBody');if(!n){p.innerHTML='<div class="pf-empty-panel">Select a milestone to inspect the route, prerequisites, AI brief and portfolio evidence.</div>';return;}
    const st=status(n),details=state.details[n.id];
    const prereq=(n.prerequisites||[]).map(id=>r.nodes.find(x=>x.id===id)).filter(Boolean);
    p.innerHTML=`<div class="pf-kicker">${esc(n.type)} · ${esc(n.difficulty)} · ~${n.hours}h</div><h3>${esc(n.title)}</h3><span class="pf-badge">${st==='done'?(state.known.includes(n.id)?'Known':'Completed'):st==='doing'?'In progress':st==='ready'?'Ready to start':'Locked'}</span><p style="margin-top:12px">${esc(n.description)}</p>${prereq.length?`<div class="pf-panel-section"><h4>Prerequisites</h4><div class="pf-tag-list">${prereq.map(x=>`<span class="pf-tag">${status(x)==='done'?'✓ ':'◈ '}${esc(x.title)}</span>`).join('')}</div></div>`:''}<div class="pf-actions">${st==='ready'?'<button class="pf-btn pf-btn-primary" data-action="start">Start learning</button>':''}${(st==='ready'||st==='doing')?'<button class="pf-btn pf-btn-ghost" data-action="done">Mark completed</button>':''}${st!=='done'?'<button class="pf-btn pf-btn-ghost" data-action="known">I already know this</button>':'<button class="pf-btn pf-btn-ghost" data-action="undo">Undo</button>'}</div>${details?detailsHtml(details):'<div class="pf-panel-section"><p>Preparing a milestone brief from Groq AI…</p></div>'}`;
    p.querySelectorAll('[data-action]').forEach(b=>b.addEventListener('click',()=>action(b.dataset.action,n)));
    if(!details)loadDetails(n);
  }
  function detailsHtml(d){return `<div class="pf-panel-section"><h4>Why it matters</h4><p>${esc(d.whyItMatters||'')}</p></div>${(d.concepts||[]).length?`<div class="pf-panel-section"><h4>Core concepts</h4><div class="pf-tag-list">${d.concepts.map(x=>`<span class="pf-tag">${esc(x)}</span>`).join('')}</div></div>`:''}<div class="pf-panel-section"><h4>Weekend project · ~${esc(d.weekendProject?.hours||6)}h</h4><p><b>${esc(d.weekendProject?.title||'')}</b><br>${esc(d.weekendProject?.description||'')}</p></div>${d.portfolioEvidence?`<div class="pf-panel-section"><h4>Portfolio evidence</h4><p>${esc(d.portfolioEvidence)}</p></div>`:''}${d.githubSuggestion?`<div class="pf-panel-section"><h4>Open-source study</h4><p>${esc(d.githubSuggestion)}</p></div>`:''}${(d.interviewQuestions||[]).length?`<div class="pf-panel-section"><h4>Interview questions</h4><ol>${d.interviewQuestions.map(x=>`<li>${esc(x)}</li>`).join('')}</ol></div>`:''}`;}
  async function loadDetails(n){try{const j=await post('/api/pathforge/node-details',{node:{title:n.title,description:n.description,type:n.type,skills:n.skills},targetRole:state.roadmap.targetRole,companyType:state.roadmap.companyType,level:state.roadmap.input.level});state.details[n.id]=j.details;save();if(selected===n.id)panel();}catch(e){state.details[n.id]={whyItMatters:n.description+' (AI brief unavailable: '+e.message+')',concepts:n.skills||[],weekendProject:{title:'Build a small proof of '+n.title,description:'Ship a minimal, documented artifact that demonstrates this milestone and push it to your portfolio.',hours:6},portfolioEvidence:'A public repo or write-up showing '+n.title+'.'};if(selected===n.id)panel();}}
  function select(id){selected=id;renderGraph();panel();$('pfPanel').scrollIntoView({behavior:'smooth',block:'nearest'});}
  async function action(a,n){
    if(a==='start')state.doing=unique([...state.doing,n.id]);
    else if(a==='done'){state.done=unique([...state.done,n.id]);state.doing=state.doing.filter(x=>x!==n.id);setNote('✦ Milestone complete. New nodes may have unlocked.');}
    else if(a==='undo'){state.done=state.done.filter(x=>x!==n.id);state.known=state.known.filter(x=>x!==n.id);state.skipped=state.skipped.filter(x=>x!==n.id);}
    else if(a==='known'){
      state.done=unique([...state.done,n.id]);state.known=unique([...state.known,n.id]);state.doing=state.doing.filter(x=>x!==n.id);setNote('Knowledge captured. Replanning your route with Groq AI…');
      try{const rem=state.roadmap.nodes.filter(x=>!state.done.includes(x.id)&&x.type!=='target').map(x=>({id:x.id,title:x.title,hours:x.hours}));const j=await post('/api/pathforge/replan',{targetRole:state.roadmap.targetRole,justKnown:n.title,remaining:rem,hoursPerWeek:state.roadmap.input.hoursPerWeek});state.skipped=unique([...state.skipped,...(j.plan.skipNodeIds||[])]);setNote(j.plan.explanation||'Route updated.');}catch(e){setNote('Known skill recorded. AI replan was unavailable, so dependencies were updated locally.');}
    }
    save();renderGraph();panel();sync();
  }
  async function sync(){try{await post('/api/pathforge/sync',{roadmap:state.roadmap,done:state.done,known:state.known,skipped:state.skipped});}catch(e){}}
  function exportJson(){const blob=new Blob([JSON.stringify({roadmap:state.roadmap,done:state.done,known:state.known,skipped:state.skipped},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='pathsurfers-roadmap.json';a.click();URL.revokeObjectURL(a.href);}
  function showRoadmap(){const r=state.roadmap;$('pfForge').hidden=true;$('pfRoadmap').hidden=false;$('pfTarget').textContent=r.targetRole;$('pfSummary').textContent=r.summary;renderGraph();panel();window.scrollTo({top:0,behavior:'smooth'});sync();}
  function localFallback(input){
    const job=input.dreamJob||'Target career';
    const phases=[
      {id:'p1',title:'Foundation',description:'Build the core technical base required for the target role.'},
      {id:'p2',title:'Core Skills',description:'Develop role-specific engineering and AI skills.'},
      {id:'p3',title:'Applied Projects',description:'Turn skills into measurable portfolio evidence.'},
      {id:'p4',title:'Production Readiness',description:'Practice testing, deployment and systems thinking.'},
      {id:'p5',title:'Interview & Target',description:'Convert evidence into interview-ready proof.'}
    ];
    const base=[
      ['n1','Python & problem solving','skill','p1',12,[]],['n2','Git, Linux & developer workflow','skill','p1',8,['n1']],
      ['n3','Data structures & algorithms','skill','p1',20,['n1']],['n4','SQL & data modeling','skill','p1',12,['n1']],
      ['n5','Statistics & probability','skill','p2',16,['n3']],['n6','Machine learning fundamentals','skill','p2',24,['n5','n4']],
      ['n7','Model evaluation & error analysis','skill','p2',14,['n6']],['n8','Deep learning foundations','skill','p2',24,['n6']],
      ['n9','Target-role mini project','project','p3',24,['n7']],['n10','End-to-end portfolio project','project','p3',36,['n8','n9']],
      ['n11','APIs, testing & deployment','skill','p4',18,['n10']],['n12','Production ML / system design','skill','p4',22,['n7','n11']],
      ['n13','Portfolio review & technical storytelling','interview','p5',10,['n10','n12']],
      ['n14','Target-role interview loop','interview','p5',14,['n3','n13']],['n15',job,'target','p5',8,['n12','n14']]
    ];
    return {title:'PathForge roadmap · '+job,targetRole:job,companyType:input.companyType||'',
      summary:'A resilient career route toward '+job+', calibrated to '+input.hoursPerWeek+' hours/week for '+input.months+' months.',
      phases,nodes:base.map(x=>({id:x[0],phaseId:x[3],title:x[1],type:x[2],description:'Practical milestone for '+job+'.',skills:[],prerequisites:x[5],hours:x[4],difficulty:x[4]>=24?'hard':'medium',optional:false})),
      id:'local-'+Date.now(),createdAt:new Date().toISOString(),input,aiStatus:'fallback'};
  }

  async function forge(e){
    e.preventDefault(); showError('');
    const input={dreamJob:$('pfJob').value,level:$('pfLevel').value,skills:$('pfSkills').value,hoursPerWeek:+$('pfHours').value,months:+$('pfMonths').value,companyType:$('pfCompany').value};
    if(!input.dreamJob.trim()){showError('Describe your dream job first.');return;}

    // HARD RELIABILITY RULE: the main experience never waits for Flask, Groq, DNS,
    // an overloaded server, or a stale browser request. Render locally first.
    loading(false);
    state.roadmap=localFallback(input); state.done=[]; state.doing=[]; state.known=[]; state.skipped=[]; state.details={};
    state.baseHours=state.roadmap.nodes.reduce((a,x)=>a+(+x.hours||0),0);
    save(); showRoadmap();
    setNote('✦ PathForge is live. Validated local route loaded; Groq enrichment is running in the background.');

    // Persist/swap to the server-generated deterministic graph if available.
    try{
      const j=await post('/api/pathforge/generate',input,4000);
      if(j.roadmap){
        const progress={done:[...state.done],doing:[...state.doing],known:[...state.known],skipped:[...state.skipped]};
        state.roadmap=j.roadmap; Object.assign(state,progress); state.baseHours=state.roadmap.nodes.reduce((a,x)=>a+(+x.hours||0),0); save(); showRoadmap();
      }
    }catch(e){}

    // Groq is optional enrichment, never a gate. A timeout/failure/malformed JSON
    // leaves the fully usable local roadmap on screen.
    const forgeId=state.roadmap.id;
    aiPill('busy','GROQ ENRICHING…');
    const enrichBar=$('pfEnrich'); if(enrichBar)enrichBar.hidden=false;
    post('/api/pathforge/enrich',input,45000).then(ai=>{
      if(ai.roadmap&&Array.isArray(ai.roadmap.nodes)&&ai.roadmap.nodes.length&&state.roadmap&&state.roadmap.id===forgeId){
        state.roadmap=ai.roadmap; state.done=[]; state.doing=[]; state.known=[]; state.skipped=[]; state.details={};
        state.baseHours=state.roadmap.nodes.reduce((a,x)=>a+(+x.hours||0),0); selected=null; save(); showRoadmap();
        aiPill('on','GROQ AI ROUTE'); setNote('✦ Groq AI roadmap validated and active — '+ai.roadmap.nodes.length+' milestones specific to your target.');
      }
    }).catch(err=>{aiPill('off','LOCAL ROUTE'); setNote('Showing the validated local route. '+err.message);})
      .finally(()=>{loading(false); if(enrichBar)enrichBar.hidden=true;});
  }

  $('pfForm').addEventListener('submit',forge);$('pfClose').addEventListener('click',()=>{selected=null;panel();});$('pfExport').addEventListener('click',exportJson);$('pfNew').addEventListener('click',()=>{state.roadmap=null;localStorage.removeItem(KEY);location.reload();});
  loading(false);
  fetch('/api/ai/status',{credentials:'same-origin'}).then(r=>r.json()).then(s=>{
    if(!s.configured)aiPill('off','LOCAL ENGINE · ADD GROQ KEY');
    else if(s.last_error)aiPill('off','GROQ: '+String(s.last_error).slice(0,40));
    else aiPill('on','GROQ AI READY');
  }).catch(()=>aiPill('off','LOCAL ENGINE'));
  if(load()){showRoadmap();if(state.roadmap&&state.roadmap.aiStatus==='groq')aiPill('on','GROQ AI ROUTE');}
})();
