# PathSurfers API Highlights

## PathForge

- `POST /api/pathforge/generate` — validates learner input, calls Groq, sanitizes and returns a roadmap.
- `POST /api/pathforge/node-details` — generates a grounded milestone brief.
- `POST /api/pathforge/replan` — conservatively removes only redundant milestones.
- `POST /api/pathforge/sync` — persists roadmap/progress into the learning-path and context layers.

## Platform

The existing course, assessment, repository, trainer, messaging, notification, certificate, analytics and Mr.White endpoints remain available. All state-changing requests are protected by the platform's CSRF/session controls.
