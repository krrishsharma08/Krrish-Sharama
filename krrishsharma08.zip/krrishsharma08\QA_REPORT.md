# PathSurfers — Release QA Notes

## Submission identity
- Product: **PathSurfers**
- Problem: **Reverse-Engineered Career Roadmapper**
- Core: Generative AI + interactive visualisation
- Unified platform: PathForge + courses + evidence-based competencies + recommendations + Mr.White + Analytics Hub.

## Verified statically
- Python source compiles.
- Registration exposes exactly Trainee, Leader and Non-Reliable User.
- Leader generates a 5-digit code; Trainee validates a chosen Leader code; Non-Reliable User receives no code.
- Non-Reliable User is blocked from direct-message sending.
- Course enrollment uses parameterized SQL and handles duplicate/invalid enrollment safely.
- Competency cards no longer seed arbitrary proficiency percentages; assessment evidence and real course/module progress are used.
- Recommendations are constrained to the actual course catalogue and can use Groq.
- Groq API keys are server-side only.
- PathForge output is validated/sanitized before use.
- PWA manifest and responsive assets are included.
- Android WebView wrapper source is included.

## Honest build limitation
A live Groq request and signed APK require internet access / Android SDK respectively. The package therefore includes the complete source and reproducible APK build instructions rather than falsely claiming a signed APK was produced in this offline build environment.
