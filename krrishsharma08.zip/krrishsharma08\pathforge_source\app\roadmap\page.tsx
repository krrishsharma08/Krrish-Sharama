"use client";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Compass, Download, Plus, Sparkles } from "lucide-react";
import RoadmapView from "@/components/RoadmapView";
import NodePanel from "@/components/NodePanel";
import { computeStatus } from "@/lib/graph";
import { loadState, saveState, type AppState } from "@/lib/store";

const post = (url: string, body: unknown) => fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });

export default function RoadmapPage() {
  const router = useRouter();
  const [s, setS] = useState<AppState | null>(null);
  const [sel, setSel] = useState<string | null>(null);
  const [dLoad, setDLoad] = useState(false);
  const [dErr, setDErr] = useState("");
  const [replanning, setReplanning] = useState(false);
  const [toast, setToast] = useState("");

  useEffect(() => { const st = loadState(); if (!st) router.replace("/"); else setS(st); }, [router]);
  useEffect(() => {
    if (!s) return;
    saveState(s);
    const timer = window.setTimeout(() => {
      fetch("/api/pathforge/sync", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ roadmap: s.roadmap, done: s.done, known: s.known, skipped: s.skipped }) }).catch(() => {});
    }, 500);
    return () => window.clearTimeout(timer);
  }, [s]);
  useEffect(() => { if (!toast) return; const t = setTimeout(() => setToast(""), 3200); return () => clearTimeout(t); }, [toast]);

  const r = s?.roadmap;
  const doneSet = useMemo(() => new Set([...(s?.done || []), ...(s?.skipped || [])]), [s?.done, s?.skipped]);
  const status = useMemo(() => (r && s ? computeStatus(r.nodes, doneSet, new Set(s.doing)) : {}), [r, s, doneSet]);

  const stats = useMemo(() => {
    if (!r || !s) return null;
    const total = r.nodes.length;
    const doneN = r.nodes.filter((n) => doneSet.has(n.id)).length;
    const remH = r.nodes.filter((n) => !doneSet.has(n.id) && !n.optional).reduce((a, n) => a + n.hours, 0);
    const weeks = Math.ceil(remH / Math.max(1, r.input.hoursPerWeek));
    const baseWeeks = Math.ceil(s.baseHours / Math.max(1, r.input.hoursPerWeek));
    const phase = r.phases.find((p) => r.nodes.some((n) => n.phaseId === p.id && !doneSet.has(n.id)))?.title || "Complete 🎉";
    return { total, doneN, pct: Math.round((doneN / total) * 100), weeks, saved: Math.max(0, baseWeeks - weeks), phase,
      avail: Object.values(status).filter((x) => x === "available").length, prog: Object.values(status).filter((x) => x === "progress").length,
      locked: Object.values(status).filter((x) => x === "locked").length };
  }, [r, s, doneSet, status]);

  async function loadDetails(id: string) {
    if (!s) return;
    const n = s.roadmap.nodes.find((x) => x.id === id);
    if (!n) return;
    setDLoad(true); setDErr("");
    try {
      const res = await post("/api/pathforge/node-details", { node: { title: n.title, description: n.description, type: n.type, skills: n.skills }, targetRole: s.roadmap.targetRole, companyType: s.roadmap.companyType, level: s.roadmap.input.level });
      const j = await res.json();
      if (!res.ok) throw new Error(j.error || "Could not load details.");
      setS((p) => (p ? { ...p, details: { ...p.details, [id]: j.details } } : p));
    } catch (e) { setDErr(e instanceof Error ? e.message : "Could not load details."); }
    finally { setDLoad(false); }
  }
  useEffect(() => { if (sel && s && !s.details[sel]) loadDetails(sel); /* eslint-disable-next-line */ }, [sel, !!s]);

  if (!s || !r || !stats) return <div className="boot"><div className="orb"><Compass size={30} /></div></div>;

  const upd = (f: (p: AppState) => AppState) => setS((p) => (p ? f(p) : p));
  const uniq = (a: string[]) => Array.from(new Set(a));
  const node = sel ? r.nodes.find((n) => n.id === sel) : undefined;

  function start(id: string) { upd((p) => ({ ...p, doing: uniq([...p.doing, id]) })); }
  function toggleDone(id: string) {
    const was = doneSet.has(id);
    upd((p) => ({ ...p, done: was ? p.done.filter((x) => x !== id) : uniq([...p.done, id]), known: was ? p.known.filter((x) => x !== id) : p.known, doing: p.doing.filter((x) => x !== id) }));
    if (!was) setToast("✦ Milestone complete. New nodes may have unlocked!");
  }
  async function markKnown(id: string) {
    const n = r!.nodes.find((x) => x.id === id);
    if (!n) return;
    upd((p) => ({ ...p, done: uniq([...p.done, id]), known: uniq([...p.known, id]), doing: p.doing.filter((x) => x !== id) }));
    setToast(`“${n.title}” marked as known. Rerouting…`);
    setReplanning(true);
    try {
      const after = new Set([...Array.from(doneSet), id]);
      const remaining = r!.nodes.filter((x) => !after.has(x.id) && x.type !== "target").map((x) => ({ id: x.id, title: x.title, hours: x.hours }));
      const res = await post("/api/pathforge/replan", { targetRole: r!.targetRole, justKnown: n.title, remaining, hoursPerWeek: r!.input.hoursPerWeek });
      const j = await res.json();
      if (!res.ok) throw new Error(j.error);
      const valid = new Set(remaining.map((x) => x.id));
      const skip = (j.plan.skipNodeIds as string[]).filter((x) => valid.has(x));
      upd((p) => ({ ...p, skipped: uniq([...p.skipped, ...skip]), note: j.plan.explanation + (j.plan.thisWeek.length ? `\nThis week: ${j.plan.thisWeek.join(" • ")}` : "") }));
    } catch {
      upd((p) => ({ ...p, note: `Marked “${n.title}” as known. Unlocks and timeline were updated locally (the AI explanation was unavailable).` }));
    } finally { setReplanning(false); }
  }

  const byId = (id: string) => r.nodes.find((n) => n.id === id);
  function exportJson() {
    const blob = new Blob([JSON.stringify({ roadmap: r, done: s!.done, known: s!.known, skipped: s!.skipped }, null, 2)], { type: "application/json" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "pathforge-roadmap.json"; a.click(); URL.revokeObjectURL(a.href);
  }

  return (
    <div className="app">
      <header className="rm-head glass">
        <button className="brand plain" onClick={() => router.push("/")} aria-label="Back to home"><span className="logo"><Compass size={16} /></span><span className="hide-s">PATHFORGE</span></button>
        <div className="rm-title"><b>{r.targetRole}</b><small>{r.companyType || r.title}</small></div>
        <div className="nav-r">
          <button className="btn btn-ghost sm" onClick={exportJson}><Download size={15} /><span className="hide-s">Export</span></button>
          <button className="btn btn-ghost sm" onClick={() => { window.location.href = "/chat"; }}><Sparkles size={15} /><span className="hide-s">Mr.White</span></button><button className="btn btn-ghost sm" onClick={() => router.push("/")}><Plus size={15} /><span className="hide-s">New</span></button>
        </div>
      </header>

      <div className="stats">
        <div className="stat"><small>Progress</small><b>{stats.pct}%</b><div className="bar"><span style={{ width: `${stats.pct}%` }} /></div></div>
        <div className="stat"><small>Milestones</small><b>{stats.doneN} / {stats.total}</b></div>
        <div className="stat wide"><small>Current phase</small><b>{stats.phase}</b></div>
        <div className="stat"><small>Remaining</small><b>~{stats.weeks} wks</b>{stats.saved > 0 && <em>{stats.saved} wks saved</em>}</div>
        <div className="stat"><small>Weekly target</small><b>{r.input.hoursPerWeek} h</b></div>
        <div className="stat"><small>Skill gap</small><b className="gap"><i className="c">{s.known.length}</i><i className="p">{stats.prog}</i><i className="a">{stats.avail}</i><i className="l">{stats.locked}</i></b></div>
      </div>

      <div className="canvas">
        <RoadmapView roadmap={r} status={status} selectedId={sel} onSelect={setSel} />
        <div className="legend glass"><span className="lg completed" />Done <span className="lg available" />Ready <span className="lg progress" />Learning <span className="lg locked" />Locked <span className="lg optional" />Optional</div>
        {(s.note || replanning) && (
          <div className="note glass" role="status">
            <Sparkles size={16} />
            <p>{replanning ? "Mr.White is replanning your route…" : s.note}</p>
            {!replanning && <button className="link" onClick={() => upd((p) => ({ ...p, note: "" }))}>Dismiss</button>}
          </div>
        )}
        {node && (
          <NodePanel
            node={node} status={status[node.id]} known={s.known.includes(node.id)}
            prereqs={node.prerequisites.map((id) => ({ title: byId(id)?.title || id, done: doneSet.has(id) }))}
            details={s.details[node.id]} loading={dLoad} error={dErr}
            onRetry={() => loadDetails(node.id)} onClose={() => setSel(null)}
            onStart={() => start(node.id)} onDone={() => toggleDone(node.id)} onKnown={() => markKnown(node.id)} onUndo={() => toggleDone(node.id)}
          />
        )}
      </div>

      {toast && <div className="toast" role="status">{toast}</div>}
    </div>
  );
}
