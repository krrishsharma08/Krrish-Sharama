-- PathSurfers FAM final additive schema. Existing tables/rows are untouched.
CREATE TABLE IF NOT EXISTS fam_login_rate_limits (
 identifier_hash TEXT PRIMARY KEY, attempts INTEGER NOT NULL DEFAULT 0,
 window_started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, locked_until DATETIME
);
CREATE TABLE IF NOT EXISTS fam_user_preferences (
 username TEXT PRIMARY KEY, display_name TEXT, theme TEXT NOT NULL DEFAULT 'light', updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS mrwhite_conversations (
 id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, title TEXT NOT NULL DEFAULT 'New chat',
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(username) REFERENCES users(username) ON UPDATE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_mrw_conv_user_updated ON mrwhite_conversations(username,updated_at DESC);
CREATE TABLE IF NOT EXISTS mrwhite_messages (
 id INTEGER PRIMARY KEY AUTOINCREMENT, conversation_id INTEGER NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('user','assistant','system')), content TEXT NOT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(conversation_id) REFERENCES mrwhite_conversations(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_mrw_msg_conv ON mrwhite_messages(conversation_id,id);
CREATE TABLE IF NOT EXISTS course_assets (
 id INTEGER PRIMARY KEY AUTOINCREMENT, course_id INTEGER NOT NULL, module_id INTEGER,
 asset_type TEXT NOT NULL CHECK(asset_type IN ('pdf','photo','video')), filename TEXT NOT NULL,
 stored_name TEXT NOT NULL UNIQUE, mime_type TEXT NOT NULL, size_bytes INTEGER NOT NULL DEFAULT 0,
 created_by TEXT, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(course_id) REFERENCES courses(id) ON DELETE CASCADE,
 FOREIGN KEY(module_id) REFERENCES course_modules(id) ON DELETE SET NULL,
 FOREIGN KEY(created_by) REFERENCES users(username) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_course_assets_course ON course_assets(course_id,created_at);
CREATE TABLE IF NOT EXISTS emergency_drill_templates (
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, scenario TEXT NOT NULL, instructions TEXT,
 duration_seconds INTEGER NOT NULL DEFAULT 300, status TEXT NOT NULL DEFAULT 'Published', created_by TEXT,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS webinar_reminders (
 id INTEGER PRIMARY KEY AUTOINCREMENT, webinar_id INTEGER NOT NULL, username TEXT NOT NULL, reminder_at DATETIME NOT NULL,
 UNIQUE(webinar_id,username), FOREIGN KEY(webinar_id) REFERENCES webinars(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS fam_ai_recommendations (
 id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, generated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, payload TEXT NOT NULL
);
