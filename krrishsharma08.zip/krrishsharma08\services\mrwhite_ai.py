"""PathSurfers FAM additive: the AI-powered layer of Mr.White.

This sits ON TOP of the existing local/offline Mr.White logic in app.py.
app.py still runs its calculator + deterministic intent rules first; only
when those don't produce an answer do we ask Groq, and we always hand Groq
real, freshly-queried data about the signed-in user rather than letting it
guess — so it can't hallucinate scores, courses or deadlines that don't exist.
"""
from services.groq_service import chat_completion, ai_enabled

PROJECT_FEATURES = """
PathSurfers platform features you can help navigate the user to:
- /  (Dashboard): overview of the user's progress
- /courses : browse & search all courses, enroll
- /courses/create : (Trainer/Leader/Meteorologist/Administrator only) create a new course
- /competencies : competency levels per subject, with real percentage scores
- /ai-quiz : AI-generated adaptive quiz to identify skill gaps
- /recommendations : AI-recommended next course based on quiz/competency gaps
- /repository : shared learning resources (PDF/links/videos)
- /trainer-matching : get matched with a trainer for a weak subject
- /learning-path : personalised sequence of courses
- /webinars : upcoming/past webinars
- /emergency-drills : emergency drill schedule
- /analytics : personal or org-wide analytics dashboard
- /account or /profile : profile settings, dark mode toggle, certificate display-name
- /chat : this chat with Mr.White, with saved conversation history
"""

MR_WHITE_SYSTEM = (
    "You are Mr.White, the in-app AI assistant for PathSurfers, an AI career-roadmap "
    "and learning platform built around PathForge (reverse-engineered career roadmaps). You talk like a friendly gen-z human — "
    "casual, warm, a little playful, light emoji use, short punchy sentences — but you are "
    "genuinely helpful and never sacrifice accuracy for vibe. You know this platform inside "
    "out and actively help users navigate it by name-dropping the right page/route. "
    "You ONLY answer using the LIVE USER DATA given to you below — never invent scores, "
    "course names, deadlines or dates that aren't in that data. If something isn't in the "
    "data, say so honestly instead of guessing. Keep replies concise (under ~120 words) "
    "unless the user asks for depth. You can also help with general questions, quick "
    "definitions, study tips, and light conversation — still gen-z, still accurate.\n"
    + PROJECT_FEATURES
)


def build_context_block(user_row, enrolled, assignment, deadlines, assessments, gaps=None):
    lines = []
    if user_row:
        lines.append(f"User: {user_row.get('fullname') or user_row.get('username')} "
                      f"(role: {user_row.get('role')})")
    if enrolled:
        lines.append("Enrolled courses:")
        for c in enrolled:
            lines.append(f"  - {c['title']}: {c['done'] or 0}/{c['total_modules'] or 0} modules done")
    else:
        lines.append("Enrolled courses: none yet.")
    if assignment:
        lines.append(f"Current trainer assignment: {assignment['subject']} with "
                      f"{assignment['trainer']} ({assignment['status']})")
    if deadlines:
        lines.append("Upcoming deadlines:")
        for d in deadlines:
            lines.append(f"  - {d['title']} due {d['due_date']}")
    if assessments:
        lines.append("Assessment scores:")
        for a in assessments:
            lines.append(f"  - {a['title']}: {a['score']}")
    if gaps:
        weak = gaps.get("weak") or []
        if weak:
            lines.append(f"Identified weak competency domains: {', '.join(weak)}")
    return "\n".join(lines) if lines else "No platform data available for this user yet."


def ask_mr_white(user_message, context_block, history=None):
    """history: list of {'role': 'user'|'assistant', 'content': str}, most-recent-last,
    already trimmed by the caller. Returns text or None (caller falls back to the
    existing local deterministic Mr.White)."""
    if not ai_enabled():
        return None
    messages = [{"role": "system", "content": MR_WHITE_SYSTEM + "\n\nLIVE USER DATA:\n" + context_block}]
    for turn in (history or [])[-10:]:
        role = "assistant" if turn.get("role") == "assistant" else "user"
        messages.append({"role": role, "content": str(turn.get("content", ""))[:2000]})
    messages.append({"role": "user", "content": user_message[:2000]})
    return chat_completion(messages, temperature=0.8, max_tokens=350)
