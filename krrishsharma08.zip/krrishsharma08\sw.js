// PathSurfers service worker. Bump CACHE_NAME whenever static assets change:
// the activate step deletes every older cache, so no device keeps stale JS.
const CACHE_NAME = 'pathsurfers-v7';
const STATIC_ASSETS = [
  '/static/manifest.json',
  '/static/css/style.css',
  '/static/css/pathsurfers-ui.css',
  '/static/js/script.js',
  '/static/icons/icon.svg',
  '/static/icons/icon-192.png',
  '/static/icons/icon-512.png',
  '/static/css/pathforge.css',
  '/static/js/pathforge.js'
];
const PUBLIC_PAGES = new Set(['/login', '/register', '/recover']);

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(STATIC_ASSETS)).catch(() => {}));
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys =>
    Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key)))
  ));
  self.clients.claim();
});

function networkFirst(request) {
  return fetch(request).then(response => {
    if (response.ok) {
      const copy = response.clone();
      caches.open(CACHE_NAME).then(c => c.put(request, copy));
    }
    return response;
  }).catch(() => caches.match(request));
}

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;
  // Authenticated pages and /api/* are never cached (no stale private data).
  // Static assets are network-first so code fixes reach users immediately,
  // with the cache used only when the device is offline.
  if (url.pathname.startsWith('/static/') || PUBLIC_PAGES.has(url.pathname)) {
    event.respondWith(networkFirst(event.request));
  }
});
