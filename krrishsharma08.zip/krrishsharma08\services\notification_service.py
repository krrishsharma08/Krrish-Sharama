
def notify(conn, username, title, message, notification_type="system"):
    conn.execute("""INSERT INTO notifications(username,title,message,notification_type,is_read,created_at)
                    VALUES (?,?,?,?,0,CURRENT_TIMESTAMP)""",
                 (username,title,message,notification_type))
def unread_count(conn, username):
    r=conn.execute("SELECT COUNT(*) c FROM notifications WHERE username=? AND is_read=0",(username,)).fetchone()
    return r["c"]
