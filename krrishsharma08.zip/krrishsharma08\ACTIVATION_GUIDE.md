# PathSurfers Local Activation

1. Create/activate a Python virtual environment.
2. Install `requirements.txt`.
3. Ensure `.env` contains a valid `GROQ_API_KEY` and model name.
4. Run `python app.py`.
5. Open `http://127.0.0.1:5000`.
6. Sign in, then open PathForge.

The Groq key is read only by the server. Do not commit `.env` or publish the key.
