# PathForge: Your dream job. Reverse-engineered.

**Product:** PathSurfers — Reverse-Engineered Career Roadmapper + Learning Intelligence

## What it does
Type a hyper-specific target job ("AI Ethics Engineer at a robotics company"), add your level, known skills, hours per week and timeline. Groq generates a structured career dependency graph that is rendered as an interactive skill tree (zoom, pan, click). Clicking a node asks the AI for a milestone brief: why it matters, weekend project, portfolio evidence, interview questions, common mistakes. Marking a skill as known unlocks downstream nodes, shrinks the timeline and asks the AI to skip redundant steps. **Mr.White**, an in-app AI mentor, answers using your roadmap context and keeps its chat history.

## Done / Left / Plan
- **Done:** AI roadmap generation with Zod validation + retry; interactive React Flow graph; node details; known/complete/start states; dynamic replanning; time constraints; progress and skill-gap stats; Mr.White chat with persistence; JSON export; responsive UI (bottom sheets on mobile); error handling.
- **Left:** server-side database (progress and chat currently persist in the browser's localStorage); accounts; PDF/shareable links; role comparison; "people who took this path" (would need real data); automated tests.
- **Plan:** Prisma + SQLite/Postgres, shareable public roadmaps, compare two roles, Capacitor Android build.

## Architecture and why
- **Next.js 14 (App Router) + TypeScript:** one project for UI and server routes, so the API key never reaches the browser.
- **API routes:** `/api/generate`, `/api/node-details`, `/api/replan`, `/api/chat`, all server-side calls to `https://api.x.ai/v1`.
- **Structured output:** the model is asked for strict JSON; `lib/schema.ts` (Zod) validates it, `generateStructured` retries once with a correction prompt, and `sanitizeRoadmap` forces a valid DAG (prerequisites only point to earlier nodes, exactly one target).
- **React Flow (@xyflow/react):** pan/zoom/minimap out of the box; node state is derived from progress (`lib/graph.ts`).
- **Persistence:** browser localStorage (zero setup, survives refresh). Honest trade-off versus a database, see "Left".
- **Security:** key only in `.env.local`, request-size limits, input validation, in-memory rate limiting, friendly error messages.

## What we added beyond the brief
Mr.White mentor chat with a compact context builder, AI-assisted replanning, skill-gap counters, timeline "weeks saved", JSON export, offline sample roadmap, model fallback list.

## How to run
```
npm install
copy .env.example .env.local     (then paste your NEW key after GROQ_API_KEY=)
npm run dev
```
Open http://localhost:3000. Production: `npm run build` then `npm start`.

## Tools and AI used
Grok via the Groq API powers the product. The code was written with AI assistance (Claude), as permitted by the hackathon rules. Libraries: Next.js, React, @xyflow/react, Zod, lucide-react.

## Who it is for
College and self-taught students targeting specific roles, internships and placements.

## Notes
- AI resources are suggestions, not verified; the UI labels them as such. The "Explore Demo" roadmap is hand-written sample data, not AI output.
- Never commit `.env.local`. If a key was ever shared publicly, rotate it.
