
-- PathSurfers GHEE additive migration.
-- Creates only new tables/indexes. No existing rows are updated/deleted.
CREATE TABLE IF NOT EXISTS repository_ownership (
    repository_id INTEGER PRIMARY KEY,
    uploaded_by TEXT NOT NULL,
    uploaded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(repository_id) REFERENCES repository(id) ON DELETE CASCADE,
    FOREIGN KEY(uploaded_by) REFERENCES users(username) ON UPDATE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_repository_ownership_user
ON repository_ownership(uploaded_by);

CREATE TABLE IF NOT EXISTS course_study_materials (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    course_id INTEGER NOT NULL,
    section_title TEXT NOT NULL,
    material TEXT NOT NULL,
    sequence_no INTEGER NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(course_id) REFERENCES courses(id) ON DELETE CASCADE,
    UNIQUE(course_id, sequence_no)
);

CREATE INDEX IF NOT EXISTS idx_course_study_materials_course
ON course_study_materials(course_id, sequence_no);

CREATE TABLE IF NOT EXISTS mrwhite_context (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    role TEXT,
    last_intent TEXT,
    last_topic TEXT,
    last_course_id INTEGER,
    last_repository_id INTEGER,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(username),
    FOREIGN KEY(username) REFERENCES users(username) ON UPDATE CASCADE,
    FOREIGN KEY(last_course_id) REFERENCES courses(id) ON DELETE SET NULL,
    FOREIGN KEY(last_repository_id) REFERENCES repository(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_mrwhite_context_user
ON mrwhite_context(username);
