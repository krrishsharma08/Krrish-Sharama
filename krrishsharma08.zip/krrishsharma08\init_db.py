import sqlite3

def init_db():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    # Create users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'Trainee',
            fullname TEXT,
            email TEXT,
            phone TEXT,
            dob TEXT,
            ref_code TEXT,
            leader_ref_code TEXT
        )
    ''')

    # Create courses table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS courses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            category TEXT NOT NULL,
            level TEXT NOT NULL,
            description TEXT
        )
    ''')

    # Create enrollments table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS enrollments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            course_id INTEGER NOT NULL,
            FOREIGN KEY (course_id) REFERENCES courses (id)
        )
    ''')

    # Create messages table for real-time chat functionality
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender_username TEXT NOT NULL,
            receiver_username TEXT NOT NULL,
            message TEXT NOT NULL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Seed initial course data if table is empty
    cursor.execute('SELECT COUNT(*) FROM courses')
    if cursor.fetchone()[0] == 0:
        initial_courses = [
            ('Python Programming Fundamentals', 'Programming', 'Beginner', 'Learn core Python programming concepts and syntax.'),
            ('Oceanographic Data Processing', 'Oceanography', 'Advanced', 'Comprehensive guide to oceanographic data processing.'),
            ('Seismic Data Analysis', 'Seismology', 'Intermediate', 'In-depth look into processing seismic wave readings.'),
            ('Atmospheric Pressure & Weather Forecasting', 'Meteorology', 'Intermediate', 'Analysis of barometric pressure and cyclone prediction.')
        ]
        cursor.executemany(
            'INSERT INTO courses (title, category, level, description) VALUES (?, ?, ?, ?)',
            initial_courses
        )

    conn.commit()
    conn.close()

if __name__ == '__main__':
    init_db()
    print("Database initialized successfully!")