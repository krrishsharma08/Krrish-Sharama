
from datetime import datetime

LEVELS = ((0, 39, "Beginner"), (40, 59, "Developing"), (60, 79, "Intermediate"),
          (80, 94, "Advanced"), (95, 100, "Expert"))
THRESHOLDS = {"critical": 50, "needs_improvement": 70, "strong": 80}

def competency_level(score):
    score = max(0, min(100, float(score or 0)))
    for lo, hi, label in LEVELS:
        if lo <= score <= hi:
            return label
    return "Expert"

def classify_gap(score):
    score = float(score or 0)
    if score < THRESHOLDS["critical"]:
        return "Critical Gap"
    if score < THRESHOLDS["needs_improvement"]:
        return "Needs Improvement"
    if score < THRESHOLDS["strong"]:
        return "Competent"
    return "Strong"

def record_assessment(conn, username, assessment_type, subject_scores, total_questions=None,
                      correct_answers=None, started_at=None, completed_at=None):
    cur = conn.execute("""INSERT INTO competency_assessments
        (username, assessment_type, total_questions, correct_answers, started_at, completed_at)
        VALUES (?, ?, ?, ?, COALESCE(?, CURRENT_TIMESTAMP), COALESCE(?, CURRENT_TIMESTAMP))""",
        (username, assessment_type, total_questions, correct_answers, started_at, completed_at))
    assessment_id = cur.lastrowid
    for subject, score in subject_scores.items():
        conn.execute("""INSERT INTO competency_scores
            (assessment_id, subject, score, competency_level, created_at)
            VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)""",
            (assessment_id, subject, float(score), competency_level(score)))
    return assessment_id

def latest_scores(conn, username):
    rows = conn.execute("""SELECT cs.subject, cs.score, cs.competency_level, cs.created_at
        FROM competency_scores cs
        JOIN competency_assessments ca ON ca.id=cs.assessment_id
        WHERE ca.username=? AND cs.id IN (
          SELECT MAX(cs2.id) FROM competency_scores cs2
          JOIN competency_assessments ca2 ON ca2.id=cs2.assessment_id
          WHERE ca2.username=? GROUP BY cs2.subject
        ) ORDER BY cs.subject""", (username, username)).fetchall()
    return [dict(r) for r in rows]

def gap_analysis(conn, username):
    rows = latest_scores(conn, username)
    for r in rows:
        r["status"] = classify_gap(r["score"])
    strong = [r for r in rows if r["score"] >= THRESHOLDS["strong"]]
    weak = [r for r in rows if r["score"] < THRESHOLDS["needs_improvement"]]
    improving = []
    for r in rows:
        hist = conn.execute("""SELECT cs.score FROM competency_scores cs
            JOIN competency_assessments ca ON ca.id=cs.assessment_id
            WHERE ca.username=? AND cs.subject=? ORDER BY cs.id DESC LIMIT 2""",
            (username, r["subject"])).fetchall()
        if len(hist) == 2 and hist[0]["score"] > hist[1]["score"]:
            improving.append(r)
    critical = [r for r in rows if r["score"] < THRESHOLDS["critical"]]
    return {"scores": rows, "strong": strong, "weak": weak, "improving": improving, "critical": critical}
