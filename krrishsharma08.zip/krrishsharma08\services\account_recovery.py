import hashlib
import secrets
import smtplib
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage
import os

OTP_TTL_MINUTES = 10
MAX_ATTEMPTS = 5

def _hash_code(code):
    return hashlib.sha256(code.encode("utf-8")).hexdigest()

def _mask_destination(value, channel):
    value = value or ""
    if channel == "email":
        if "@" not in value:
            return "***"
        local, domain = value.split("@", 1)
        return (local[:1] + "***@" + domain) if local else "***@" + domain
    return ("*" * max(0, len(value)-4)) + value[-4:] if len(value) >= 4 else "***"

def find_user_by_identifier(conn, identifier):
    identifier = (identifier or "").strip()
    if not identifier:
        return None, None
    rows = conn.execute(
        "SELECT * FROM users WHERE lower(email)=lower(?) OR phone=?",
        (identifier, identifier)
    ).fetchall()
    if len(rows) != 1:
        return None, None
    user = rows[0]
    channel = "email" if user["email"] and user["email"].lower() == identifier.lower() else "phone"
    return user, channel

def _send_email(destination, code):
    host = os.environ.get("SMTP_HOST")
    port = int(os.environ.get("SMTP_PORT", "587"))
    sender = os.environ.get("SMTP_FROM") or os.environ.get("SMTP_USERNAME")
    username = os.environ.get("SMTP_USERNAME")
    password = os.environ.get("SMTP_PASSWORD")
    use_tls = os.environ.get("SMTP_USE_TLS", "1") == "1"
    if not all([host, sender, username, password]):
        return False
    msg = EmailMessage()
    msg["Subject"] = "PathSurfers account verification code"
    msg["From"] = sender
    msg["To"] = destination
    msg.set_content(
        "Your PathSurfers verification code is: "
        + code + "\n\nThis code expires in 10 minutes. If you did not request it, ignore this email."
    )
    with smtplib.SMTP(host, port, timeout=15) as server:
        if use_tls:
            server.starttls()
        server.login(username, password)
        server.send_message(msg)
    return True

def create_recovery_code(conn, username, channel, destination):
    conn.execute("UPDATE account_recovery_codes SET used=1 WHERE username=? AND used=0", (username,))
    code = f"{secrets.randbelow(1000000):06d}"
    expires = datetime.now(timezone.utc) + timedelta(minutes=OTP_TTL_MINUTES)
    conn.execute(
        """INSERT INTO account_recovery_codes
           (username, channel, destination, code_hash, expires_at)
           VALUES (?, ?, ?, ?, ?)""",
        (username, channel, destination, _hash_code(code), expires.isoformat())
    )
    sent = False
    if channel == "email":
        try:
            sent = _send_email(destination, code)
        except Exception:
            sent = False
    return code, sent, _mask_destination(destination, channel), expires

def verify_recovery_code(conn, username, code):
    row = conn.execute(
        """SELECT * FROM account_recovery_codes
           WHERE username=? AND used=0
           ORDER BY id DESC LIMIT 1""",
        (username,)
    ).fetchone()
    if not row:
        return False, "No active verification code. Request a new code."
    if row["attempts"] >= MAX_ATTEMPTS:
        return False, "Too many attempts. Request a new code."
    try:
        expires = datetime.fromisoformat(row["expires_at"])
        if expires.tzinfo is None:
            expires = expires.replace(tzinfo=timezone.utc)
    except ValueError:
        return False, "Verification code is invalid."
    if datetime.now(timezone.utc) > expires:
        conn.execute("UPDATE account_recovery_codes SET used=1 WHERE id=?", (row["id"],))
        return False, "Verification code has expired. Request a new code."
    if not secrets.compare_digest(_hash_code((code or "").strip()), row["code_hash"]):
        conn.execute("UPDATE account_recovery_codes SET attempts=attempts+1 WHERE id=?", (row["id"],))
        return False, "Incorrect verification code."
    conn.execute("UPDATE account_recovery_codes SET used=1 WHERE id=?", (row["id"],))
    return True, "Verified"

def set_password(conn, username, new_password):
    from werkzeug.security import generate_password_hash
    conn.execute("UPDATE users SET password=? WHERE username=?", (generate_password_hash(new_password), username))

def valid_password(password):
    return (
        isinstance(password, str)
        and 8 <= len(password) <= 128
        and any(c.isalpha() for c in password)
        and any(c.isdigit() for c in password)
    )

def verify_current_password(conn, username, password):
    from werkzeug.security import check_password_hash
    row = conn.execute("SELECT password FROM users WHERE username=?", (username,)).fetchone()
    return bool(row and check_password_hash(row["password"], password or ""))
