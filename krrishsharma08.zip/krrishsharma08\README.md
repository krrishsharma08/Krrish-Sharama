# PATHSURFERS

**Reverse-Engineered Career Roadmapper** — type a hyper-specific dream job, get an interactive,
dependency-aware career graph, then prove progress with real courses, competencies and an AI mentor.

PathForge (the roadmap engine) is the centrepiece; courses, competencies, recommendations,
analytics, repository, trainer matching, webinars, certificates and Mr.White are wired to it.

## Quick start

Python 3.10+ is the only requirement. Flask and its dependencies are vendored in `vendor/python`,
so no `pip install` is needed.

1. Put your Groq key in `.env` (copy `.env.example` if `.env` is missing):
   ```
   GROQ_API_KEY=YOUR_NEW_KEY_HERE
   GROQ_MODEL=openai/gpt-oss-120b
   ```
2. Start:
   - Windows: double-click `START_PATHSURFERS.bat`
   - Linux / macOS: `bash run_linux_mac.sh`
3. Open http://127.0.0.1:5000 (the launcher also prints a Wi-Fi address for phones).

## Architecture

| Layer | What |
|---|---|
| Backend | Flask 3 (`app.py`) + additive layers installed at startup: `enhancements.py`, `ghee_enhancements.py`, `ok_chat_enhancements.py`, `pathforge_api.py`, `fam_enhancements.py` |
| Frontend | Jinja templates (`templates/`), vanilla JS, `static/css/style.css` + `static/css/pathsurfers-ui.css` (glass/cyberpunk layer, light/dark) |
| PathForge | `templates/pathforge.html`, `static/js/pathforge.js`, `static/css/pathforge.css`, `pathforge_api.py` |
| Database | SQLite `database.db`; schema in `app.py:init_db` + `migrations/*.sql` (idempotent, applied on start) |
| AI | `services/groq_service.py` — the single Groq client used by every AI feature |
| PWA | `static/manifest.json`, `/sw.js` (served from root) |
| Android | `android_wrapper/` — WebView shell (see below) |

## How the AI is made reliable

- **One client** (`services/groq_service.py`): sends an explicit `User-Agent` (Groq's Cloudflare edge
  rejects the default `Python-urllib` agent with 403/1010), walks a model fallback chain when a model
  is retired, retries once on 429/5xx, enforces deadlines, and records the last error for
  `GET /api/ai/status`. The key never leaves the server.
- **PathForge never waits for AI**: the browser renders a deterministic local graph instantly,
  `/api/pathforge/generate` persists a server copy, then `/api/pathforge/enrich` asks Groq. The AI graph
  is accepted only after `sanitize_roadmap()` validates ids, types, phases, prerequisites (earlier nodes
  only) and the single target node. Timeout, error or malformed JSON leaves the local graph on screen.
- **Mr.White** receives a JSON profile built from the database (enrolments, module progress,
  competencies, PathForge target, completed and next-ready milestones) and must label
  `📊 From your data` vs `💡 Suggestion`. Without Groq it answers from the same data.

## Data flow (no fake numbers)

enrol → complete modules (`user_module_progress`) → competency per category =
module completion (averaged with course assessments when they exist) → PathForge sync
(`pathforge_roadmaps`, `learning_paths`) → recommendations rank real catalog courses by overlap
with your remaining PathForge milestones, then low-progress enrolled courses.

## Roles (exactly three)

| Role | Registration | Can |
|---|---|---|
| Trainee | must enter an existing Leader's 5-digit code | learner features, joins that Leader |
| Leader | a unique 5-digit code is generated | create courses, trainer workshop, repository, messaging |
| Non-Reliable User | no code | leader-style features and repository posting; **cannot message** (`/send_message`, mentor chat return 403); never gets a code |

## Install on phones

- **PWA (works now):** run the server, open the Wi-Fi URL in Chrome (Android) or Safari (iOS) →
  menu → *Add to Home screen*. Full "install app" prompts require HTTPS (deploy, or use a tunnel).
- **APK:** open `android_wrapper/` in Android Studio, set `START_URL` in `MainActivity.java` to your
  laptop's Wi-Fi URL or deployed HTTPS URL, then *Build → Build APK(s)*. Output:
  `android_wrapper/app/build/outputs/apk/debug/app-debug.apk`. Alternatively deploy over HTTPS and
  generate an APK from the PWA at pwabuilder.com.

## Security notes

`.env` is git-ignored; never commit it. All POSTs require a CSRF token (base.html attaches it to
every same-origin `fetch`). AI output is validated before use, and PathForge HTML-escapes all roadmap text before rendering.
