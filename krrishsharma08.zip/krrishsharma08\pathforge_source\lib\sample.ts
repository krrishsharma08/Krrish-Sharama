import type { StoredRoadmap } from "./schema";

// Hand-written SAMPLE roadmap (not AI-generated). Used only by "Explore Demo" as an offline fallback.
export const SAMPLE: StoredRoadmap = {
  id: "sample",
  createdAt: new Date(0).toISOString(),
  input: { dreamJob: "AI Engineer at a healthcare startup (sample)", level: "Beginner", skills: "", hoursPerWeek: 10, months: 6, companyType: "Healthcare" },
  title: "Sample: AI Engineer at a Healthcare Startup",
  targetRole: "AI Engineer",
  companyType: "Healthcare startup",
  summary: "A pre-written sample roadmap so you can explore the interface offline. Generate your own to see a fully AI-built path.",
  phases: [
    { id: "p1", title: "Foundations", description: "Programming and maths basics" },
    { id: "p2", title: "Core ML", description: "Classical ML and deep learning" },
    { id: "p3", title: "Domain & Portfolio", description: "Healthcare data and a capstone" },
    { id: "p4", title: "Entry & Target", description: "First role and the goal" },
  ],
  nodes: [
    { id: "n1", phaseId: "p1", title: "Python & Git", type: "skill", description: "Write clean Python and use Git daily.", skills: ["Python", "Git"], prerequisites: [], hours: 20, difficulty: "easy", optional: false },
    { id: "n2", phaseId: "p1", title: "Maths for ML", type: "skill", description: "Linear algebra, probability and calculus essentials.", skills: ["Linear algebra", "Probability"], prerequisites: ["n1"], hours: 25, difficulty: "medium", optional: false },
    { id: "n3", phaseId: "p1", title: "NumPy & Pandas", type: "skill", description: "Load, clean and explore tabular data.", skills: ["NumPy", "Pandas"], prerequisites: ["n1"], hours: 20, difficulty: "easy", optional: false },
    { id: "n4", phaseId: "p2", title: "Classical ML with scikit-learn", type: "skill", description: "Regression, trees, evaluation and validation.", skills: ["scikit-learn"], prerequisites: ["n2", "n3"], hours: 30, difficulty: "medium", optional: false },
    { id: "n5", phaseId: "p2", title: "Deep Learning with PyTorch", type: "skill", description: "Train neural networks end to end.", skills: ["PyTorch"], prerequisites: ["n4"], hours: 35, difficulty: "hard", optional: false },
    { id: "n6", phaseId: "p3", title: "Healthcare Data & Ethics", type: "skill", description: "Medical data formats, privacy and responsible AI.", skills: ["Privacy", "Bias"], prerequisites: ["n3"], hours: 15, difficulty: "medium", optional: false },
    { id: "n7", phaseId: "p3", title: "Capstone: Medical Image Classifier", type: "project", description: "End-to-end project on a public dataset.", skills: ["PyTorch", "Evaluation"], prerequisites: ["n5", "n6"], hours: 40, difficulty: "hard", optional: false },
    { id: "n8", phaseId: "p3", title: "Kaggle Competition (alt route)", type: "project", description: "Optional: sharpen skills in a competition.", skills: ["Feature engineering"], prerequisites: ["n4"], hours: 20, difficulty: "medium", optional: true },
    { id: "n9", phaseId: "p4", title: "ML Intern", type: "role", description: "First internship applying ML to real data.", skills: ["Teamwork"], prerequisites: ["n7"], hours: 10, difficulty: "medium", optional: false },
    { id: "n10", phaseId: "p4", title: "AI Engineer @ Healthcare Startup", type: "target", description: "Your dream role.", skills: [], prerequisites: ["n9"], hours: 5, difficulty: "hard", optional: false },
  ],
};
