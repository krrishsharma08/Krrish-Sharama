
import random
def get_question_set(conn, subject=None, count=5, difficulty=None):
    sql="SELECT * FROM questions WHERE active=1"
    params=[]
    if subject:
        sql += " AND lower(subject)=lower(?)"; params.append(subject)
    if difficulty:
        sql += " AND difficulty=?"; params.append(difficulty)
    rows=conn.execute(sql,params).fetchall()
    rows=list(rows); random.shuffle(rows)
    return [dict(r) for r in rows[:max(1,int(count))]]
def question_options(conn,qid):
    return [dict(r) for r in conn.execute("SELECT * FROM question_options WHERE question_id=? ORDER BY option_order",(qid,)).fetchall()]
