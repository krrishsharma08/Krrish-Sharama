
def dashboard_metrics(conn):
    def one(sql): return conn.execute(sql).fetchone()[0] or 0
    return {
        "trainees": one("SELECT COUNT(*) FROM users WHERE role='Trainee'"),
        "trainers": one("SELECT COUNT(*) FROM users WHERE role!='Trainee' AND role!='Administrator'"),
        "courses": one("SELECT COUNT(*) FROM courses"),
        "enrollments": one("SELECT COUNT(*) FROM enrollments"),
        "assessments": one("SELECT COUNT(*) FROM assessment_attempts"),
        "assignments": one("SELECT COUNT(*) FROM trainer_assignments"),
        "avg_feedback": round(float(conn.execute("SELECT AVG(rating) FROM trainer_feedback").fetchone()[0] or 0),2)
    }

# ---- PORTAL additive analytics: read-only, no schema/data changes ----

def score_distribution(conn):
    """Bucket every stored course-assessment score into 0-9,10-19,...,90-100 bands."""
    rows = conn.execute("SELECT score FROM course_assessments").fetchall()
    buckets = {f"{b}-{b+9}": 0 for b in range(0, 100, 10)}
    for r in rows:
        s = r['score'] or 0
        b = min(90, int(s // 10) * 10)
        buckets[f"{b}-{b+9}"] += 1
    return buckets

def pass_rate(conn):
    """Overall and per-course pass rate (score >= 70), based on existing course_assessments.passed flag."""
    total = conn.execute("SELECT COUNT(*) FROM course_assessments").fetchone()[0] or 0
    passed = conn.execute("SELECT COUNT(*) FROM course_assessments WHERE passed=1").fetchone()[0] or 0
    overall = round((passed * 100.0 / total), 1) if total else 0.0
    per_course = conn.execute("""
        SELECT c.title,
               COUNT(ca.id) attempts,
               ROUND(SUM(ca.passed) * 100.0 / COUNT(ca.id), 1) pass_pct
        FROM course_assessments ca JOIN courses c ON c.id = ca.course_id
        GROUP BY ca.course_id ORDER BY pass_pct ASC
    """).fetchall()
    return {"overall": overall, "total_attempts": total, "passed": passed,
            "per_course": [dict(r) for r in per_course]}

def leaderboard(conn, limit=10):
    """Top trainees ranked by average course-assessment score (existing data only)."""
    rows = conn.execute("""
        SELECT COALESCE(u.fullname, u.username) name, u.username,
               ROUND(AVG(ca.score), 1) avg_score, COUNT(ca.id) attempts
        FROM course_assessments ca JOIN users u ON u.username = ca.username
        GROUP BY ca.username ORDER BY avg_score DESC, attempts DESC LIMIT ?
    """, (limit,)).fetchall()
    return [dict(r) for r in rows]

def question_accuracy(conn, limit=15):
    """Which questions trainees get wrong most often, using existing assessment_answers."""
    rows = conn.execute("""
        SELECT q.id, q.subject, q.topic, q.question,
               COUNT(aa.id) attempts,
               ROUND(SUM(aa.is_correct) * 100.0 / COUNT(aa.id), 1) accuracy_pct
        FROM assessment_answers aa JOIN questions q ON q.id = aa.question_id
        GROUP BY aa.question_id HAVING attempts > 0
        ORDER BY accuracy_pct ASC LIMIT ?
    """, (limit,)).fetchall()
    return [dict(r) for r in rows]
