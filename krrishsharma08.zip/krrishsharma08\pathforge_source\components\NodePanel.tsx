"use client";
import { AlertTriangle, CheckCircle2, ExternalLink, Github, Hammer, HelpCircle, Lightbulb, Lock, Play, RotateCcw, Sparkles, X } from "lucide-react";
import type { NodeDetails, RoadmapNode } from "@/lib/schema";
import type { Status } from "@/lib/graph";

type Props = {
  node: RoadmapNode; status: Status; prereqs: { title: string; done: boolean }[];
  details?: NodeDetails; loading: boolean; error: string; known: boolean;
  onRetry: () => void; onClose: () => void; onStart: () => void; onDone: () => void; onKnown: () => void; onUndo: () => void;
};

export default function NodePanel(p: Props) {
  const { node, status, details: d } = p;
  return (
    <aside className="panel glass" aria-label={`Details for ${node.title}`}>
      <div className="panel-grab" />
      <div className="panel-head">
        <div>
          <div className="eyebrow">{node.type} · {node.difficulty} · ~{node.hours}h</div>
          <h2>{node.title}</h2>
        </div>
        <button className="icon-btn" onClick={p.onClose} aria-label="Close details"><X size={18} /></button>
      </div>
      <span className={`badge ${status}`}>{status === "completed" ? (p.known ? "Known" : "Completed") : status === "progress" ? "In progress" : status === "available" ? "Ready to start" : "Locked"}</span>
      <p className="muted">{node.description}</p>

      <div className="actions">
        {status === "available" && <button className="btn btn-primary" onClick={p.onStart}><Play size={16} /> Start learning</button>}
        {(status === "available" || status === "progress") && <button className="btn btn-ghost" onClick={p.onDone}><CheckCircle2 size={16} /> Mark completed</button>}
        {status !== "completed" && <button className="btn btn-known" onClick={p.onKnown}><Sparkles size={16} /> I already know this</button>}
        {status === "completed" && <button className="btn btn-ghost" onClick={p.onUndo}><RotateCcw size={16} /> Undo</button>}
      </div>

      {p.prereqs.length > 0 && (
        <section>
          <h4>Prerequisites</h4>
          <div className="tags">
            {p.prereqs.map((x) => <span key={x.title} className={x.done ? "tag ok" : "tag lock"}>{x.done ? <CheckCircle2 size={12} /> : <Lock size={12} />} {x.title}</span>)}
          </div>
        </section>
      )}

      {p.loading && <div className="shimmer-block"><i /><i /><i /><i /><span>Mr.White is preparing your milestone brief…</span></div>}
      {p.error && !p.loading && <div className="err">{p.error} <button className="link" onClick={p.onRetry}>Retry</button></div>}

      {d && (
        <>
          <section><h4><Lightbulb size={14} /> Why it matters</h4><p>{d.whyItMatters}</p></section>
          {d.concepts.length > 0 && <section><h4>What you need to know</h4><div className="tags">{d.concepts.map((c) => <span key={c} className="tag">{c}</span>)}</div></section>}
          <section className="card-in">
            <h4><Hammer size={14} /> Weekend project · ~{d.weekendProject.hours}h</h4>
            <strong>{d.weekendProject.title}</strong>
            <p>{d.weekendProject.description}</p>
          </section>
          {d.portfolioEvidence && <section><h4>Portfolio evidence</h4><p>{d.portfolioEvidence}</p></section>}
          {d.githubSuggestion && <section><h4><Github size={14} /> GitHub study tip</h4><p>{d.githubSuggestion}</p></section>}
          {d.interviewQuestions.length > 0 && <section><h4><HelpCircle size={14} /> Interview questions</h4><ol>{d.interviewQuestions.map((q) => <li key={q}>{q}</li>)}</ol></section>}
          {d.commonMistakes.length > 0 && <section><h4><AlertTriangle size={14} /> Common mistakes</h4><ul>{d.commonMistakes.map((q) => <li key={q}>{q}</li>)}</ul></section>}
          {d.resources.length > 0 && (
            <section>
              <h4>Suggested resources</h4>
              <p className="tiny">AI-suggested names. Not verified: check before relying on them.</p>
              {d.resources.map((r) => (
                <a key={r.name} className="res" target="_blank" rel="noopener noreferrer" href={`https://www.google.com/search?q=${encodeURIComponent(r.name)}`}>
                  <span><b>{r.name}</b> <em>{r.kind}</em><br /><small>{r.why}</small></span><ExternalLink size={14} />
                </a>
              ))}
            </section>
          )}
        </>
      )}
    </aside>
  );
}
