"""PORTAL additive seed: adds IMD/meteorology-domain questions to the existing
`questions` / `question_options` tables. Purely additive — never touches or
deletes any existing row. Safe to re-run (skips if already seeded)."""
import os
import sqlite3

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, 'database.db')

SEED_MARKER = 'PORTAL_METEOROLOGY_SEED_V1'

QUESTIONS = [
    ("Meteorology", "Numerical Weather Prediction", "Intermediate",
     "In Numerical Weather Prediction (NWP), what does the term 'model resolution' primarily determine?",
     "The smallest spatial scale of weather features the model can represent",
     ["The smallest spatial scale of weather features the model can represent",
      "The number of satellites used for data input", "The colour scheme of the output map",
      "The length of the forecast period only"], 0),
    ("Meteorology", "Numerical Weather Prediction", "Advanced",
     "Which technique is commonly used to combine observational data with a prior NWP model forecast to produce an improved initial state?",
     "Data assimilation",
     ["Data assimilation", "Data compression", "Radiative transfer modelling", "Fourier smoothing"], 0),
    ("Meteorology", "Doppler Radar", "Beginner",
     "Doppler weather radar primarily measures which two quantities to characterise precipitation?",
     "Reflectivity and radial velocity",
     ["Reflectivity and radial velocity", "Humidity and pressure", "Temperature and dew point", "Solar radiation and albedo"], 0),
    ("Meteorology", "Doppler Radar", "Intermediate",
     "A 'velocity couplet' on Doppler radar imagery — adjacent strong inbound and outbound velocities — is most associated with which phenomenon?",
     "Mesocyclone / tornadic rotation",
     ["Mesocyclone / tornadic rotation", "Clear-air turbulence", "Fog formation", "Stratospheric warming"], 0),
    ("Meteorology", "Tropical Cyclones", "Beginner",
     "On the Saffir-Simpson scale, a tropical cyclone is upgraded to a hurricane/cyclone once sustained winds exceed approximately what speed?",
     "119 km/h (64 knots)",
     ["119 km/h (64 knots)", "50 km/h (27 knots)", "200 km/h (108 knots)", "300 km/h (162 knots)"], 0),
    ("Meteorology", "Tropical Cyclones", "Intermediate",
     "The relatively calm, clear region at the centre of a mature tropical cyclone is known as the:",
     "Eye",
     ["Eye", "Eyewall", "Rainband", "Trough"], 0),
    ("Meteorology", "Tropical Cyclones", "Advanced",
     "Rapid intensification of a tropical cyclone is most favoured by which combination of ocean-atmosphere conditions?",
     "Warm sea-surface temperatures and low vertical wind shear",
     ["Warm sea-surface temperatures and low vertical wind shear",
      "Cold sea-surface temperatures and high wind shear",
      "Dry mid-level air and strong subsidence", "High surface pressure and stable stratification"], 0),
    ("Meteorology", "Satellite Meteorology", "Beginner",
     "Geostationary meteorological satellites like INSAT-3D orbit at an altitude that keeps them fixed over which reference point?",
     "A fixed point on the Earth's equator",
     ["A fixed point on the Earth's equator", "The North Pole", "The Sun", "A randomly drifting orbit"], 0),
    ("Meteorology", "Satellite Meteorology", "Intermediate",
     "Infrared satellite imagery of clouds is primarily used to estimate which property?",
     "Cloud-top temperature (and thus approximate height)",
     ["Cloud-top temperature (and thus approximate height)", "Cloud colour", "Wind direction at the surface", "Ocean salinity"], 0),
    ("Meteorology", "Atmospheric Physics", "Beginner",
     "The rate at which temperature decreases with altitude in the troposphere under standard conditions is called the:",
     "Environmental lapse rate",
     ["Environmental lapse rate", "Coriolis rate", "Pressure gradient rate", "Adiabatic constant"], 0),
    ("Meteorology", "Atmospheric Physics", "Intermediate",
     "The Coriolis force, responsible for deflecting moving air masses, is strongest at the:",
     "Poles",
     ["Poles", "Equator", "Tropic of Cancer only", "It is uniform everywhere on Earth"], 0),
    ("Meteorology", "Agro-Meteorology", "Beginner",
     "Agro-meteorological advisories issued to farmers primarily help with decisions about:",
     "Sowing, irrigation, and harvesting timing based on weather forecasts",
     ["Sowing, irrigation, and harvesting timing based on weather forecasts",
      "Stock market prices", "Urban traffic routing", "Airline scheduling only"], 0),
    ("Meteorology", "Agro-Meteorology", "Intermediate",
     "Downscaling a weather forecast from block level to panchayat (village) level primarily aims to improve which aspect of the forecast?",
     "Spatial resolution / hyper-local accuracy",
     ["Spatial resolution / hyper-local accuracy", "Forecast length (how many days ahead)",
      "Satellite bandwidth usage", "Radar reflectivity calibration"], 0),
    ("Meteorology", "Monsoon Science", "Intermediate",
     "The Indian Summer Monsoon is primarily driven by the seasonal reversal of winds caused by differential heating between the:",
     "Indian landmass and the surrounding Indian Ocean",
     ["Indian landmass and the surrounding Indian Ocean", "Arctic and Antarctic ice sheets",
      "Sun and the Moon's gravitational pull", "Himalayas and the Gobi desert only"], 0),
    ("Meteorology", "Weather Warnings", "Beginner",
     "In IMD's colour-coded weather warning system, which colour indicates the most severe 'take action' alert?",
     "Red",
     ["Red", "Green", "Yellow", "Blue"], 0),
    ("Seismology", "Earthquake Monitoring", "Intermediate",
     "The Richter and Moment Magnitude scales both aim to quantify which property of an earthquake?",
     "The energy released at the source",
     ["The energy released at the source", "The distance from the epicentre to the nearest city",
      "The depth of the fault line only", "The duration of aftershocks"], 0),
    ("Oceanography", "Ocean-Atmosphere Interaction", "Intermediate",
     "El Niño events, characterised by warmer-than-usual sea surface temperatures in the central/eastern Pacific, typically have what effect on the Indian monsoon?",
     "They are often (though not always) associated with weaker/below-normal monsoon rainfall",
     ["They are often (though not always) associated with weaker/below-normal monsoon rainfall",
      "They always cause flooding across all of India", "They have no known statistical relationship",
      "They only affect Antarctic sea ice"], 0),
]


def run():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    already = conn.execute(
        "SELECT COUNT(*) c FROM questions WHERE explanation LIKE ?", (f'%{SEED_MARKER}%',)
    ).fetchone()['c']
    if already:
        print(f"Meteorology seed already present ({already} rows) — skipping, no changes made.")
        conn.close()
        return

    inserted = 0
    for subject, topic, difficulty, question, correct, options, correct_idx in QUESTIONS:
        cur = conn.execute(
            "INSERT INTO questions(subject,topic,difficulty,question,explanation,marks,active) VALUES(?,?,?,?,?,?,1)",
            (subject, topic, difficulty, question, SEED_MARKER, 1)
        )
        qid = cur.lastrowid
        for i, opt_text in enumerate(options):
            conn.execute(
                "INSERT INTO question_options(question_id,option_text,is_correct,option_order) VALUES(?,?,?,?)",
                (qid, opt_text, 1 if i == correct_idx else 0, i + 1)
            )
        inserted += 1

    conn.commit()
    conn.close()
    print(f"Inserted {inserted} new meteorology/domain questions additively (existing rows untouched).")


if __name__ == '__main__':
    run()
