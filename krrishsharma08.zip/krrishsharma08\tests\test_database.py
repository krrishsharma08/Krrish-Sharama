import os, sqlite3, unittest
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
class DatabaseIntegrityTests(unittest.TestCase):
    def setUp(self): self.db=sqlite3.connect(os.path.join(ROOT,"database.db"))
    def test_original_data_exists(self):
        for table,minimum in [("users",5),("courses",4),("enrollments",3),("messages",5),("repository",9)]:
            self.assertGreaterEqual(self.db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0],minimum)
    def test_enhancement_tables_exist(self):
        names={r[0] for r in self.db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        for n in ["competency_assessments","competency_scores","questions","trainer_profiles","trainer_expertise","trainer_availability","trainer_assignments","course_feedback","trainer_feedback","certificates","approvals","notifications","training_deadlines","learning_paths","learning_path_items"]:
            self.assertIn(n,names)
if __name__=="__main__": unittest.main()
