import os, sqlite3, unittest
from services.account_recovery import valid_password, _hash_code

ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

class FinalFeatureTests(unittest.TestCase):
    def test_password_policy(self):
        self.assertTrue(valid_password("Example123"))
        self.assertFalse(valid_password("short"))
        self.assertFalse(valid_password("onlyletters"))

    def test_recovery_codes_are_hashed(self):
        self.assertNotEqual(_hash_code("123456"), "123456")
        self.assertEqual(len(_hash_code("123456")), 64)

    def test_username_is_unique(self):
        con=sqlite3.connect(os.path.join(ROOT,"database.db"))
        indexes=con.execute("PRAGMA index_list(users)").fetchall()
        names={row[1] for row in indexes}
        self.assertTrue("idx_users_username_unique" in names or any("sqlite_autoindex_users_1" == n for n in names))
        con.close()

if __name__=="__main__":
    unittest.main()
