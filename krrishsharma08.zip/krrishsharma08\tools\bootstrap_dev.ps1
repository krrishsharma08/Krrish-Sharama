$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)

Write-Host "[PathSurfers] Checking host tools..."
foreach ($cmd in @('python','node','npm','java')) {
  if (-not (Get-Command $cmd -ErrorAction SilentlyContinue)) { throw "$cmd is required." }
}

Write-Host "[PathSurfers] Creating Python environment..."
python -m venv "$Root\.venv"
& "$Root\.venv\Scripts\python.exe" -m pip install --upgrade pip
& "$Root\.venv\Scripts\python.exe" -m pip install -r "$Root\requirements.txt"

Write-Host "[PathSurfers] Installing PathForge dependencies..."
Push-Location "$Root\pathforge_source"
npm install
Pop-Location

Write-Host "[PathSurfers] Running deterministic verification..."
Push-Location $Root
& "$Root\.venv\Scripts\python.exe" scripts\verify_database.py
& "$Root\.venv\Scripts\python.exe" -m compileall -q app.py app_original.py enhancements.py fam_enhancements.py ghee_enhancements.py ok_chat_enhancements.py pathforge_api.py services scripts models tests
node --check static\js\pathforge.js
node --check static\js\script.js
Pop-Location

Write-Host "[PathSurfers] Web bootstrap complete."
Write-Host "Android SDK/Gradle should be installed through Android Studio or the official command-line tools before building the APK."
